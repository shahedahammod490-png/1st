"""Binary-safe debug-app export; no install, deletion, tar extraction or camera control.

Python 3.11+. The phone must have a sealed export from the nonhuman acquisition app.
SHA256 verifies transfer integrity, not clinical provenance or authentication.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import subprocess
from pathlib import Path

PACKAGE = "org.ocurisk.lab.acquisition"
ID_RE = re.compile(r"(?:capture|probe)_[a-f0-9]{32}\Z")
NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,100}\Z")
SERIAL_RE = re.compile(r"[A-Za-z0-9_.:-]{1,120}\Z")
MAX_FILE = 64 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024


def object_unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def parse_json(raw: bytes):
    return json.loads(raw.decode("utf-8"), object_pairs_hook=object_unique,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"Invalid JSON {x}")))


def checksum_entries(raw: bytes) -> list[dict]:
    if len(raw) > 64 * 1024:
        raise ValueError("Checksum manifest too large")
    obj = parse_json(raw)
    if not isinstance(obj, dict) or obj.get("schema_version") != "1.0":
        raise ValueError("Unknown checksum schema")
    entries = obj.get("files")
    if not isinstance(entries, list) or not 1 <= len(entries) <= 16:
        raise ValueError("Expected 1..16 files")
    seen, total = set(), 0
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Invalid file entry")
        name, size, digest = entry.get("name"), entry.get("size_bytes"), entry.get("sha256")
        if not isinstance(name, str) or not NAME_RE.fullmatch(name) or ".." in name or name == "checksums.json":
            raise ValueError("Unsafe export basename")
        if name in seen:
            raise ValueError("Duplicate export basename")
        if type(size) is not int or not 0 <= size <= MAX_FILE:
            raise ValueError("Invalid export size")
        if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError("Invalid SHA256")
        seen.add(name)
        total += size
    if total > MAX_TOTAL:
        raise ValueError("Export exceeds total limit")
    return entries


def validate_bytes(entry: dict, raw: bytes) -> None:
    if len(raw) != entry["size_bytes"]:
        raise ValueError(f"Byte length mismatch: {entry['name']}")
    if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
        raise ValueError(f"SHA256 mismatch: {entry['name']}")


def adb_bytes(adb: str, serial: str, args: list[str], max_bytes: int = MAX_FILE) -> bytes:
    # A temporary spool avoids unbounded RAM use; subprocess never uses a host shell.
    import tempfile
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        proc = subprocess.run([adb, "-s", serial, *args], stdout=out, stderr=err,
                              timeout=60, check=False)
        err.seek(0)
        message = err.read(8192).decode("utf-8", errors="replace")
        if proc.returncode:
            raise RuntimeError(f"ADB failed ({proc.returncode}): {message}")
        if out.tell() > max_bytes:
            raise ValueError("ADB output exceeded expected size")
        out.seek(0)
        return out.read(max_bytes + 1)


def assert_device(adb: str, serial: str) -> None:
    if not SERIAL_RE.fullmatch(serial):
        raise ValueError("Invalid explicit ADB serial")
    state = adb_bytes(adb, serial, ["get-state"], 1024).decode().strip()
    if state != "device":
        raise RuntimeError(f"Device must be authorized and online, got: {state!r}")


def validate_local(directory: Path) -> list[dict]:
    if directory.is_symlink():
        raise ValueError("Export directory must not be a symlink")
    checksum_path = directory / "checksums.json"
    if checksum_path.is_symlink() or not checksum_path.is_file() or checksum_path.stat().st_size > 65536:
        raise ValueError("Invalid checksum file")
    entries = checksum_entries(checksum_path.read_bytes())
    expected = {"checksums.json", *(e["name"] for e in entries)}
    if {p.name for p in directory.iterdir()} != expected:
        raise ValueError("Unexpected or missing export files")
    for entry in entries:
        path = directory / entry["name"]
        if not path.is_file() or path.is_symlink():
            raise ValueError("Export file is not a regular file")
        if path.stat().st_size != entry["size_bytes"]:
            raise ValueError("Export file size differs from checksum manifest")
        validate_bytes(entry, path.read_bytes())
    if "manifest.json" in expected:
        manifest = parse_json((directory / "manifest.json").read_bytes())
        if manifest.get("data_origin") != "NON_HUMAN_TEST" or manifest.get("mode") != "CONTROL":
            raise ValueError("This acquisition tool accepts only nonhuman CONTROL stills")
        frames = manifest.get("frames")
        if not isinstance(frames, list) or len(frames) != 1:
            raise ValueError("Expected exactly one native still")
        image = frames[0].get("source_file")
        match = next((e for e in entries if e["name"] == image), None)
        if match is None or frames[0].get("sha256") != match["sha256"]:
            raise ValueError("Capture manifest image hash mismatch")
        if image != "capture.jpg" or not (directory / image).read_bytes().startswith(b"\xff\xd8"):
            raise ValueError("Expected native JPEG magic")
    return entries


def download(adb: str, serial: str, capture_id: str, destination: Path) -> Path:
    if not ID_RE.fullmatch(capture_id):
        raise ValueError("Export ID must be the exact capture_/probe_ UUID shown by the app")
    assert_device(adb, serial)
    remote = f"files/export/{capture_id}"
    checksums = adb_bytes(adb, serial, ["exec-out", "run-as", PACKAGE, "cat", f"{remote}/checksums.json"], 65536)
    entries = checksum_entries(checksums)
    names = {entry["name"] for entry in entries}
    required = {"capture.jpg", "manifest.json", "metadata.json"} if capture_id.startswith("capture_") else {"capabilities.json", "capture_results.jsonl"}
    if names != required:
        raise ValueError("Export file set differs from this tool's expected sealed schema")
    directory = destination / capture_id
    directory.mkdir(parents=True, exist_ok=False)  # never overwrite an earlier export
    (directory / "checksums.json").write_bytes(checksums)
    for entry in entries:
        raw = adb_bytes(adb, serial, ["exec-out", "run-as", PACKAGE, "cat", f"{remote}/{entry['name']}"], entry["size_bytes"])
        validate_bytes(entry, raw)
        (directory / entry["name"]).write_bytes(raw)
    validate_local(directory)
    return directory


def import_payload(directory: Path, output: Path) -> None:
    entries = validate_local(directory)
    manifest_path = directory / "manifest.json"
    if not manifest_path.exists():
        raise ValueError("A capability probe is not a capture")
    manifest = parse_json(manifest_path.read_bytes())
    files = [{"name": e["name"], "base64": base64.b64encode((directory / e["name"]).read_bytes()).decode("ascii")}
             for e in entries if e["name"] == "capture.jpg"]
    # Metadata remains as a separate durable exported file. Contract only accepts image files.
    with output.open("x", encoding="utf-8") as f:
        json.dump({"manifest": manifest, "files": files}, f, allow_nan=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    dl = sub.add_parser("download")
    dl.add_argument("--adb", default="adb")
    dl.add_argument("--serial", required=True)
    dl.add_argument("--capture-id", required=True)
    dl.add_argument("--destination", type=Path, required=True)
    verify = sub.add_parser("verify")
    verify.add_argument("directory", type=Path)
    payload = sub.add_parser("payload")
    payload.add_argument("directory", type=Path)
    payload.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.action == "download":
        print(download(args.adb, args.serial, args.capture_id, args.destination))
    elif args.action == "verify":
        print(f"Verified {len(validate_local(args.directory))} file hashes and actual byte lengths")
    else:
        import_payload(args.directory, args.output)
        print(args.output)


if __name__ == "__main__":
    main()
