# Android nonhuman acquisition source

The native component is **IMPLEMENTED_UNTESTED, source only**. No APK was built and no phone was connected in the authoring environment. See [ANDROID_IMPLEMENTATION.md](../research/ANDROID_IMPLEMENTATION.md) for complete limitations, dependencies, transfer workflow and device acceptance gates.

The app enumerates selectable rear CameraX IDs, requires an explicit selection, probes Camera2 characteristics, logs request/result metadata, and saves native JPEG stills with exact timestamp association or explicit missing metadata. Default illumination is OFF. A separate short torch test is restricted to an acknowledged inert nonhuman target; the app never claims physical LED verification. Human acquisition, flash capture, video, pose estimation and direct HTTP upload are NOT_IMPLEMENTED.

Build with installed JDK 17, Gradle 8.11.1 and Android SDK platform/build-tools 35. No Gradle wrapper binary is supplied; do not assume `gradlew` exists.

```powershell
gradle --version
gradle :app:assembleDebug :app:lintDebug
```

Run the commands from this `android` directory, after configuring the Android SDK using Android Studio or `ANDROID_HOME`. The expected output path **after a successful build** is `app/build/outputs/apk/debug/app-debug.apk`. It does not currently exist.

Do not change dependency pins without recording the resolution/build output. The first real build must inspect resolved transitive dependencies and retain Gradle/SDK/JDK versions before claiming reproducibility.
