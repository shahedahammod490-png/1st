"""Synthetic encode/decode engineering evidence only."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image
from ocurisk_lab.video import probe_media,analyze_media
class VideoTests(unittest.TestCase):
 def test_actual_duplicate_decode_sampling_manual_cancel(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   for i in range(4): Image.fromarray(np.full((64,64,3),80 if i<2 else 100,dtype='uint8')).save(root/f'{i:02d}.png')
   source=root/'synthetic.mkv'
   subprocess.run(['ffmpeg','-v','error','-framerate','5','-i',str(root/'%02d.png'),'-c:v','ffv1',str(source)],check=True)
   digest=hashlib.sha256(source.read_bytes()).hexdigest(); metadata=probe_media(source)
   progress=[]; result=analyze_media(source,root/'out',media={'mirrored':False},options={'sample_every':2},progress=progress.append)
   self.assertEqual(len(result['frames']),4); self.assertEqual(result['frames'][0]['sha256'],result['frames'][1]['sha256'])
   self.assertEqual([f['timestamp_ns'] for f in result['frames']],['0','200000000','400000000','600000000'])
   self.assertIsNone(result['frames'][1]['eyes']); self.assertEqual(len(progress),4)
   self.assertEqual(digest,result['provenance']['source_sha256']); self.assertEqual(digest,hashlib.sha256(source.read_bytes()).hexdigest())
   cancelled=analyze_media(source,root/'cancel',media={},options={},cancelled=lambda:True)
   self.assertEqual(cancelled['status'],'CANCELLED'); self.assertEqual(cancelled['frames'],[])
   with self.assertRaises(ValueError): analyze_media(source,root/'invalid',media={},options={'annotations':{'4':{'OD':None,'OS':None}}})
 def test_still(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp); source=root/'synthetic.png'; Image.fromarray(np.full((64,64,3),80,dtype='uint8')).save(source)
   result=analyze_media(source,root/'out',media={},options={}); self.assertEqual(len(result['frames']),1)
 def test_manual_conflict_and_failed_partial(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp); source=root/'synthetic.png'; Image.fromarray(np.full((64,64,3),80,dtype='uint8')).save(source)
   circle={'cx_px':32,'cy_px':32,'radius_px':15,'source':'MANUAL_ANNOTATION'}
   result=analyze_media(source,root/'manual',media={},options={'annotations':{'0':{'OD':circle,'OS':circle}}})
   self.assertIsNone(result['frames'][0]['timestamp_ns'])
   for eye in result['frames'][0]['eyes'].values():
    self.assertEqual(eye['status'],'INCONCLUSIVE'); self.assertIn('ANATOMICAL_ANNOTATION_CONFLICT',eye['reasons']); self.assertEqual(eye['annotation_source'],'MANUAL_ANNOTATION')
   for comparisons in result['frames'][0]['comparisons'].values():
    self.assertIsNone(comparisons['BOUNDARY_Y_RE']['value'])
   def failure(value): raise RuntimeError('synthetic callback failure')
   failed=analyze_media(source,root/'failed',media={},options={},progress=failure)
   self.assertEqual(json.loads((root/'failed'/'result.partial.json').read_text()),failed)
   self.assertEqual(failed['status'],'FAILED'); self.assertEqual(len(failed['frames']),1); self.assertIn('synthetic callback failure',failed['error'])
 def test_detection_failure_retains_decoded_source(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp); source=root/'synthetic.png'; Image.fromarray(np.full((64,64,3),80,dtype='uint8')).save(source)
   with patch('ocurisk_lab.video.detection.detect',side_effect=RuntimeError('synthetic analysis failure')):
    result=analyze_media(source,root/'out',media={},options={})
   self.assertEqual(result['status'],'FAILED'); self.assertEqual(len(result['frames']),1)
   self.assertEqual(result['frames'][0]['analysis_status'],'PENDING'); self.assertIsNone(result['frames'][0]['eyes'])
   self.assertTrue((root/'out'/result['frames'][0]['source_file']).exists())
   self.assertEqual(json.loads((root/'out'/'result.partial.json').read_text()),result)
 def test_actual_variable_pts(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   for i in range(3): Image.fromarray(np.full((64,64,3),40+i*30,dtype='uint8')).save(root/f'{i}.png')
   listing=root/'frames.txt'; listing.write_text("file '0.png'\nduration 0.12\nfile '1.png'\nduration 0.40\nfile '2.png'\nduration 0.20\nfile '2.png'\n")
   source=root/'vfr.mkv'; subprocess.run(['ffmpeg','-v','error','-f','concat','-safe','1','-i',str(listing),'-fps_mode','vfr','-c:v','ffv1',str(source)],check=True)
   result=analyze_media(source,root/'out',media={},options={})
   stamps=[int(f['timestamp_ns']) for f in result['frames']]; self.assertEqual(stamps,[0,120000000,520000000,720000000]); self.assertEqual(len(stamps),4)
