# LAB-0001 first-stage release

Separate source/docs/test archive, 2026-10-08. Local Git checkpoint only; no external repository, production deployment or original integration. All three supplied PDF copies and provenance are included for future continuation. Original ZIP and dependency/node_modules/Git tree are intentionally not duplicated; use the original ZIP with its recorded SHA for legacy baseline execution/protection checks.

Implemented: loopback image import/persistence, manual anatomical OD/OS annotation, candidate spatial features/artifacts, immutable exports, deterministic replay, descriptive metrics, Android still/probe source and Windows/USB helpers. Android has no built APK. No real optical or clinical results, participant dataset, calibrated/trained model, full video or verified phone connection exists. Browser interaction/Windows/native build remain unverified. Scientific pipeline BLOCK; scoped independent Linux foundation APPROVE.

Read README to run. Read PROJECT_STATUS and HANDOFF_SOL to continue. Source hashes in evidence/release_inventory.json identify archived files; input hashes and verifier source snapshot remain separately preserved. Human datasets/runtime DB/caches/build outputs are excluded from release. Test evidence is synthetic and its origin is explicit.
