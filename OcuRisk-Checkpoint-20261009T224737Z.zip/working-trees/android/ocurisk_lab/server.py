"""Loopback-only research service: python -m ocurisk_lab.server."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
import json
import mimetypes
from pathlib import Path
import socket
from urllib.parse import unquote, urlsplit

from .schema import ValidationError, require
from .store import Store, json_text, runtime_versions

MAX_REQUEST_BYTES = 34 * 1024 * 1024
WEB = Path(__file__).parent / 'web'


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    def constant(value):
        raise ValidationError('Non-finite JSON number')
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ValidationError('Invalid strict JSON') from exc


def capabilities():
    return {'capture_import': 'IMPLEMENTED', 'manual_anatomical_annotation': 'IMPLEMENTED', 'candidate_image_features': 'IMPLEMENTED', 'advanced_models': 'NOT_IMPLEMENTED', 'clinical_prediction': 'AWAITING_REFERENCE_DATA', 'clinical_uncertainty': 'NOT_IMPLEMENTED', 'reference_dataset_registry': 'NOT_IMPLEMENTED', 'verified_reference_dataset': None, 'phone_connection': 'NOT_VERIFIED', 'physical_illumination': 'NOT_VERIFIED', 'geometry_calibration': 'NOT_VERIFIED', 'prediction': None, 'uncertainty': None}


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'

    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    def _host(self):
        hosts = self.headers.get_all('Host', [])
        require(len(hosts) == 1, 'Exactly one Host header required')
        host = hosts[0]
        require(host in self.server.allowed_hosts, 'Host is not an allowed loopback authority')
        return host

    def _route(self):
        require(not self.path.startswith('//'), 'Invalid request path')
        parsed = urlsplit(self.path)
        require(not parsed.scheme and not parsed.netloc and not parsed.query and not parsed.fragment, 'Invalid request target')
        path = unquote(parsed.path, errors='strict')
        require('\\' not in path and '\x00' not in path and not any(part in ('.', '..') for part in path.split('/')), 'Unsafe request path')
        return path.split('/')[1:]

    def _send(self, status, body, content_type='application/json; charset=utf-8', disposition=None):
        if not isinstance(body, bytes):
            body = json_text(body).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if disposition:
            self.send_header('Content-Disposition', disposition)
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path):
        self._send(200, path.read_bytes(), mimetypes.guess_type(path.name)[0] or 'application/octet-stream')

    def _dispatch(self, method):
        self._host()
        route = self._route()
        store = self.server.store
        if method == 'GET':
            if route == ['']:
                return self._file(WEB / 'index.html')
            if len(route) == 1 and route[0] in ('app.js', 'style.css'):
                return self._file(WEB / route[0])
            if route == ['api', 'health']:
                return self._send(200, {'status': 'running', 'service': 'OcuRisk Research Lab', 'runtime_versions': runtime_versions(), 'device_connection': 'NOT_VERIFIED'})
            if route == ['api', 'status']:
                return self._send(200, capabilities())
            if route == ['api', 'captures']:
                return self._send(200, store.captures())
            if len(route) == 3 and route[:2] == ['api', 'captures']:
                return self._send(200, store.capture(route[2]))
            if route == ['api', 'runs']:
                return self._send(200, store.runs())
            if len(route) == 3 and route[:2] == ['api', 'runs']:
                return self._send(200, store.run(route[2]))
            if len(route) == 3 and route[:2] == ['api', 'export']:
                return self._send(200, store.run(route[2]), disposition=f'attachment; filename="run-{route[2]}.json"')
            if len(route) == 4 and route[:2] == ['api', 'artifacts']:
                return self._file(store.artifact_path(route[2], route[3]))
            if len(route) == 4 and route[:2] == ['api', 'images']:
                return self._file(store.image_path(route[2], route[3]))
        if method == 'POST':
            host = self._host()
            origin = self.headers.get('Origin')
            require(origin is None or origin == f'http://{host}', 'Cross-origin writes forbidden')
            require(self.headers.get('Sec-Fetch-Site') in (None, 'same-origin', 'none'), 'Cross-site writes forbidden')
            require(self.headers.get_content_type() == 'application/json', 'Content-Type must be application/json')
            require(self.headers.get('Transfer-Encoding') is None, 'Transfer-Encoding unsupported')
            lengths = self.headers.get_all('Content-Length', [])
            require(len(lengths) == 1 and lengths[0].isdigit(), 'Content-Length required')
            length = int(lengths[0])
            require(0 < length <= MAX_REQUEST_BYTES, 'Request exceeds size bound')
            raw = self.rfile.read(length)
            require(len(raw) == length, 'Incomplete request body')
            payload = strict_json(raw)
            if route == ['api', 'captures']:
                return self._send(201, store.import_capture(payload))
            if len(route) == 4 and route[:2] == ['api', 'captures'] and route[3] == 'process':
                require(payload == {}, 'Processing request must be an empty object')
                return self._send(201, store.process(route[2]))
        self._send(404, {'error': 'Route not found'})

    def _handle(self, method):
        try:
            self._dispatch(method)
        except ValidationError as exc:
            self._send(400, {'error': str(exc)})
        except KeyError:
            self._send(404, {'error': 'Record or file not found'})
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            self.close_connection = True
        except Exception:
            self._send(500, {'error': 'Operation failed; no completed run was persisted'})

    def do_GET(self):
        self._handle('GET')

    def do_POST(self):
        self._handle('POST')


def create_server(host, port, data_dir, analyzer=None):
    # Resolve localhost without allowing arbitrary DNS names or non-loopback binds.
    require(host in ('localhost', '127.0.0.1', '::1'), 'Only loopback host 127.0.0.1, ::1 or localhost is allowed')
    bind_host = '127.0.0.1' if host == 'localhost' else host
    require(ipaddress.ip_address(bind_host).is_loopback, 'Public bind forbidden')
    require(type(port) is int and 0 <= port <= 65535, 'Invalid port')
    class LocalServer(ThreadingHTTPServer):
        address_family = socket.AF_INET6 if ':' in bind_host else socket.AF_INET
        daemon_threads = True
    server = LocalServer((bind_host, port), Handler)
    try:
        server.store = Store(data_dir, analyzer)
    except Exception:
        server.server_close()
        raise
    actual_port = server.server_address[1]
    authorities = [f'127.0.0.1:{actual_port}', f'localhost:{actual_port}', f'[::1]:{actual_port}']
    if actual_port == 80:
        authorities += ['127.0.0.1', 'localhost', '[::1]']
    server.allowed_hosts = set(authorities)
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', default=8765, type=int)
    parser.add_argument('--data-dir', default='data')
    args = parser.parse_args()
    try:
        server = create_server(args.host, args.port, args.data_dir)
    except ValidationError as exc:
        parser.error(str(exc))
    print(f'OcuRisk research service: http://{args.host}:{server.server_address[1]}', flush=True)
    print(json_text({'runtime_versions': runtime_versions(), 'capabilities': capabilities()}), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
