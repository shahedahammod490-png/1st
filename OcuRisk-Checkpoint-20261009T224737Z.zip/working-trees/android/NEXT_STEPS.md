# Continuation and next tasks

Read PROJECT_STATUS first, then TEST_REPORT, REPOSITORY_AUDIT, HANDOFF_SOL, contracts/INTERFACES, STAGE_ACCEPTANCE and independent verification. Do not assume memory of this session. User clarification: lead scientific architect conducts research/design/review; GPT-6.1 Sol is primary engineer. Original integration remains unauthorized.

| Priority / owner | Next task | Eligible work / dependency |
|---|---|---|
| P0 / Sol | Reproduce environment and Linux tests; browser smoke on equipped browser; then Windows runtime | Source available; pinned dependencies require package access or offline wheels; browser interaction unverified |
| P1 / User + Sol | Read-only Windows/ADB diagnostics, then build separate Android package | Physical connected PC, Android SDK/Gradle/JDK; no APK exists here |
| P1 / User + Sol | Inert-target OFF capture, observed request/result metadata, hash-identical USB export/import | Successful native build/device capability result; no eye illumination |
| P1 / Lead | Audit complete geometric derivations and model-eye apparatus assumptions | Primary full-source access, independent units/sign review; continue in parallel with engineering |
| P2 / Sol | Native sidecar association, robust repeated acquisition, video file+PTS decode, four streams | Real device sample formats and stream support; do not fake timestamp/pose |
| P2 / Lead | Preregister optical/segmentation and matched acquisition experiments | Measured geometry, fixation design, model-eye apparatus; safety review before human light |
| P2 / Sol | Alternative automatic pupil/glint detectors and faithful legacy replay | Same annotated frames, explicit comparator definitions; data eligibility |
| P3 / User + qualified collaborators | Define endpoint/population/reference, ethics/consent/safety, precision targets | Essential human clinical/research decisions; neither software nor prior papers grant approval |
| P3 / Lead | Complete statistical/Bayesian reporting-source review and frozen analysis design | No fitted probability without explicit likelihood/outcomes |
| P4 / Sol | Reference dataset/versioned grouped split and simple model pipelines | Approved independent references, leakage clearance, sufficient justified data |
| P5 / Lead + independent verifier | Review paired scope-specific results, failures/calibration/uncertainty | Frozen held-out cohort; no builder self-approval of scientific claims |
| Final / User | Decide whether any independently verified pipeline should enter original | No original changes unless explicitly approved |

Resume record must include new files/tests, actual hardware/data origin, code/config/input hashes, failures, scientific state, agent ownership, pending integration and human action. Keep raw data out of version control/release archive. Start new branches/worktrees after extracting the independent repository; never work inside the original EYE. Do not repeatedly rerun passed suites unless new changes/failures justify it. Never turn a blocked stage into success with synthetic data or default numbers.
