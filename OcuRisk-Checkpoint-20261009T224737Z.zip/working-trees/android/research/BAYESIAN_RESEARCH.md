# Bayesian and screening-risk research specification

Lead scientific architect, 2026-10-08. This is a proposed model design, not fitted software or an inferred patient probability. The detailed original audit is research/audits/RISK_BACKEND_AUDIT.md.

## Original model finding

`calculateMultiModalRisk()` constructs an additive score from optical/context signals and hand-set point shifts. The displayed Beta curve is parameterized after computing the score; there is no specified observed-data likelihood, fitted coefficients, posterior update or validation cohort. It therefore remains RISK_HEURISTIC. A Beta density curve around a selected number cannot turn that number into calibrated individual disease risk. Rounded unnormalized density ordinates and mismatch between reported index and Beta mean create additional display defects. The Li/Foo trajectory code contains illustrative rates, not validated progression coefficients.

## Outcomes before predictors

Define separately: (1) current reference-defined refractive screening condition, (2) referral under a prespecified subject-level rule, (3) future onset, and (4) progression over a specified horizon. A label must have independently adjudicated outcome, timing, clinical convention and population. Do not combine amblyopia, myopia, astigmatism, glare and behavioral risk into an unexplained percentage. User/qualified collaborators must choose clinical scope and error trade-offs before final validation. Cross-sectional labels cannot train five-year progression or causal intervention benefit.

## Candidate probabilistic specification

For a prespecified binary outcome, an initial comparator is penalized logistic regression. A Bayesian counterpart can be:

\[
y_i\mid p_i\sim\operatorname{Bernoulli}(p_i),\quad
\operatorname{logit}(p_i)=\alpha+x_i^T\beta+u_{site(i)}.
\]

Here i is the declared independent observation unit, not a video frame. For an eye-level outcome, use a participant effect/appropriate clustered analysis; for subject referral, define the both-eye aggregation rule before evaluating. Do not multiply two eye probabilities under an unjustified independence assumption. A site/device random effect is eligible only when enough distinct groups permit estimation; it cannot manufacture evidence for an unseen device.

Standardize continuous predictors using training data only. Specify priors with prior-predictive implications on the probability scale. A centered Normal coefficient prior with documented scale and an intercept prior reflecting an independently justified prevalence range are candidates, not approved numerical values. No prevalence or prior scale is selected here. Hierarchical variance priors require proper, checked behavior. Posterior inference method, sampler convergence (if MCMC), effective sample size/divergences, prior sensitivity and posterior predictive checks must be logged. Approximate inference needs its own verification. No numerical posterior or credible interval exists now.

Prediction for a new eligible case is posterior predictive integration over parameter uncertainty. A credible interval for fitted probability is different from outcome uncertainty, measurement error, uncertainty under domain shift and a frequentist interval on external performance. Heuristic quality scores are not any of these. The Beta-binomial conjugate model may represent prevalence from event counts under exchangeability; it is not an automatic personalized risk model with arbitrary multimodal features.

## Optical versus context

Optical estimator consumes optical/geometry inputs and independently measured refraction targets. Context (age, family history, behavior) belongs to a separately declared screening/prognostic model. Compare optical-only, context-only and combined models. A past prescription may reveal current labels or intervention history; use it only if the intended clinical use and temporal availability explicitly permit it, never secretly to improve optical prediction. Correlated outputs from the same image must not be counted as independent evidence. Cross-fitted optical predictions are required when training downstream risk on outputs of a model fitted to the same cohort.

Missingness must be explicit. Train-only imputation/missingness indicators are candidates; assess informative missingness and device/quality failures. No missing predictor becomes a normal value, fabricated measurement or assurance of low risk. Abstention/coverage is part of performance. Different priors or missingness patterns must not silently change the target population.

## Acceptance experiments

RISK01 compares archived heuristic ranking, logistic and Bayesian candidates on the same participants/outcome, with grouped tuning and a frozen independent test. Report calibration-in-the-large, slope, reliability curves with uncertainty, Brier/log loss, discrimination, threshold confusion counts, PPV/NPV at cohort prevalence and abstention. Evaluate clinical decision trade-offs with qualified threshold design; high AUC alone does not certify calibration or utility. Prior-sensitivity and simulated known-truth inference tests verify mathematics only. Bootstrap/model instability and subgroup/device sensitivity belong to development; cluster-aware paired intervals belong to final comparisons.

Acceptance requires reproducible posterior computation, sound unit/dependency handling, reference quality, leakage clearance and external scope-specific calibration/performance. Independent review must reproduce claims. PROGRESSION stays BLOCKED until appropriate longitudinal outcomes, follow-up/censoring, treatments and time-dependent analysis are designed. No therapeutic-effect percentage is inferred from observational association.

## Reporting evidence investigated after handoff

E12: Collins et al., 2024, TRIPOD+AI statement, DOI https://doi.org/10.1136/bmj-2023-078378; primary record and indexed abstract summary https://pubmed.ncbi.nlm.nih.gov/38626948/ inspected. It introduces a 27-item reporting checklist for regression/ML prediction studies. Publisher full text returned 403 here; checklist-item compliance is not claimed without complete inspection. This is reporting guidance, not a fitted-model validation certificate.

E13: Riley et al., Evaluation of clinical prediction models (part 2), BMJ 2024, DOI https://doi.org/10.1136/bmj-2023-074820; https://pubmed.ncbi.nlm.nih.gov/38224968/ record discovered but usable abstract/full methods unavailable on current open. E14: Whittle et al., Extended sample size calculations for evaluation of prediction models using a threshold for classification, primary author preprint https://arxiv.org/abs/2406.19673 and publication record https://pubmed.ncbi.nlm.nih.gov/40596983/. Discovery abstract distinguishes precision of threshold metrics from calibration/discrimination design. Full derivations not inspected and no sample-size number adopted. Next research: inspect complete E12–E14 methodology, prespecify intended population/event and target interval widths with qualified clinical/statistical collaborators, then compute a justified design accounting for clustering. Do not use a generic fixed events-per-variable rule as automatic acceptance.
