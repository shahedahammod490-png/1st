# CMF Phone 2 Pro / Windows USB feasibility plan

Date: 2026-10-08. Hardware state: **UNVERIFIED**. The user identifies CMF Phone 2 Pro and Windows PC with USB. This agent did not connect either device, run Windows commands, measure illumination/geometry or perform eye experiments. API documentation does not prove device support.

## Official engineering evidence inspected

| Source | Documented fact and limit |
| --- | --- |
| https://developer.android.com/media/camera/camerax/configuration | CameraX controls torch, focus/metering and exposure compensation. Query flash/torch capabilities and actual selected output. Requested settings are not physical verification. |
| https://developer.android.com/media/camera/camerax/analyze | KEEP_ONLY_LATEST drops/overwrites analysis frames; blocking can affect other bound use cases. Release ImageProxy, preserve actual format, strides, rotation and size. |
| https://developer.android.com/media/camera/camerax/video-capture | Preview + VideoCapture supported; combinations adding analysis/stills may fail due to hardware. Quality selection does not guarantee every combined configuration. |
| https://developer.android.com/reference/androidx/camera/camera2/interop/Camera2Interop.Extender | Capture requests/callbacks accessible through interop; do not submit competing requests or close CameraX-owned sessions. API versions evolve; pin and test dependencies. |
| https://developer.android.com/reference/androidx/camera/camera2/interop/Camera2CameraInfo | Access selected camera ID/characteristics through CameraX camera2 interop. |
| https://developer.android.com/reference/androidx/camera/camera2/interop/Camera2CameraControl | Interop request controls exist; verify observed result rather than assume controls applied. |
| https://developer.android.com/reference/android/hardware/camera2/CameraCharacteristics | Actual hardware level, available request/result keys and modes, stream configurations, sensor timestamp source and manual capabilities must be queried. |
| https://developer.android.com/reference/android/hardware/camera2/CaptureResult | SENSOR_TIMESTAMP is first-row exposure start. UNKNOWN/REALTIME timestamp source changes compatibility with IMU/elapsedRealtime. Missing keys remain unknown. |
| https://developer.android.com/tools/adb | USB authorization, device selection, install and file transfer. USB debugging does not turn the camera/LED into a PC instrument. |
| https://android.googlesource.com/platform/packages/modules/adb/+/refs/heads/main/docs/user/adb.1.md | Official command syntax for pull, reverse and install. |
| https://developer.android.com/studio/run/oem-usb | Windows USB/OEM driver diagnostics. |

CameraX is the first implementation choice. Camera2 interop is justified for observation/control where needed. A complete Camera2 replacement requires measured deficiencies in CameraX, not a preference for low-level code.

## H0 — Connection, no eye illumination

Physical user actions: connect a data-capable USB cable, enable developer USB debugging and accept the PC authorization prompt. Install official platform tools/appropriate driver if necessary. These actions are not clinical experiments.

Read-only diagnostics in Windows PowerShell:

```powershell
adb version
adb devices -l
adb -s <serial> shell getprop ro.product.model
adb -s <serial> shell getprop ro.build.version.release
adb -s <serial> shell getprop ro.build.version.sdk
adb -s <serial> shell getprop ro.build.fingerprint
```

Acceptance: exact device is authorized and online; model/build recorded; explicit serial prevents ambiguous multi-device operation. Keep device identifiers local; pseudonymize public exports.

## H1 — Camera capability report

Native diagnostic app enumerates camera IDs and available physical IDs; facing/sensor orientation; hardware level; focal lengths/sensor dimensions/intrinsics where supplied; available formats/sizes/FPS ranges; flash presence; AE/AF/AWB modes and locks; exposure/ISO/focus ranges; stabilization modes; request/result metadata keys; SENSOR_INFO_TIMESTAMP_SOURCE; motion sensors and coordinate frames.

Acceptance: report comes from the physical device. Missing/unsupported values are null with reasons. Main rear lens must be identified and selected by audited ID; automatic logical-camera switching must be recorded or prevented where possible. Advertised resolution is insufficient.

## H2 — CameraX nonhuman capture proof

Capture a calibration/color/chart target. Test configurations separately before combining them. Distinguish illumination OFF, pulsed still flash and continuous torch. Observe futures/CameraInfo/CaptureResult, physically confirm LED operation on a nonhuman target and verify automatic off on stop/background/error.

Measure actual size/frame timing, exposure, sensitivity, focus, WB and stabilization, clipping/blur and file finalization. RAW is optional only if advertised and usable; processed RGB/JPEG/video paths must record processing limitations.

Acceptance: real media + sidecars, explicit unsupported-configuration errors, lifecycle recovery and reproducible replay. No UI flash animation can satisfy illumination verification. This gate does not authorize human eye capture.

## H3 — Timing and metadata integrity

Persist requested settings separately from observed results. Retain camera sensor timestamps, analysis ImageProxy timestamps, decoded MP4 presentation timestamps, callback arrival times, IMU timestamps, clock sources and synchronization method.

Nanoseconds must be JSON decimal strings; JavaScript numbers can lose integer precision. UNKNOWN sensor timestamps cannot be assumed directly comparable with other clocks. IMU orientation is not translational position or working distance.

CameraX analysis and encoded video are separate streams. Do not associate by callback index or use requested FPS as actual sampling frequency. Establish and store a measured association/offset or use UNKNOWN. KEEP_ONLY_LATEST is acceptable for live coaching only when labelled; it cannot support the claim that every recorded frame was analyzed. Process all recorded decoded frames offline, using saved PTS and documented frame accounting.

Acceptance: timing provenance known; dropped frames/gaps reported; metadata association evidence available or marked unknown; no scientific time-series acceptance without suitable association.

## H4 — Transfer and import

First milestone: finalized phone files + JSON/JSONL metadata -> USB transfer -> immutable local import. No live stream is required initially.

Candidate commands after the Lab APK/export path exists:

```powershell
adb -s <serial> install <lab-debug.apk>
adb -s <serial> pull <lab-export-directory> <pc-import-directory>
adb -s <serial> reverse tcp:<lab-port> tcp:<lab-port>
adb -s <serial> reverse --list
```

Direct upload through reverse is a candidate, not yet verified. PC API should bind loopback, require a session token, validate paths/types/size, atomically persist finalized imports and verify SHA-256. Verify an actual phone request before labelling USB API upload functional. Do not add cloud transfer by default. Dedicated package/storage paths protect original OcuRisk.

Acceptance: matching SHA-256 and complete media/metadata, no partial-recording import, retry/idempotency, no writes to original project or its database.

## H5 — Physical geometry and nonhuman optical bench

Measure camera center, active LED center/extent, baseline vector and uncertainty, device axes, camera orientation and distances. An equation may define eccentricity relative to aperture edge rather than camera center; preserve the precise definition rather than substituting one quantity for another.

For eye position E, camera C and LED L, use engineering geometry predictors:

```text
n = (C - E) / norm(C - E)
b_perp = (I - n*n_transpose) * (L - C)
```

These are geometric quantities, not a refractive formula. Record world/camera/image coordinate transformations and create a physical diagram before approving movement.

| Motion | What must be distinguished |
| --- | --- |
| Static | Reference camera/light/distance/gaze geometry |
| Rigid roll | Rotates world LED-camera meridian, may preserve baseline magnitude; different from digital image rotation |
| Translation | Changes viewing direction relative to fixed gaze and may change projected baseline/distance |
| Yaw/pitch | Pivot determines source position, optical axis and view geometry |
| Head turn | Eye/head orientation, gaze compensation and peripheral optics change; not equivalent to flash eccentricity |

Use a measured jig/position for translation/distance; IMU alone cannot prove them. For each eye retain geometry independently.

Acceptance: movement type, pivot, units, uncertainty and distance defined. No angle-to-diopter mapping. No hard-coded right video = OD / left video = OS.

## H6 — Qualified safety and participant gate

The exact CMF light source, mode, shortest planned distance, exposure time, repetition, fail-safes and attachments require qualified optical/clinical review before human retinal-reflex experiments. Apply current relevant light-hazard evaluation, consent and applicable ethics/research permissions. The v3 suggested flash-photo instructions are not automatically an approved Lab protocol.

Sources: https://doi.org/10.11604/pamj.2022.43.15.32963 (nine other phones, condensing lens, no CMF; full methods inspected) and https://www.iso.org/standard/79919.html (current standard scope, full numerical standard not inspected). Neither certifies CMF torch video safety. No numeric safe exposure duration is invented here.

Distances 50/60/75/100 cm remain experiment design candidates, not proven safe/optimal operating values. Until approval, nonhuman engineering diagnostics proceed.

Acceptance: documented approval covers the exact configuration and participant procedure; independent reference/clinical protocol, consent and data governance exist.

## H7 — Controlled pilot after H6

Compare static control and both directional videos; preserve OD_RIGHT, OS_RIGHT, OD_LEFT and OS_LEFT. Record fixation target, head/gaze provenance, ambient conditions, actual settings/geometry, reference procedure and repeat acquisition. Head-turn is separate and optional.

First measure gradability, annotated segmentation, clipping/glint, repeatability, duration/failure burden. Refraction fitting requires appropriate independent reference method/date/device/examiner and cycloplegia status. Old spectacle prescriptions are not silently perfect references.

Acceptance: reproducible real signal, optical annotations/reference coverage and failure analysis. No quantitative refractive or screening performance claim before participant-held-out evaluation and independent verification.

## Present blockers and human actions

- Actual phone camera/Android/torch/control capabilities: UNKNOWN.
- Windows USB diagnostics, native APK build/install/run and transfer: NOT RUN BY THIS WORKSTREAM.
- Physical LED-camera geometry and emitted-light measurements: MISSING.
- Human safety/research approvals and independent reference dataset: MISSING.
- OcuRisk camera, optical, clinical or ML performance from this review: NONE MEASURED.

Next safe action: implement isolated diagnostic/report and import tooling, test against nonclinical fixtures, then request only the physical user actions needed to produce a real capability report. Agent sol_android was notified of timestamp, LED, use-case binding and frame-drop constraints.
