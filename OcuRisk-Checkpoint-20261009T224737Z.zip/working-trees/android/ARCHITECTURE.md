# Research architecture and engineering handoff

## Principle and implemented boundary
Build one independent local research application. Raw device truth must precede derived features; derived features must precede calibrated prediction; contextual risk must be a separate consumer. Missing observations remain null with reasons. Workflow state and scientific evidence status are separate fields. Legacy code is preserved for audit/comparison, never silently promoted to a validated pipeline.

First implementation uses a Python/SQLite loopback service, static browser dashboard and NumPy/Pillow optical inspection. This is an isolated research runtime, independent of original React/Express dependencies. It makes reproducible array-based research possible without rescuing the original coupled clinical computations. React can replace the presentation later behind unchanged contracts. Native Android CameraX is a separate acquisition client. `contracts/INTERFACES.md` is authoritative for initial APIs. No production project edits, deployments or database migrations are included.

```mermaid
flowchart TD
    A["Android acquisition"] --> B["Immutable capture import"]
    B --> C["Raw media and metadata"]
    C --> D["Per-frame OD and OS features"]
    R["Independent reference and subject split"] --> E["Refractive model comparison"]
    D --> E
    E --> F["Separate contextual risk models"]
    C --> G["Research dashboard and replay"]
    D --> G
    E --> G
    F --> G
    G --> V["Independent verification gate"]
```

Diagram shows target relationships, not a claim every node is implemented. Camera metadata probe/still source is initially unbuilt; ML/risk/reference modules remain unavailable until dependencies are satisfied.

## Seven research sections

| Section | Responsibilities | First iteration | Required later |
|---|---|---|---|
| Device/Acquisition | Capabilities, requested/observed controls, physical LED evidence, geometry, capture/transfer | CameraX probe/still source + Windows diagnostics | APK/device tests; video, pose/timing association, physical geometry |
| Dataset | Pseudonymous subject/session/capture IDs, immutable bytes, origin, references, splits | Strict image manifest, SHA256 import, SQLite, exact duplicate and partition audit utility | Approved collection, reference table/cards, near duplicates, frozen split UI |
| Optical | Independent eye ROIs, maps/masks/features, rejection and replay | Manual circles; spatial image candidates; baseline contrast adaptation | Automated pupil/iris alternatives, annotations, temporal/video replay, original full baseline harness |
| Refractive model | Physics, structured models, CNN, directional/hybrid/residual | Registry/unavailable output | Traceable/calibrated physics; trained artifacts, nested subject validation |
| Risk model | Legacy heuristic vs fitted statistical/Bayesian models | Legacy preserved; probability unavailable | Explicit target/horizon, priors/likelihood, calibration and external/longitudinal validation |
| Experiment/statistics | Config/source hashes, comparisons, errors, coverage, failure analysis | Persisted runs, descriptive metrics helpers | Paired held-out comparisons, cluster CIs, model cards, ablations |
| Evidence/Verification | Claims/assumptions/source/dispute/blocker registry | Audit, opened sources, independent engineering tests | Adversarial clinical-scope assessment and user-approved integration recommendation |

## Data and identity

Participant is the partition unit; no frame/session/eye split leakage. Capture direction and anatomical eye are independent. Both videos contain OD and OS; four streams remain `OD_RIGHT, OS_RIGHT, OD_LEFT, OS_LEFT`. No inference of preferred view from direction. For the initial image importer, a direction is just recorded metadata; it does not prove a continuous movement video was captured. Every imported frame retains index/time/source hash; no FPS-derived timestamp is fabricated.

Store native/decoded coordinate conventions, mirroring/rotation, source camera ID and actual physical lens where available. All pupil annotations are in stored image pixels. They are manual circles, not automated pupil fits or millimetres. Null eye geometry produces INCONCLUSIVE. Native exports include the Lab manifest plus separate sidecars; real format compatibility and backend sidecar association must be validated before calling the phone workflow integrated. Phone orientation from IMU is not translation/distance; sensor time association must be proven.

## Reproducibility and state

Immutable raw directory + validated manifest; SQLite stores capture/run JSON. Every run carries source hashes, manifest hash, algorithm/version/config/config hash and timestamp. Same bytes/config must yield identical features/artifact bytes apart from run identity/time. Do not overwrite a working result after algorithm changes. Save all rejected frames and reasons. Synthetic tests never populate an empty real-study database or clinical report.

Evidence statuses follow PDFs: LITERATURE_SUPPORTED, MEASURED_BY_US, MODEL_PREDICTED, ENGINEERING_DEFAULT, HYPOTHESIS, UNVERIFIED, CONTRADICTED, INCONCLUSIVE. Verifier statuses are separate. Engineering statuses include NOT_IMPLEMENTED, IMPLEMENTED_UNTESTED, TESTED_ENGINEERING_ONLY, AWAITING_REFERENCE_DATA, EXPERIMENTAL, VALIDATED_FOR_DEFINED_SCOPE, FAILED, INCONCLUSIVE. An image feature produced by code can be engineering-tested while its refractive interpretation remains UNVERIFIED.

## Privacy and scope

Loopback only; no cloud LLM or copied provider configuration; pseudonymous IDs; strict finite/schema/path/hash validation; bounded uploads; same-origin writes. Local files remain sensitive if humans appear: pseudonymous IDs do not anonymize faces, and a caller-supplied approval reference is not proof of ethics permission. Initial dashboard defaults to nonhuman engineering. Participant collection requires documented governance, consent, appropriate permissions, reference protocol and access/retention plan. Multi-user/remote use is outside first-release scope.

## Parallel ownership and integration

Actual GPT-6.1 Sol agents implement service, optical and Android modules. The lead owns contracts/docs/status, protection and packaging. Audit and verifier agents are separate from implementers. File ownership replaces branch merges in this shared directory; no agent can commit other modules. Root runs integration/regression after returned changes. Consequential scientific assumptions are reviewed independently; unresolved critical findings block acceptance, and user explicit approval is still needed for any original integration.
