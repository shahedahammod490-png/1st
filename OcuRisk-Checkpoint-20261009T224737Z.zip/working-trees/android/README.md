# OcuRisk Research Lab — LAB-0001

Original OcuRisk remains unchanged. This repository is an independent research foundation, not a clinically validated product. The lead scientific architect owns research/design/review; GPT-6.1 Sol is the primary engineer and was directly delegated the service, optical and Android modules.

Start continuation at [PROJECT_STATUS.md](PROJECT_STATUS.md). Read the [repository audit](REPOSITORY_AUDIT.md), [architecture](ARCHITECTURE.md), [Sol handoff](HANDOFF_SOL.md), [hardware validation](HARDWARE_VALIDATION.md), [experiment registry](EXPERIMENT_REGISTRY.md), [stage gates](STAGE_ACCEPTANCE.md), [test report](TEST_REPORT.md) and [next tasks](NEXT_STEPS.md). Scientific review, candidate models, missing evidence and source-access limitations are preserved under research/ and the root registries. Original supplied directives/PDF copies are in inputs/; supplemented research/engineering master prompts are in prompts/.

This independent local prototype imports PNG/JPEG images, stores capture metadata and manual anatomical eye circles, computes candidate image features, and exports immutable results. It starts with an empty database. It contains no trained clinical model or hidden demonstration captures. The completed tests use explicitly synthetic, nonhuman inputs.

## Install dependencies

Run commands from this repository directory. Python 3.11+ is the interface target; the current verified host is Linux with Python 3.12.14, NumPy 2.3.5 and Pillow 12.3.0. Windows execution and dependency installation have not been verified.

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir data
```

Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir data
```

The pinned dependencies match the tested environment. Installation requires access to a package index or compatible predownloaded wheels. For an offline wheel directory, replace the install command with `python -m pip install --no-index --find-links ./wheels -r requirements.txt`, using the environment's Python executable. No dependencies were downloaded during implementation. Availability of compatible Windows wheels remains unverified. The service uses Python's standard HTTP and SQLite libraries; FastAPI and pytest are unnecessary.

## Import, process and inspect

Open [http://127.0.0.1:8765](http://127.0.0.1:8765) after starting the server. Public network binds are rejected. Stop with Ctrl+C and restart with the same `--data-dir` to retain persisted captures and runs. Paths in `--data-dir` are server-operator settings, not client-supplied import paths.

1. Choose your PNG/JPEG image without an alpha channel or transparency tag. Images are bounded to 16 MiB each and 40 million decoded pixels; animated images are unsupported.
2. Enter source metadata. The default origin is `NON_HUMAN_TEST`. Leave unmeasured quantities blank; they remain null. The mode field records supplied metadata and does not prove that a video or phone acquisition occurred.
3. Explicitly select anatomical OD (right eye) or OS (left eye), then drag from the pupil center to its radius. Unannotated eyes remain missing. Circle coordinates refer to decoded stored image pixels; the display copy ignores orientation metadata, and rotation/mirroring fields are recorded without implicit image transformation.
4. Import the source and annotations. The server validates the manifest, decodes the actual image and verifies its SHA256. Duplicate IDs and exact source hashes are rejected.
5. Process the imported frames. Inspect the source, measurements with declared units, masks, feature definitions, artifact validity, algorithm configuration, runtime versions and implementation hashes. Export the actual result JSON from the run view.

Manual circles are annotations rather than automatic pupil detection or physical millimetre measurements. Feature computation does not establish clinical gradability. Missing clinical prediction and uncertainty remain null. Phone connection, physical illumination and geometric calibration remain unverified. Advanced models and the verified reference-data registry are unavailable.

`REAL_APPROVED` requires an explicitly supplied `approval_reference`. That field records provenance metadata; it neither verifies an ethics approval nor authorizes human acquisition. This milestone's evidence is nonhuman synthetic replay only. Study authorization and human acquisition gates are outside this software field.

## Deterministic replay of a supplied image

Supply an image and an eye-annotation JSON file yourself. For a missingness-only replay, `eyes.json` can contain:

```json
{"OD": null, "OS": null}
```

Replace an eye's null with an actual manually assigned circle when available. Each circle needs finite `cx_px`, `cy_px`, positive `radius_px`, and `source: "MANUAL_ANNOTATION"`, all in decoded source pixel coordinates. The replay command reads your files, computes twice, compares result JSON and artifact bytes, and writes a report plus the first run's actual artifacts. Its output directory must not already exist.

Windows PowerShell:

```powershell
.\.venv\Scripts\python.exe tools\replay.py --image .\frame.png --eyes-json .\eyes.json --output-dir .\replay-output
```

Linux:

```bash
.venv/bin/python tools/replay.py --image ./frame.png --eyes-json ./eyes.json --output-dir ./replay-output
```

Optional `--config-json ./config.json` records a supplied optical configuration. Exit code zero means the two executions agreed; it does not validate optics or clinical performance. Service runs preserve implementation hashes and reject changes to the loaded optical source; restart the service after code edits.

## Engineering checks

With the same environment Python:

```bash
python -m unittest discover -s tests -v
python -m compileall -q ocurisk_lab tools
```

If Node.js is available, `node --check ocurisk_lab/web/app.js` checks dashboard JavaScript syntax. The unit and independent suites exercise synthetic image import, missingness, zero preservation, persistence, deterministic replay, source provenance, invalid-input rejection, safe routes and loopback restrictions. These checks do not verify browser interaction, Windows, Android builds, phones, acquisition hardware or clinical performance.

## Optional browser smoke

`tests/browser_smoke.cjs` drives the dashboard with a newly generated, explicitly synthetic nonhuman image, distinct OD/OS drag-circle annotations, import, processing, rendered artifacts and an exported JSON download. It uses temporary capture storage and writes evidence under `evidence/browser-smoke/`. It requires an independently available Playwright module and Chromium executable; those are not backend runtime dependencies.

```bash
PLAYWRIGHT_MODULE_PATH=/absolute/path/to/playwright CHROMIUM_EXECUTABLE=/absolute/path/to/chrome node tests/browser_smoke.cjs
```

On Windows PowerShell, set the two environment variables before running `node tests/browser_smoke.cjs`. Set `PYTHON_EXECUTABLE` to your environment's Python when needed. If Playwright resolves normally and its installed browser is available, the two browser variables can be omitted.

The current Linux attempt reached local service startup but could not launch Chromium because its reported executable path does not exist. No browser was downloaded, and no screenshot or successful UI interaction is claimed. The saved failure report and service log document that boundary; browser interaction remains unverified.
