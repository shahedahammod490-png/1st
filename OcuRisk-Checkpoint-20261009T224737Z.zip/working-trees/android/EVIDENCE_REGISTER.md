# Evidence and claim register

The following is the authoritative mapping of claim type to evidence; no claim receives clinical acceptance from an engineering test. Literature details and access limits are in research/EVIDENCE_REVIEW.md (E01–E10) and research/OPTICAL_RESEARCH.md (E11 onward). Review is targeted, not a completed systematic review or novelty opinion.

| Claim ID | Claim / classification | Evidence / current conclusion |
|---|---|---|
| C01 | Original authored source/docs audited — ACTUAL SOFTWARE AUDIT | REPOSITORY_AUDIT and detailed function inventories; third-party dependency internals not exhaustively audited |
| C02 | Protected original unchanged — MEASURED FILE INTEGRITY | Inventory ZIP SHA and all inventoried authored source hashes; final check in TEST_REPORT |
| C03 | Original builds/tests currently pass — UNSUPPORTED | Original compiler fails with 18 errors; Linux Rollup startup block prevents runtime tests/build |
| C04 | Uniform image can receive original contrast/refraction evidence — REPRODUCED SOFTWARE DEFECT | Exact-source CV counterexamples; not a human measurement |
| C05 | Original risk is genuine Bayesian inference — CONTRADICTED BY IMPLEMENTATION | RISK_BACKEND_AUDIT; additive point shift + constructed Beta visualization lacks data likelihood |
| C06 | Separate import/replay foundation works in tested scope — TESTED_ENGINEERING_ONLY | Sol tests, independent 26-test suite; Linux synthetic/nonhuman scope only |
| C07 | RGB maps/gradient detect true retinal structures — HYPOTHESIS | Implemented candidate features; no structure-reference validation |
| C08 | CMF Android/USB acquisition verified — UNKNOWN | Native/Windows source exists; no build/device/Windows result |
| C09 | Smartphone photorefraction/CNN prior work exists — LITERATURE_SUPPORTED | E01/E06/E07; different devices, cohorts, endpoints; no transfer of published performance |
| C10 | Universal K6 or monotonic gradient gives accurate diopters — UNVERIFIED, CONTRARY CAUTION | No traceable shipped derivation/calibration; E02/E03/E11 warn calibration, saturation and pupil/source dependence |
| C11 | Directional fusion/head turn improves performance — HYPOTHESIS | Acquisition matrix proposed; no actual streams or comparative results |
| C12 | Safe CMF eye illumination — UNKNOWN | E09/E10 do not certify this configuration; qualified review and physical measurements absent |
| C13 | ML/Bayesian/5-year model validated — UNSUPPORTED | No fitted artifacts, reference dataset or follow-up outcomes |
| C14 | Generic approach is novel — UNVERIFIED | Prior-art matrix contains earlier phone/CNN/multimeridian/video precedents |
| C15 | A validated winning complete pipeline exists — UNKNOWN / BLOCKED | All scientific and final selection gates open; no production integration |

Future claim changes require precise scope, raw result/config/input references, independent reviewer, limitations and dated version. Record disagreements without overwriting prior findings. The six foundation verifier findings and fixes are preserved in the independent report; no consequential scientific dispute has been resolved by fabricating data.
