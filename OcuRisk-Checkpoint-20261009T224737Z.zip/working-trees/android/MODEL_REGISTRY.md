# Model registry

No trained model, weights, fitted calibration, Bayesian posterior or clinical prediction exists in this release. Performance fields are null/absent, never zero as a substitute for missing. Candidate complexity is conditional on dataset quality and sample-size/precision assessment.

| ID | Candidate / role | Status / required evidence |
|---|---|---|
| BASELINE_OLD | Exact original TS optical/risk source preserved in legacy; full pipeline replay not implemented | UNCALIBRATED; audited counterexamples, no clinical acceptance |
| ADAPTED_OLD | Per-eye contrast comparator inside optical v1.2; artificial .08 floor retained visibly | TESTED_ENGINEERING_ONLY; differs from original pooled detector |
| FEATURES_V1 | Manual pupil normalization, RD/RE/Y, glint/crescent candidates, gradient/polar | TESTED_ENGINEERING_ONLY; not a refractive model |
| CONST_TRAIN | Constant train-only reference-mean predictor | PLANNED; no training set |
| PHYSICS_CAL | Traceable bounded-domain eccentric model with measured geometry/calibration | UNVERIFIED; derivation and calibration unresolved |
| RIDGE / ELASTIC | Regularized tabular optical/geometry regression | AWAITING_REFERENCE_DATA; first fitted candidates |
| RF / BOOST | Random Forest/Gradient Boosting | AWAITING_REFERENCE_DATA; compare simpler models and instability |
| MLP / CNN | Small MLP/lightweight image network | NOT_IMPLEMENTED; subject-level learning curves and justified capacity |
| FUSION / HYBRID | Per-eye directional fusion, image+feature+geometry or valid physics residual | NOT_IMPLEMENTED; complete streams and ablations needed |
| RISK_HEURISTIC | Original additive risk score | ARCHIVED_UNVALIDATED; no posterior/probability interpretation |
| RISK_LOGISTIC / BAYES | Explicit event-based logistic/Bayesian models | AWAITING_OUTCOMES; see Bayesian specification |
| PROGRESSION | Longitudinal onset/progression | BLOCKED; no longitudinal outcomes |

Every future model card must record target/event/horizon, population/device scope, training/validation/test participant versions, preprocessing and tuning, code/data/config hashes, reference definition, missingness/abstention, calibration/uncertainty method, performance denominators and intervals, subgroup/device failures, prohibited uses, independent verdict and deployment status. A model ID is not evidence it was implemented.
