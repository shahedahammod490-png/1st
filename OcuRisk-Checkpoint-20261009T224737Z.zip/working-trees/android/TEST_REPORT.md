# Actual execution evidence — LAB-0001

Date: 2026-10-08. Host Linux, Python3.12.14, NumPy2.3.5, Pillow12.3.0, Node24.19.0. These results concern supplied synthetic inputs and software behavior. No participant performance, optical calibration, CMF acquisition or Windows result is included.

| Check | Actual result | Retained evidence |
|---|---|---|
| Combined Lab Python suite | **63/63 PASS**, 6.549 s, exit0 | evidence/final_python_tests.txt |
| Independent adversarial subset | **26/26 PASS**, separately run by verifier, 3.250 s; included in 63, not additional tests | research/verification/latest_tests.txt and INDEPENDENT_VERIFICATION.md |
| Optical subset | 14 tests included in 63 | Analytic features, uniform/glint/candidate, asymmetry, clipping, overlap, deterministic artifacts |
| Schema/service/evaluation subsets | 4/12/7 tests included in 63 | Manifest validation, HTTP/SQLite/import/export, missingness, finite metrics and leakage audit |
| Binary-safe USB helper | **6/6 PASS**, 0.002 s, exit0 | evidence/final_usb_helper_tests.txt; synthetic subprocess/byte fixtures, no real ADB |
| Original CV counterexamples | Six assertions PASS, Node24.19.0 | evidence/final_cv_reproduction.txt; copied computational bodies with source SHA/provenance |
| Original risk arithmetic counterexamples | Five assertions PASS, Python | evidence/final_risk_reproduction.txt; independent arithmetic, not original TS runtime |
| Protected ZIP and inventoried original tree | PASS, no mismatch, exit0 | evidence/final_original_protection.txt; exact ZIP SHA in original_inventory.json |
| Python compileall and dashboard/browser-script JS syntax | PASS, exit0 | evidence/final_check_summary.json |
| Android XML parsing | Two documents well-formed in engineer check | research/ANDROID_IMPLEMENTATION.md; XML parse is not Android build |
| Original tsc | FAIL, exit2, 18 errors | evidence/original_typecheck.txt |
| Original Vitest / Vite startup | BLOCKED, exit1 before tests/build; bundled Linux Rollup binary absent | evidence/original_test_start.txt, original_build_start.txt |
| Local Playwright browser smoke | BLOCKED: Chromium executable absent; no UI assertions executed | evidence/browser-smoke/browser-smoke-report.json and service-log.txt |
| Separate cloud browser loopback attempt | BLOCKED: ERR_CONNECTION_REFUSED while local service was running; browser not on this host | evidence/cloud_browser_attempt.json |
| Android/Windows/device/physical light/geometry | NOT RUN | Required tools/hardware absent; no APK or measured data |

The suite exercises actual public APIs, not a mock scientific pipeline. Temporary synthetic images are labeled SYNTHETIC; no test creates a clinical accuracy result. Concurrent source edits triggered stale-source rejection during an intermediate verifier run, as intended; builders froze implementation and a fresh final suite passed. Six independent findings were corrected and retested. The independent software verdict is APPROVE only for the tested Linux nonhuman image-import/replay foundation; the complete scientific verdict is BLOCK.

Reproduction commands from repository root:

```bash
python3 -m unittest discover -s tests -v
python3 -m unittest discover -s tools/windows -p 'test_*.py' -v
node research/audits/cv_reproduction.mjs
python3 research/audits/risk_math_reproduction.py
python3 tools/check_original.py --zip /path/to/original.zip --source /path/to/parent-of-EYE
python3 -m compileall -q ocurisk_lab tools
node --check ocurisk_lab/web/app.js
node --check tests/browser_smoke.cjs
```

The original-protection check requires the original input paths available to the operator; they are not embedded in application paths. Node's copied-source CV script uses experimental TypeScript stripping on the tested Node24 host. A source-only test script is not a completed browser/device experiment. Windows/Android/native stream behavior, real anatomy, clinical reference agreement and calibrated probabilities remain unverified.
