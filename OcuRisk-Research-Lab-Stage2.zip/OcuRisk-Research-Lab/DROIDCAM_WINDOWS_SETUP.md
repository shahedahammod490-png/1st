# Run the DroidCam Research Lab on your Windows PC

This is the existing local web interface with new live-capture/quality functions. It opens in your browser after the local program starts; it is not hosted online. Your already working DroidCam USB/Wi-Fi connection is the camera source. No new Android APK is required.

## First setup

1. Extract OcuRisk-Research-Lab-Stage2.zip into a new folder outside original OcuRisk. Open the included OcuRisk-Research-Lab folder.
2. Follow README.md to install Python3.12, pinned requirements and FFmpeg/ffprobe. Open PowerShell in this folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
ffmpeg -version
ffprobe -version
.\.venv\Scripts\python.exe -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir data
```

3. Leave this terminal running. Open http://127.0.0.1:8765 in your browser. Later starts can use tools/windows/start_lab.ps1 if your existing PowerShell policy permits it; the direct Python command above works without changing script policy. Stop the program with Ctrl+C. Restart using the same data directory to preserve records.

The launcher is supplied source; execution on your Windows PC has not been verified here. Missing FFmpeg/dependencies are real errors requiring installation, never substitute values.

## Record and automatically measure a nonhuman chart

1. Start your existing phone/PC DroidCam connection using USB or Wi-Fi as usual. Keep phone illumination off for this initial ordinary chart test.
2. Open Capture Studio. Create an experiment with a title, pseudonymous target/operator identifier, session ID, desired mode and NON_HUMAN_TEST origin. Select that experiment in the media section.
3. Click Discover cameras. If names are hidden, click Request camera permission / preview and allow camera access. Select the actual DroidCam input, then request preview again if necessary. Verify the feed is your target and inspect reported track settings.
4. Label USB or WIFI explicitly. The Lab records it as user-declared, since a virtual-camera name does not prove transport. For comparison, use a shared pair ID and target ID. Assert stationarity only for an actually stationary chart. A full-frame chart works; optionally drag the preview to select a source-pixel patch. Optional app/client/filter/focus/exposure/WB fields document known settings; blank/unknown fields are allowed and can make causal comparison confounded.
5. For STATIC choose STATIC. For MULTI_VIEW record RIGHT and LEFT separately under the same experiment; both observed eye candidates are processed in each. For HEAD_TURN select HEAD_TURN. These labels do not measure pose or prove anatomical laterality.
6. Click Start recording, then Stop & autosave. A120 second engineering guard stops normally; actual decoder bounds still apply at unusually high FPS. Snapshot & autosave saves current actual pixels. Automatic analysis is enabled by default. Upload & queue analysis uses the same quality pipeline for existing files.
7. Wait for the real processing job to complete in Optical Workspace. Inspect decoded frames/candidate maps, saved-stream quality, brightness/sharpness time plots, timing/gap diagnostics, candidate ranking and rejection reasons. Missing pupils or timing remain unavailable.
8. Return to Capture Studio, switch DroidCam transport in its client, and record the matching other connection. Select actual completed jobs in the USB/WiFi comparison section, compare, and download JSON. Mismatches produce warnings; observed differences do not declare a better connection.
9. Dataset & Expert Review provides complete experiment export, including originals, sidecars/results and provenance. Keep participant data out of Git/release archives. Partial/failed captures remain labelled and downloadable; they skip autoanalysis and cannot count as complete matched recordings.

## What to verify physically

- Actual DroidCam selection, preview and clean camera release on route exit/close.
- Static snapshot plus all three recording mode labels and both directional files.
- Original recording saved, queued and decoded; metrics agree with actual target and dimensions.
- USB/Wi-Fi labels reflect what you actually connected; repeat comparable nonhuman recordings and retain failures.
- Disconnect/error recovery, download fallback and server restart persistence.
- Export originals/results and inspect full quality JSON. Report browser/client versions and any exact error if a control fails.

No illuminated human-eye experiment is requested. Successful chart quality does not establish red-reflex acquisition, photorefraction accuracy, safe eye illumination or a trained clinical model. Those need the separate scientific gates.
