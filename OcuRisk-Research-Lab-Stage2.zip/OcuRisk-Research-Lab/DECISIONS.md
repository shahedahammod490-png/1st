# Dated decisions

| ID / date | Decision | Rationale and consequence |
|---|---|---|
| D01 / 2026-10-08 | Original ZIP/tree remain protected; new independent project | Audit evidence preserved; no production merge/migration authorized |
| D02 | Lead owns science/research/review; GPT-6.1 Sol agents own primary engineering | User role clarification; direct Sol delegation confirmed by environment; independent verifier is a separate agent, not claimed Opus |
| D03 | Local Python/SQLite/NumPy/Pillow + static dashboard; native CameraX client | Minimal executable isolation without transplanting coupled original clinical calculations; Windows is target but Linux is current test host |
| D04 | Fixed manifest/API before parallel edits; disjoint module ownership | Shared filesystem lacks independent worktrees initially; root-controlled integration/tests; no concurrent commits |
| D05 | Manual anatomical circles first; no assumed iris-mm scale | Useful inspectable processing can precede an unvalidated automatic detector; preserve null instead of fabricating physical values |
| D06 | Source/config/runtime hashes and immutable captures/runs | Reproducible evidence; cached optical code must match import-time source bytes, including constants |
| D07 | Exact legacy archive and explicitly ADAPTED_OLD comparator | Preserve .08 contrast artifact for comparison without labeling modified per-eye detector a faithful original pipeline |
| D08 | CameraX first with Camera2 interop where needed | Choice is provisional until CMF controls/stream tests; no automatic Camera2 rewrite based only on abstraction level |
| D09 | OFF nonhuman capture first; human optical protocol gated | No CMF-specific illumination measurements/approval; torch best-effort timer is not a certified safe exposure |
| D10 | Predictions and uncertainty null until references/calibration | Visible feature maps do not establish refraction or posterior risk; no fake confidence/data |
| D11 | REAL_APPROVED import enum retained with required reference | Allows later approved data provenance; string does not verify ethics or authorize collection; accepted first milestone is synthetic/nonhuman |
| D12 | Frozen-source verification; six findings corrected before scoped acceptance | Independent adversarial review found annotation/provenance/definition/alpha/UI/cache issues; critical scientific gates remain blocked |
| D13 | No winner/novelty or universal optical equation selected | Calibration/source/pupil/nonmonotonic evidence and prior art require further research; exact derivation not accessible in several sources |

Later changes append a dated supersession with evidence rather than erasing history. See PROJECT_STATUS for assignments and research/change_log.md for completion records.

## Stage2 decisions — 2026-10-09 UTC

- Keep source completion, engineering execution, browser/native execution and clinical acceptance separate. Preserve blocked evidence without substituting synthetic success.
- Freeze application source at05d915c before final tests; record independent hashes and preserve intermediate failures.
- Reject duplicate/overlapping eye candidates before anatomical assignment; retain unknown image-side observations/maps.
- Persist all owner branches and working snapshots plus main. Final integrated main supersedes older owner worktrees.
- Use explicit resume/status/task/evidence files on every continuation rather than relying on conversational memory. No background execution is promised after a turn ends.

## DroidCam decisions — 2026-10-10

- User already has workingUSB/WiFiDroidCam; virtualwebcam browser capture primary, nativeAPK optional.
- Measure savedvideo automatically across all decodedframes and retainopticalsampling separately.
- Transport labels userdeclared unless verified externally; browserreportedsettings requested/target and encodedPTS notsensortime.
- No universal sharpness/exposureclinicalthreshold, exactsource droppedframecount or inferredUSBwinner.
- ThreeSolengineeringowners editdisjointfiles; rootscientificcontract/status; independentverifier afterfreeze.
