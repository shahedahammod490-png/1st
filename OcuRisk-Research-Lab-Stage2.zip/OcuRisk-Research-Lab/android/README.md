# Android nonhuman acquisition source

Native state: **IMPLEMENTED_UNTESTED; BUILD_BLOCKED**, source only. No APK exists and no physical phone or Windows execution was verified.

CameraX selectable rear camera binding supports native JPEG stills and silent Recorder MP4 recordings for STATIC, RIGHT/LEFT (MULTI_VIEW), and HEAD_TURN labels. Those labels are caller-selected acquisition intent; head/phone pose remain null. Preview+ImageCapture and Preview+VideoCapture bind separately. Video preserves original encoded bytes, actual recording callbacks and received Camera2 request/result callbacks. Encoded-frame/sensor association remains explicitly UNKNOWN; callback times are not invented frame PTS. Recorder errors retain partial files and error metadata. Background/destroy requests stop recording and torch OFF; asynchronous finalization retains the executor until completion. These lifecycle paths require native/device verification.

Default illumination is OFF. A separate acknowledged inert-target torch test is software control only; physical LED behavior remains unverified. No human illumination protocol is provided.

Windows USB tooling in `../tools/windows/` verifies exported hashes before import. `adb_export.py import-stage2 DIRECTORY --base-url http://127.0.0.1:8765 --experiment-id ID` uploads original media bytes and checksummed sidecars into the additive Lab service. Failed recordings are retained on the phone and rejected as finalized imports. Tests use simulated ADB plus genuine FFmpeg-encoded synthetic nonhuman media; they do not establish USB/device feasibility.

Build with full JDK17, Gradle8.11.1 and Android SDK platform/build-tools35:

```bash
JAVA_HOME=/path/to/jdk17 ANDROID_HOME=/path/to/sdk GRADLE_BIN=/path/to/gradle ./verify-build.sh
```

No wrapper binary is supplied. Expected APK path only after success: `app/build/outputs/apk/debug/app-debug.apk`. The bounded recovery obtained official Gradle8.11.1, JDK17.0.18 and SDK command-line tools; checksums are retained in `../research/android-evidence/toolchain-recovery-sha256.txt`. SDK package manifests/platform35 could not be fetched. The final native attempt failed resolving Android Gradle Plugin8.9.2 before compilation (`build-recovery-final.txt`). No compilation/lint success is claimed. Retained logs describe attempted network/proxy/trust recovery; no further indefinite retry is warranted.

Current host verification: `python -m unittest discover -s tools/windows -p 'test_*.py' -v`; exact latest output is `../research/android-evidence/host-tests-final.txt`. Native build, actual CMF controls/sensor metadata, LED behavior, encoded timing, physical USB roundtrip and Windows remain separate unmet gates.
