package org.ocurisk.lab.acquisition;

import android.util.Range;
import android.util.Size;
import android.graphics.Rect;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Collection;

final class JsonFiles {
    static Object value(Object v) throws Exception {
        if (v == null) return JSONObject.NULL;
        if (v instanceof Long) return v.toString(); // ns values never lose integer precision in JS
        if (v instanceof Float || v instanceof Double) { double n=((Number)v).doubleValue(); return Double.isNaN(n)||Double.isInfinite(n)?JSONObject.NULL:v; }
        if (v instanceof Number || v instanceof Boolean || v instanceof String || v instanceof JSONObject || v instanceof JSONArray) return v;
        if (v.getClass().isArray()) { JSONArray a = new JSONArray(); for(int i=0;i<Array.getLength(v);i++) a.put(value(Array.get(v,i))); return a; }
        if (v instanceof Collection<?>) { JSONArray a=new JSONArray(); for(Object x:(Collection<?>)v) a.put(value(x)); return a; }
        if (v instanceof Range<?>) return new JSONObject().put("lower", value(((Range<?>)v).getLower())).put("upper", value(((Range<?>)v).getUpper()));
        if (v instanceof Size) return new JSONObject().put("width",((Size)v).getWidth()).put("height",((Size)v).getHeight());
        if (v instanceof Rect) { Rect r=(Rect)v; return new JSONObject().put("left",r.left).put("top",r.top).put("right",r.right).put("bottom",r.bottom); }
        return new JSONObject().put("encoding","android_toString").put("value",v.toString());
    }
    static void write(File path, byte[] bytes) throws Exception {
        File tmp = new File(path.getParentFile(), path.getName()+".partial");
        try(FileOutputStream out=new FileOutputStream(tmp)) { out.write(bytes); out.getFD().sync(); }
        if(!tmp.renameTo(path)) throw new IOException("Atomic rename failed: "+path);
    }
    static void json(File path, JSONObject v) throws Exception { write(path,v.toString(2).getBytes(StandardCharsets.UTF_8)); }
    static String hash(File path) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new FileInputStream(path)) { byte[] buf=new byte[65536]; int n; while((n=in.read(buf))!=-1) md.update(buf,0,n); }
        StringBuilder s=new StringBuilder(); for(byte b:md.digest()) s.append(String.format("%02x",b&255)); return s.toString();
    }
    static void seal(File dir, String... names) throws Exception {
        JSONArray a=new JSONArray();
        for(String n:names) { File f=new File(dir,n); a.put(new JSONObject().put("name",n).put("size_bytes",f.length()).put("sha256",hash(f))); }
        json(new File(dir,"checksums.json"),new JSONObject().put("schema_version","1.0").put("files",a));
    }
}
