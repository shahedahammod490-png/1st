package org.ocurisk.lab.acquisition;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.os.*;
import android.util.Range;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.camera.camera2.interop.*;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.camera.video.*;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

@androidx.annotation.OptIn(markerClass = ExperimentalCamera2Interop.class)
public class MainActivity extends ComponentActivity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Object resultLock=new Object();
    private final LinkedHashMap<Long,JSONObject> results=new LinkedHashMap<>();
    private CameraManager manager; private ProcessCameraProvider provider; private Camera camera;
    private ImageCapture still; private PreviewView preview; private Spinner selector; private TextView status;
    private VideoCapture<Recorder> video; private Recording recording; private Spinner acquisition; private File videoDir; private long videoLogStart; private JSONObject videoMetadata;
    private CheckBox nonhuman; private EditText exposure,iso;
    private String selectedId; private boolean busy=false,torchTesting=false,controlsReady=false,destroyed=false;
    private boolean foreground=false;
    private long controlGeneration=0;
    private JSONObject desired=new JSONObject(); private File resultLog;
    private final String sessionId="session_"+UUID.randomUUID().toString().replace("-","");
    private String deviceId;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        manager=(CameraManager)getSystemService(CAMERA_SERVICE);
        android.content.SharedPreferences identity=getSharedPreferences("provenance",MODE_PRIVATE);
        deviceId=identity.getString("device_id",null);
        if(deviceId==null) {deviceId="device_"+UUID.randomUUID().toString().replace("-","");identity.edit().putString("device_id",deviceId).apply();}
        LinearLayout column=new LinearLayout(this); column.setOrientation(LinearLayout.VERTICAL); column.setPadding(20,40,20,40);
        ScrollView scroll=new ScrollView(this); scroll.addView(column); setContentView(scroll);
        TextView safety=new TextView(this); safety.setText("NONHUMAN ENGINEERING ONLY. Use an inert target. No human/eye acquisition. Illumination defaults OFF. Physical LED behavior requires separate observation. Video and still bind separately. No audio is recorded."); column.addView(safety);
        preview=new PreviewView(this); column.addView(preview,new LinearLayout.LayoutParams(-1,450));
        acquisition=new Spinner(this); acquisition.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"STATIC","RIGHT","LEFT","HEAD_TURN"})); column.addView(acquisition);
        button(column,"Bind video preview (replaces still binding)",View.generateViewId(),()->bindVideo());
        button(column,"Start nonhuman video OFF",View.generateViewId(),()->startVideo());
        button(column,"Stop and finalize video",View.generateViewId(),()->stopVideo());
        selector=new Spinner(this); selector.setId(R.id.camera_id_selector); column.addView(selector);
        button(column,"Bind selected rear camera ID",R.id.bind_selected_camera,()->bindSelected());
        nonhuman=new CheckBox(this); nonhuman.setId(R.id.nonhuman_ack); nonhuman.setText("The target is nonhuman and inert"); column.addView(nonhuman);
        exposure=new EditText(this); exposure.setId(R.id.exposure_ns); exposure.setHint("Manual exposure nanoseconds (integer)"); exposure.setInputType(2); column.addView(exposure);
        iso=new EditText(this); iso.setId(R.id.iso); iso.setHint("Manual ISO (integer)"); iso.setInputType(2); column.addView(iso);
        button(column,"Apply manual exposure/ISO if supported",R.id.apply_manual_sensor,()->applyControls(true));
        button(column,"Restore auto; flash OFF",R.id.restore_auto,()->applyControls(false));
        button(column,"Capture native JPEG nonhuman still (OFF)",R.id.capture_nonhuman_still,()->capture());
        button(column,"Nonhuman torch test; OFF request after 1.5 s",R.id.torch_nonhuman_test,()->torchTest());
        button(column,"Request torch OFF",R.id.torch_off,()->off());
        button(column,"Export device probe + current result-log snapshot",R.id.export_capability_probe,()->probe());
        status=new TextView(this); column.addView(status);
        if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) initialize();
        else requestPermissions(new String[]{Manifest.permission.CAMERA},23);
    }
    private void button(LinearLayout c,String text,int id,Runnable action) { Button b=new Button(this); b.setText(text); b.setId(id); b.setOnClickListener(v->{try {action.run();} catch(Exception e){fail(e);}}); c.addView(b); }
    private void say(String s) { main.post(()->status.setText(s)); }
    private void fail(Exception e) { say("FAILED: "+e); }
    @Override public void onRequestPermissionsResult(int code,@NonNull String[] p,@NonNull int[] r) { super.onRequestPermissionsResult(code,p,r); if(code==23 && r.length>0 && r[0]==PackageManager.PERMISSION_GRANTED) initialize(); else say("Camera permission denied; no capture."); }
    private void initialize() {
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{try {
            provider=future.get();
            ArrayList<String> rearIds=new ArrayList<>(); rearIds.add("SELECT rear camera ID; no default main lens");
            for(CameraInfo info:provider.getAvailableCameraInfos()) {
                String id=Camera2CameraInfo.from(info).getCameraId();
                if(Objects.equals(manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING),CameraCharacteristics.LENS_FACING_BACK)) rearIds.add(id);
            }
            selector.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,rearIds));
            resultLog=new File(getFilesDir(),sessionId+".jsonl");
            say("Select a rear ID explicitly. Main-camera identity is unverified. "+(rearIds.size()-1)+" CameraX rear cameras exposed.");
        } catch(Exception e){fail(e);}},ContextCompat.getMainExecutor(this));
    }
    private void bindSelected() {
        if(busy||torchTesting) { say("Wait until capture/test finishes."); return; }
        if(provider==null || selector.getSelectedItemPosition()<1) { say("Select a rear camera ID first."); return; }
        off(); video=null; provider.unbindAll(); controlsReady=false; controlGeneration++;
        selectedId=selector.getSelectedItem().toString(); final String id=selectedId;
        try {
            CameraSelector choice=new CameraSelector.Builder().addCameraFilter(infos->{
                ArrayList<CameraInfo> matched=new ArrayList<>();
                for(CameraInfo info:infos) if(Camera2CameraInfo.from(info).getCameraId().equals(id)) matched.add(info);
                return matched;
            }).build();
            Preview.Builder pb=new Preview.Builder();
            new Camera2Interop.Extender<>(pb).setSessionCaptureCallback(captureCallback);
            Preview p=pb.build(); p.setSurfaceProvider(preview.getSurfaceProvider());
            still=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).setFlashMode(ImageCapture.FLASH_MODE_OFF).build();
            camera=provider.bindToLifecycle(this,choice,p,still);
            applyControls(false);
        } catch(Exception e) { camera=null; still=null; fail(e); }
    }
    private void bindVideo() {
        if(busy||torchTesting||provider==null||selector.getSelectedItemPosition()<1) {say("Select camera and finish capture first.");return;}
        off(); provider.unbindAll(); still=null; controlsReady=false; controlGeneration++;
        selectedId=selector.getSelectedItem().toString(); final String id=selectedId;
        try {
            CameraSelector choice=new CameraSelector.Builder().addCameraFilter(infos->{ArrayList<CameraInfo> found=new ArrayList<>();for(CameraInfo info:infos)if(Camera2CameraInfo.from(info).getCameraId().equals(id))found.add(info);return found;}).build();
            Preview.Builder pb=new Preview.Builder();new Camera2Interop.Extender<>(pb).setSessionCaptureCallback(captureCallback);
            Preview p=pb.build();p.setSurfaceProvider(preview.getSurfaceProvider());
            Recorder recorder=new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD,FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))).build();
            video=VideoCapture.withOutput(recorder);
            camera=provider.bindToLifecycle(this,choice,p,video);applyControls(false);
        }catch(Exception e){camera=null;video=null;fail(e);}
    }
    private void startVideo() {
        if(camera==null||video==null||busy||torchTesting||!controlsReady||!nonhuman.isChecked()){say("Bind video, apply controls and acknowledge inert target.");return;}
        busy=true;
        ListenableFuture<Void> offFuture=camera.getCameraControl().enableTorch(false);
        offFuture.addListener(()->{try{
            offFuture.get();if(!foreground||destroyed){busy=false;return;}String id="video_"+UUID.randomUUID().toString().replace("-","");videoDir=new File(getFilesDir(),"export/"+id);
            if(!videoDir.mkdirs())throw new IOException("Cannot create recording directory");
            synchronized(resultLock){videoLogStart=resultLog==null?0:resultLog.length();}
            String direction=acquisition.getSelectedItem().toString();
            videoMetadata=new JSONObject().put("schema_version","2.0").put("export_id",id).put("data_origin","NON_HUMAN_TEST").put("direction",direction)
                .put("mode",direction.equals("RIGHT")||direction.equals("LEFT")?"MULTI_VIEW":direction).put("source_file","recording.mp4").put("status","RECORDING")
                .put("camera_id",selectedId).put("device_id",deviceId).put("session_id",sessionId).put("build_fingerprint",Build.FINGERPRINT)
                .put("camera_capability_snapshot",CapabilityProbe.camera(manager,selectedId)).put("desired_controls",new JSONObject(desired.toString()))
                .put("start_request_elapsed_realtime_ns",Long.toString(SystemClock.elapsedRealtimeNanos())).put("mirrored",JSONObject.NULL)
                .put("sensor_frame_association","UNKNOWN_NO_ENCODED_FRAME_SENSOR_MATCH").put("phone_pose",JSONObject.NULL).put("head_pose",JSONObject.NULL)
                .put("physical_led_observation",JSONObject.NULL).put("audio_enabled",false);
            JsonFiles.json(new File(videoDir,"metadata.json"),videoMetadata);
            recording=video.getOutput().prepareRecording(this,new FileOutputOptions.Builder(new File(videoDir,"recording.mp4")).build())
                .start(ContextCompat.getMainExecutor(this),event->{try{
                    JSONObject log=new JSONObject().put("event",event.getClass().getSimpleName()).put("callback_elapsed_realtime_ns",Long.toString(SystemClock.elapsedRealtimeNanos()))
                        .put("recorded_duration_ns",Long.toString(event.getRecordingStats().getRecordedDurationNanos())).put("num_bytes_recorded",Long.toString(event.getRecordingStats().getNumBytesRecorded()));
                    if(event instanceof VideoRecordEvent.Finalize){VideoRecordEvent.Finalize f=(VideoRecordEvent.Finalize)event;log.put("error_code",f.getError()).put("cause",f.getCause()==null?JSONObject.NULL:f.getCause().toString());}
                    try(FileOutputStream out=new FileOutputStream(new File(videoDir,"recording_events.jsonl"),true)){out.write((log.toString()+"\n").getBytes(StandardCharsets.UTF_8));}catch(IOException e){videoMetadata.put("event_log_error",e.toString());fail(e);}
                    if(event instanceof VideoRecordEvent.Finalize){recording=null;off();final VideoRecordEvent.Finalize f=(VideoRecordEvent.Finalize)event;final File dir=videoDir;final JSONObject metadata=videoMetadata;io.execute(()->finalizeVideo(dir,metadata,f));}
                }catch(Exception e){stopVideo();fail(e);}});
            say("Recording nonhuman video OFF request; LED unverified. Stop to finalize.");
        }catch(Exception e){busy=false;off();fail(e);}},ContextCompat.getMainExecutor(this));
    }
    private void stopVideo(){if(recording!=null)recording.stop();off();}
    private void finalizeVideo(File dir,JSONObject metadata,VideoRecordEvent.Finalize event){try{
        File media=new File(dir,"recording.mp4");boolean valid=!event.hasError()&&media.isFile()&&media.length()>0;
        metadata.put("status",valid?"FINALIZED":"ERROR").put("error_code",event.getError()).put("error",event.getCause()==null?JSONObject.NULL:event.getCause().toString())
            .put("finalized_callback_elapsed_realtime_ns",Long.toString(SystemClock.elapsedRealtimeNanos())).put("size_bytes",media.length()).put("sha256",media.exists()?JsonFiles.hash(media):JSONObject.NULL);
        JsonFiles.json(new File(dir,"metadata.json"),metadata);
        synchronized(resultLock){try(RandomAccessFile in=new RandomAccessFile(resultLog,"r");FileOutputStream out=new FileOutputStream(new File(dir,"capture_results.jsonl"))){in.seek(videoLogStart);byte[] buffer=new byte[65536];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);out.getFD().sync();}}
        JsonFiles.json(new File(dir,"metadata.json"),metadata);
        if(media.exists())JsonFiles.seal(dir,"recording.mp4","metadata.json","recording_events.jsonl","capture_results.jsonl");
        else JsonFiles.seal(dir,"metadata.json","recording_events.jsonl","capture_results.jsonl");
        say((valid?"Finalized sealed video ":"Failed recording retained ")+dir.getName()+". Encoded frame/sensor association unknown.");
    }catch(Exception e){fail(e);}finally{main.post(()->busy=false);if(destroyed)io.shutdown();}}
    private static boolean includes(int[] xs,int x) { if(xs!=null) for(int v:xs) if(v==x) return true; return false; }
    private void applyControls(boolean manual) {
        if(camera==null || busy || torchTesting) { say("Bind camera and finish any pending capture/test first."); return; }
        try {
            CameraCharacteristics c=manager.getCameraCharacteristics(selectedId);
            CaptureRequestOptions.Builder options=new CaptureRequestOptions.Builder();
            options.setCaptureRequestOption(CaptureRequest.FLASH_MODE,CaptureRequest.FLASH_MODE_OFF);
            JSONObject next=new JSONObject().put("illumination","OFF").put("manual_sensor",manual);
            if(manual) {
                if(!includes(c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES),CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
                    || !includes(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES),CaptureRequest.CONTROL_AE_MODE_OFF)) throw new IllegalStateException("MANUAL_SENSOR/AE_OFF not advertised");
                long ns=Long.parseLong(exposure.getText().toString()); int sensitivity=Integer.parseInt(iso.getText().toString());
                Range<Long> er=c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE); Range<Integer> ir=c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                if(er==null||ir==null||!er.contains(ns)||!ir.contains(sensitivity)) throw new IllegalArgumentException("Exposure/ISO outside advertised range or range unavailable");
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_OFF);
                options.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME,ns);
                options.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY,sensitivity);
                next.put("exposure_time_ns",Long.toString(ns)).put("iso",sensitivity);
            } else {
                if(!includes(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES),CaptureRequest.CONTROL_AE_MODE_ON)) throw new IllegalStateException("AE_ON unavailable; cannot apply auto baseline");
                options.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);
                next.put("exposure_time_ns",JSONObject.NULL).put("iso",JSONObject.NULL);
            }
            // Set only advertised optional controls; unspecified keys stay visible in CaptureRequest/Result.
            if(includes(c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES),CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)) options.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            if(includes(c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES),CaptureRequest.CONTROL_AWB_MODE_AUTO)) options.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE,CaptureRequest.CONTROL_AWB_MODE_AUTO);
            if(includes(c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES),CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)) options.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF);
            if(includes(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION),CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)) options.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF);
            controlsReady=false; desired=next; final long generation=++controlGeneration;
            ListenableFuture<Void> f=Camera2CameraControl.from(camera.getCameraControl()).setCaptureRequestOptions(options.build());
            f.addListener(()->{try { f.get(); if(generation==controlGeneration && !destroyed) {controlsReady=true; say("Controls request completed. CaptureResult establishes reported behavior; physical behavior unverified.");} }catch(Exception e){fail(e);}},ContextCompat.getMainExecutor(this));
        } catch(Exception e) { fail(e); }
    }
    private void off() {
        torchTesting=false;
        if(camera!=null) {
            ListenableFuture<Void> f=camera.getCameraControl().enableTorch(false);
            f.addListener(()->{try {f.get();say("Torch OFF request completed; physical state unverified.");}catch(Exception e){fail(e);}},ContextCompat.getMainExecutor(this));
        }
    }
    private void torchTest() {
        if(camera==null||busy||torchTesting||!controlsReady||!nonhuman.isChecked()) { say("Bind camera, apply controls and acknowledge inert nonhuman target first."); return; }
        if(!camera.getCameraInfo().hasFlashUnit()) { say("CameraX reports no flash unit; physical LED state unknown."); return; }
        torchTesting=true;
        ListenableFuture<Void> f=camera.getCameraControl().enableTorch(true);
        // A timed OFF request is a best-effort software action, never a certified optical duration.
        main.postDelayed(this::off,1500);
        f.addListener(()->{try {f.get();say("Torch ON request completed. Observe only on inert target; physical state unverified. OFF already scheduled.");}catch(Exception e){off();fail(e);}},ContextCompat.getMainExecutor(this));
    }
    private final CameraCaptureSession.CaptureCallback captureCallback=new CameraCaptureSession.CaptureCallback() {
        @Override public void onCaptureCompleted(@NonNull CameraCaptureSession session,@NonNull CaptureRequest req,@NonNull TotalCaptureResult result) {
            try {
                JSONObject event=new JSONObject().put("event","capture_result").put("camera_id",session.getDevice().getId())
                    .put("frame_number",Long.toString(result.getFrameNumber())).put("callback_elapsed_realtime_ns",Long.toString(SystemClock.elapsedRealtimeNanos()))
                    .put("sensor_timestamp_ns",JsonFiles.value(result.get(CaptureResult.SENSOR_TIMESTAMP)))
                    .put("request",requestFields(req)).put("observed",resultFields(result)).put("physical_verified",false);
                Long ts=result.get(CaptureResult.SENSOR_TIMESTAMP);
                synchronized(resultLock) {
                    if(ts!=null) {results.put(ts,event); while(results.size()>512) results.remove(results.keySet().iterator().next());}
                    if(resultLog!=null) try(FileOutputStream out=new FileOutputStream(resultLog,true)) {out.write((event.toString()+"\n").getBytes(StandardCharsets.UTF_8));}
                }
            } catch(Exception e) { fail(e); }
        }
        @Override public void onCaptureFailed(@NonNull CameraCaptureSession s,@NonNull CaptureRequest r,@NonNull CaptureFailure f) { say("CaptureResult failure reason="+f.getReason()+", frame="+f.getFrameNumber()); }
    };
    private JSONObject requestFields(CaptureRequest r) throws Exception {
        return new JSONObject().put("exposure_time_ns",JsonFiles.value(r.get(CaptureRequest.SENSOR_EXPOSURE_TIME))).put("iso",JsonFiles.value(r.get(CaptureRequest.SENSOR_SENSITIVITY)))
            .put("af_mode",JsonFiles.value(r.get(CaptureRequest.CONTROL_AF_MODE))).put("ae_mode",JsonFiles.value(r.get(CaptureRequest.CONTROL_AE_MODE))).put("awb_mode",JsonFiles.value(r.get(CaptureRequest.CONTROL_AWB_MODE)))
            .put("ae_lock",JsonFiles.value(r.get(CaptureRequest.CONTROL_AE_LOCK))).put("awb_lock",JsonFiles.value(r.get(CaptureRequest.CONTROL_AWB_LOCK)))
            .put("focus_distance_diopters",JsonFiles.value(r.get(CaptureRequest.LENS_FOCUS_DISTANCE))).put("flash_mode",JsonFiles.value(r.get(CaptureRequest.FLASH_MODE)))
            .put("video_stabilization_mode",JsonFiles.value(r.get(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE))).put("optical_stabilization_mode",JsonFiles.value(r.get(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE)))
            .put("capture_intent",JsonFiles.value(r.get(CaptureRequest.CONTROL_CAPTURE_INTENT))).put("frame_duration_ns",JsonFiles.value(r.get(CaptureRequest.SENSOR_FRAME_DURATION)));
    }
    private JSONObject resultFields(CaptureResult r) throws Exception {
        return new JSONObject().put("exposure_time_ns",JsonFiles.value(r.get(CaptureResult.SENSOR_EXPOSURE_TIME))).put("iso",JsonFiles.value(r.get(CaptureResult.SENSOR_SENSITIVITY)))
            .put("af_mode",JsonFiles.value(r.get(CaptureResult.CONTROL_AF_MODE))).put("af_state",JsonFiles.value(r.get(CaptureResult.CONTROL_AF_STATE)))
            .put("ae_mode",JsonFiles.value(r.get(CaptureResult.CONTROL_AE_MODE))).put("ae_state",JsonFiles.value(r.get(CaptureResult.CONTROL_AE_STATE))).put("ae_lock",JsonFiles.value(r.get(CaptureResult.CONTROL_AE_LOCK)))
            .put("awb_mode",JsonFiles.value(r.get(CaptureResult.CONTROL_AWB_MODE))).put("awb_state",JsonFiles.value(r.get(CaptureResult.CONTROL_AWB_STATE))).put("awb_lock",JsonFiles.value(r.get(CaptureResult.CONTROL_AWB_LOCK)))
            .put("focus_distance_diopters",JsonFiles.value(r.get(CaptureResult.LENS_FOCUS_DISTANCE))).put("flash_mode",JsonFiles.value(r.get(CaptureResult.FLASH_MODE))).put("flash_state",JsonFiles.value(r.get(CaptureResult.FLASH_STATE)))
            .put("video_stabilization_mode",JsonFiles.value(r.get(CaptureResult.CONTROL_VIDEO_STABILIZATION_MODE))).put("optical_stabilization_mode",JsonFiles.value(r.get(CaptureResult.LENS_OPTICAL_STABILIZATION_MODE)))
            .put("frame_duration_ns",JsonFiles.value(r.get(CaptureResult.SENSOR_FRAME_DURATION)))
            .put("active_physical_camera_id",Build.VERSION.SDK_INT>=29?JsonFiles.value(r.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID)):JSONObject.NULL);
    }
    private void capture() {
        if(camera==null||still==null||busy||torchTesting||!controlsReady||!nonhuman.isChecked()) { say("Bind camera, finish controls/test and acknowledge nonhuman target."); return; }
        busy=true; final String cameraId=selectedId; final long click=SystemClock.elapsedRealtimeNanos();
        final JSONObject captureDesired;
        try { captureDesired=new JSONObject(desired.toString()); }catch(Exception e){busy=false;fail(e);return;}
        ListenableFuture<Void> off=camera.getCameraControl().enableTorch(false);
        off.addListener(()->{try {
            off.get(); still.setFlashMode(ImageCapture.FLASH_MODE_OFF);
            still.setTargetRotation(preview.getDisplay()==null?Surface.ROTATION_0:preview.getDisplay().getRotation());
            still.takePicture(io,new ImageCapture.OnImageCapturedCallback() {
                @Override public void onCaptureSuccess(@NonNull ImageProxy image) {
                    try {
                        if(image.getFormat()!=ImageFormat.JPEG) throw new IOException("Native JPEG required; received format "+image.getFormat());
                        long ts=image.getImageInfo().getTimestamp(); int rotation=image.getImageInfo().getRotationDegrees();
                        int width=image.getWidth(),height=image.getHeight();
                        ByteBuffer buffer=image.getPlanes()[0].getBuffer(); byte[] bytes=new byte[buffer.remaining()]; buffer.get(bytes);
                        image.close();
                        saveStill(bytes,ts,rotation,width,height,cameraId,click,captureDesired,0);
                    } catch(Exception e) {image.close();main.post(()->busy=false);fail(e);}
                }
                @Override public void onError(@NonNull ImageCaptureException e) {main.post(()->busy=false);fail(e);}
            });
        }catch(Exception e){busy=false;fail(e);}},ContextCompat.getMainExecutor(this));
    }
    private void saveStill(byte[] bytes,long ts,int rotation,int width,int height,String cameraId,long click,JSONObject captureDesired,int attempt) {
        JSONObject matched; synchronized(resultLock) {matched=results.get(ts);}
        if(matched!=null && !cameraId.equals(matched.optString("camera_id"))) matched=null;
        if(matched==null && attempt<20 && !destroyed) {main.postDelayed(()->{if(!io.isShutdown())io.execute(()->saveStill(bytes,ts,rotation,width,height,cameraId,click,captureDesired,attempt+1));},100);return;}
        try {
            String id="capture_"+UUID.randomUUID().toString().replace("-",""); File dir=new File(getFilesDir(),"export/"+id);
            if(!dir.mkdirs()) throw new IOException("Cannot create export directory");
            JsonFiles.write(new File(dir,"capture.jpg"),bytes);
            CameraCharacteristics characteristics=manager.getCameraCharacteristics(cameraId);
            JSONObject metadata=new JSONObject().put("status","IMPLEMENTED_UNTESTED").put("camera_id",cameraId).put("image_width",width).put("image_height",height)
                .put("build_fingerprint",Build.FINGERPRINT).put("sensor_timestamp_source",JsonFiles.value(characteristics.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE)))
                .put("camera_capability_snapshot",CapabilityProbe.camera(manager,cameraId))
                .put("image_proxy_timestamp_ns",Long.toString(ts)).put("rotation_metadata_deg",rotation).put("mirrored",JSONObject.NULL)
                .put("app_desired_controls",captureDesired).put("matched_result",matched==null?JSONObject.NULL:matched)
                .put("metadata_match",matched==null?"MISSING_EXACT_SENSOR_TIMESTAMP_MATCH":"EXACT_SENSOR_TIMESTAMP_MATCH")
                .put("click_elapsed_realtime_ns",Long.toString(click)).put("file_save_elapsed_realtime_ns",Long.toString(SystemClock.elapsedRealtimeNanos()))
                .put("geometry",JSONObject.NULL).put("physical_led_observation",JSONObject.NULL)
                .put("timestamp_note","ImageProxy timestamp is retained; only exact CaptureResult match supplies sensor timestamp. Clock domains are not assumed equal.");
            JsonFiles.json(new File(dir,"metadata.json"),metadata);
            JSONObject observed=matched==null?null:matched.getJSONObject("observed");
            Integer flash=observed==null||observed.isNull("flash_mode")?null:observed.getInt("flash_mode");
            Integer flashState=observed==null||observed.isNull("flash_state")?null:observed.getInt("flash_state");
            // FIRED invalidates a software OFF report; this is still never physical verification.
            String reported=flash==null||flashState==null?"UNKNOWN":flash==CaptureResult.FLASH_MODE_TORCH?"TORCH":flashState==CaptureResult.FLASH_STATE_FIRED?"FLASH":flash==CaptureResult.FLASH_MODE_OFF?"OFF":"UNKNOWN";
            JSONObject manifest=new JSONObject().put("schema_version","1.0").put("capture_id",id).put("participant_id","nonhuman_target").put("session_id",sessionId)
                .put("device_id",deviceId)
                .put("mode","CONTROL").put("data_origin","NON_HUMAN_TEST").put("approval_reference",JSONObject.NULL)
                .put("illumination",new JSONObject().put("requested","OFF").put("reported",reported).put("physical_verified",false).put("evidence_id",JSONObject.NULL))
                .put("distance_m",JSONObject.NULL).put("phone_pose",JSONObject.NULL).put("head_pose",JSONObject.NULL).put("mirrored",JSONObject.NULL)
                .put("image_rotation_deg",rotation).put("timestamp_source",matched==null?"UNKNOWN_NO_MATCHED_CAPTURE_RESULT":"CAMERA2_SENSOR_TIMESTAMP")
                .put("frames",new JSONArray().put(new JSONObject().put("frame_index",0).put("timestamp_ns",matched==null?JSONObject.NULL:matched.get("sensor_timestamp_ns"))
                    .put("source_file","capture.jpg").put("sha256",JsonFiles.hash(new File(dir,"capture.jpg"))).put("eyes",new JSONObject().put("OD",JSONObject.NULL).put("OS",JSONObject.NULL))));
            JsonFiles.json(new File(dir,"manifest.json"),manifest);
            JsonFiles.seal(dir,"capture.jpg","metadata.json","manifest.json");
            say("Saved sealed export "+id+". Metadata: "+metadata.getString("metadata_match")+". Physical LED unverified.");
        }catch(Exception e){fail(e);}finally{main.post(()->busy=false);}
    }
    private void probe() {
        if(provider==null) {say("Camera provider/permission unavailable.");return;}
        io.execute(()->{try {
            String id="probe_"+UUID.randomUUID().toString().replace("-","");File dir=new File(getFilesDir(),"export/"+id);
            if(!dir.mkdirs()) throw new IOException("Cannot create probe directory");
            JsonFiles.json(new File(dir,"capabilities.json"),CapabilityProbe.all(this));
            synchronized(resultLock) {
                byte[] log=resultLog==null||!resultLog.exists()?new byte[0]:readBytes(resultLog);
                JsonFiles.write(new File(dir,"capture_results.jsonl"),log);
            }
            JsonFiles.seal(dir,"capabilities.json","capture_results.jsonl");say("Saved sealed probe "+id+". Stream limits advertised; physical behavior untested.");
        }catch(Exception e){fail(e);}});
    }
    private static byte[] readBytes(File f) throws IOException {try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    @Override protected void onResume(){super.onResume();foreground=true;}
    @Override protected void onPause() {foreground=false;stopVideo();off();super.onPause();}
    @Override protected void onDestroy() {destroyed=true;controlGeneration++;stopVideo();off();super.onDestroy();if(recording==null&&!busy)io.shutdown();}
}
