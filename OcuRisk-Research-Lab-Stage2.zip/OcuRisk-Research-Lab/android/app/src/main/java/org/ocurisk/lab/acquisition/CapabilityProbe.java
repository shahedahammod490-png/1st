package org.ocurisk.lab.acquisition;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.util.Size;
import org.json.*;

final class CapabilityProbe {
    static JSONObject camera(CameraManager manager, String id) throws Exception {
        CameraCharacteristics c=manager.getCameraCharacteristics(id);
        JSONObject out=new JSONObject().put("camera_id",id).put("main_rear_camera_verified",false).put("physical_led_verified",false);
        JSONObject characteristics=new JSONObject();
        for(CameraCharacteristics.Key<?> key:c.getKeys()) {
            try { characteristics.put(key.getName(),JsonFiles.value(c.get(key))); }
            catch(Exception e) { characteristics.put(key.getName(),JSONObject.NULL); characteristics.put(key.getName()+"_read_error",e.toString()); }
        }
        out.put("characteristics",characteristics);
        out.put("available_request_keys",names(c.getAvailableCaptureRequestKeys()));
        out.put("available_result_keys",names(c.getAvailableCaptureResultKeys()));
        out.put("sensor_timestamp_source",JsonFiles.value(c.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE)));
        out.put("exposure_time_range_ns",JsonFiles.value(c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)));
        out.put("iso_range",JsonFiles.value(c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)));
        out.put("ae_modes",JsonFiles.value(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES)));
        out.put("af_modes",JsonFiles.value(c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)));
        out.put("awb_modes",JsonFiles.value(c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)));
        out.put("flash_available_reported",JsonFiles.value(c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)));
        out.put("fps_ranges_advertised_not_measured",JsonFiles.value(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)));
        StreamConfigurationMap streams=c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        JSONArray formats=new JSONArray();
        if(streams!=null) for(int format:streams.getOutputFormats()) {
            JSONArray sizes=new JSONArray(); Size[] supported=streams.getOutputSizes(format);
            if(supported!=null) for(Size s:supported) sizes.put(new JSONObject().put("width",s.getWidth()).put("height",s.getHeight())
                .put("minimum_frame_duration_ns",Long.toString(streams.getOutputMinFrameDuration(format,s)))
                .put("stall_duration_ns",Long.toString(streams.getOutputStallDuration(format,s))));
            formats.put(new JSONObject().put("format",format).put("sizes",sizes));
        }
        out.put("output_formats",streams==null?JSONObject.NULL:formats);
        JSONArray highSpeed=new JSONArray();
        if(streams!=null) {
            Size[] highSpeedSizes=streams.getHighSpeedVideoSizes();
            if(highSpeedSizes!=null) for(Size size:highSpeedSizes) highSpeed.put(new JSONObject().put("size",JsonFiles.value(size)).put("fps_ranges",JsonFiles.value(streams.getHighSpeedVideoFpsRangesFor(size))));
        }
        out.put("high_speed_video_advertised_not_implemented",streams==null?JSONObject.NULL:highSpeed);
        JSONArray physical=new JSONArray();
        if(Build.VERSION.SDK_INT>=28) for(String physicalId:c.getPhysicalCameraIds()) {
            try { physical.put(new JSONObject().put("id",physicalId).put("characteristics",cameraPhysical(manager,physicalId))); }
            catch(Exception e) { physical.put(new JSONObject().put("id",physicalId).put("error",e.toString())); }
        }
        out.put("physical_cameras",Build.VERSION.SDK_INT>=28?physical:JSONObject.NULL);
        return out;
    }
    private static JSONObject cameraPhysical(CameraManager m,String id) throws Exception {
        CameraCharacteristics c=m.getCameraCharacteristics(id); JSONObject o=new JSONObject();
        for(CameraCharacteristics.Key<?> k:c.getKeys()) o.put(k.getName(),JsonFiles.value(c.get(k))); return o;
    }
    private static JSONArray names(java.util.List<?> keys) { JSONArray a=new JSONArray(); if(keys!=null) for(Object k:keys) a.put(k.toString()); return a; }
    static JSONObject all(Context context) throws Exception {
        CameraManager manager=(CameraManager)context.getSystemService(Context.CAMERA_SERVICE);
        JSONArray cameras=new JSONArray();
        for(String id:manager.getCameraIdList()) { try { cameras.put(camera(manager,id)); } catch(Exception e) { cameras.put(new JSONObject().put("camera_id",id).put("error",e.toString())); } }
        JSONArray sensors=new JSONArray(); SensorManager sm=(SensorManager)context.getSystemService(Context.SENSOR_SERVICE);
        for(Sensor s:sm.getSensorList(Sensor.TYPE_ALL)) sensors.put(new JSONObject().put("name",s.getName()).put("type",s.getType()).put("vendor",s.getVendor()).put("version",s.getVersion()).put("min_delay_us",s.getMinDelay()).put("maximum_range",JsonFiles.value(s.getMaximumRange())).put("resolution",JsonFiles.value(s.getResolution())));
        return new JSONObject().put("schema_version","1.0").put("status","IMPLEMENTED_UNTESTED")
            .put("build_fingerprint",Build.FINGERPRINT).put("android_release",Build.VERSION.RELEASE).put("sdk",Build.VERSION.SDK_INT)
            .put("model",Build.MODEL).put("manufacturer",Build.MANUFACTURER).put("cameras",cameras).put("motion_sensor_inventory",sensors)
            .put("camera_to_led_distance_m",JSONObject.NULL).put("pose_measurement",JSONObject.NULL)
            .put("video_status","NOT_IMPLEMENTED").put("torch_physical_observation",JSONObject.NULL)
            .put("note","Advertised camera/sensor metadata is not verified physical behavior or an optical safety assessment.");
    }
}
