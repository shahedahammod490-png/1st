#!/usr/bin/env bash
# Reproducible native gate. Supply official Gradle 8.11.1, SDK35/buildtools35 and a full JDK17.
set -euo pipefail
cd "$(dirname "$0")"
: "${JAVA_HOME:?Set JAVA_HOME to full JDK17}"
: "${ANDROID_HOME:?Set ANDROID_HOME to SDK root}"
"$JAVA_HOME/bin/javac" -version
"${GRADLE_BIN:-gradle}" --version
"${GRADLE_BIN:-gradle}" --no-daemon :app:assembleDebug :app:lintDebug
sha256sum app/build/outputs/apk/debug/app-debug.apk
