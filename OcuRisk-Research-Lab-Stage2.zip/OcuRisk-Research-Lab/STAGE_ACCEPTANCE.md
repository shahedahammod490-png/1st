# Stage acceptance criteria

Passing means the documented scoped gate passes; never “the whole project works”. Scientific release remains blocked if geometry/illumination/identity/reference/leakage/uncertainty critical criteria fail. Numeric clinical tolerance, endpoint and power/precision targets require qualified study design and must be frozen before the final test cohort; do not invent an accuracy target merely to get a pass.

LAB-0001 scoped status: Stage0 authored-source/document audit COMPLETE, original runtime validation incomplete; Stage1 Linux synthetic/nonhuman import/replay foundation PASS after independent verification; Stage2 native source only, NOT PASSED; Stage3 manual feature visualization/replay engineering subset PASS, full optical baseline/real interpretation NOT PASSED. Stages4–11 scientific prerequisites remain open/BLOCKED. This is not acceptance of the complete clinical pipeline or Windows/Android/browser interaction.

| Stage | Deliverable and measurable acceptance | Current blocking dependencies |
|---|---|---|
| 0 Audit | All authored modules/docs read; current architecture/API/functions/assumptions documented; source preserved; actual baseline execution logs and counterexamples; stale docs distinguished | Original Vitest/build cannot run with packaged host-mismatched dependency binaries; source/static/arithmetic audit completed, full runtime verification incomplete |
| 1 Isolated foundation | Separate runtime/repo/data; empty DB; validated/checksummed imports; immutable actual runs/exports; finite/no fake outputs; independent eyes; meaningful tests + independent adversarial review; original hashes unchanged | Must resolve verifier consequential failures before scoped PASS |
| 2 Device/USB | Real CMF build/model/camera capability report; main lens selected by evidence; nonhuman real media+observed metadata; light fail-safe; hash-identical transfer; actual control/failure logs | Physical phone/Windows unavailable here; APK build and hardware gate not passed |
| 3 Optical inspection/baseline replay | Raw/normalized/masks/definitions/gradient/polar/quality visible; manual source explicit; legacy exact vs adapted separate; deterministic replay; out-of-bounds/missing abstain | Initial synthetic engineering tests; real optical structure interpretation and full old-video replay unverified |
| 4 Alternative segmentation | Same annotated frames through declared alternatives; false-positive/IoU/boundary/error/rejection tables; representative masks reviewed; independent labelled laterality fixtures | Real representative annotated data; candidate detector exists but real accuracy unverified |
| 5 Acquisition/repeatability | Static vs clearly defined phone-directional vs optional head-turn matched/repeated; all four streams; actual pose/distance/time/source LED and fixed-gaze evidence; reproducible signal/failures quantified | Geometry/illumination safety approval, actual controlled captures; cannot choose winner from appearance |
| 6 Approved referenced dataset | Consent/ethics/governance; independent reference method/date/device/examiner/cycloplegia; participant/eye/capture coverage/distribution/exclusions; duplicate/leakage audit; frozen split | Human research and clinical reference access; old prescription cannot fill gap |
| 7 Refractive models | Train-only transformations; simpler baselines/candidates/ablations; participant-grouped selection; frozen test; actual errors/coverage/uncertainty/OOD/failures; model cards | Dataset gate; no quantitative refraction claim from synthetic fixtures |
| 8 Risk/Bayesian | Explicit outcome/horizon/prior/likelihood; model fits vs heuristic/logistic; calibration/prior/missingness/correlation checks; context separate | Independent target outcomes; progression requires longitudinal follow-up |
| 9 Statistical comparison | Same held-out participants/captures; paired subject-cluster CIs; MAE/medianAE/RMSE/bias/LOA, sensitivity/spec/PPV/NPV/AUC/calibration as relevant; abstention/failure/latency/device/subgroup results | Preregistered endpoint/tolerances/precision design; no repeated test tuning |
| 10 Independent adversarial verification | Separate verifier reproduces claims, literature/conflicting evidence/replays, critical blockers resolved, signed/versioned verdict and disputes | Engineering review first; scientific review still requires actual data/hardware |
| 11 Integration recommendation | Supported/unsupported/rejected claims, scope/risks, final full-pipeline comparison and reproducible package; user selects whether to integrate | Explicit user approval; original integration not authorized |

## Stage 1 hard assertions
No source mutation; no public service bind; no cross-origin writes; no file traversal; no imported hash mismatch; no clinical fallback numbers; no copying one eye to another; timestamp zero valid; missing timestamp/distance/pose/reference/prediction/uncertainty stays missing; clipped/conflicting annotation explicit INCONCLUSIVE; source/config hash and artifact version retained; synthetic test results identified; no automatic advancement of scientific status.

## Study endpoint gate
Continuous agreement and screening utility are different goals. A model may have low mean error with unacceptable tails/abstention or subgroup failures. Before clinical selection, define which unit is evaluated (eye and/or subject referral rule), endpoint/horizon, refraction convention, disease-specific scope exclusions, acceptable lower confidence bound for sensitivity/coverage, and upper bound for error/false referrals with qualified collaborators. Engineering targets are never statistical power justifications. If all candidates fail, report no suitable pipeline.


## Stage2 acceptance supplement

Accept engineering components only against current integrated tests and current source hashes. Report separately: dependency/compile, unit/math, HTTP integration, actual browser interaction/appearance, native build, physical CMF/Windows and clinical science. An environment-blocked browser or APK build remains BLOCKED, even when Python tests pass.

Required software properties: all eligible source frames indexed; original hashes unchanged; duplicate frames retained; source PTS/estimated clock distinguished; no fabricated observations during tracking loss; unknown anatomical identity remains unresolved; same-source/ROI algorithm comparisons; joint manual conflict checks; saved append-only review/reference evidence; proper train-only/participant-grouped model fitting; explicit Bayesian likelihood/priors; synthetic/bench/clinical origins never mixed; missing dependency and missing clinical results are explicit.

Every exposed control must perform its stated operation or explain its unavailable prerequisite. No fake demonstration results or empty implementation may satisfy a gate. Expert reflex labels do not establish refraction accuracy. All scientific acceptance and original-product integration remain blocked pending independent reference evidence and the user's explicit integration approval.

Current Stage2 development milestone (2026-10-09 UTC) is distinct from numbered scientific stage 2 above: 112 Python and 9 host-helper tests pass, including independent execution. It does not pass the device/USB scientific gate. Browser/native/physical/clinical gates remain open.

## DroidCam amendment — 2026-10-10

DroidCam live source is primary by explicit user directive. Native APK acceptance is not a prerequisite for DroidCam browser acquisition. Require real selected virtualcamera, savedmedia/sidecars and automatic quality metrics with clock/proxy/missingness scope. ActualWindowsUSB/WiFi verification is separate from browserfixtures. Follow research/DROIDCAM_SCIENTIFIC_ACCEPTANCE.md; neither feed delivery nor chart quality verifies retinal reflex, eyeillumination safety or photorefraction.
