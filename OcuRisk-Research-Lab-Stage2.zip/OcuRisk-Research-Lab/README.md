# OcuRisk Research Lab — Stage2 development

A separate local research application. Original OcuRisk remains unchanged. No CMF optical performance, clinical accuracy or winning pipeline has been established.

**Resume development:** read RESUME_HERE.md, PROJECT_STATUS.md, TASK_BOARD.md, contracts/STAGE2.md and the latest independent verification report. The original repository audit and all three supplied PDFs remain in this repository. Historical Stage1 tests are not automatically evidence for current source.

## What you can do

| Workspace | Function |
|---|---|
| Overview | Inspect actual experiment counts, saved sessions, job states and available device status |
| Capture Studio | Create experiments, record a selected Windows webcam (DroidCam primary), or import original images/videos with mode, direction and source metadata |
| Optical Workspace | Automatically decode recordings, inspect frames and candidate maps, compare methods, save manual corrections and rerun |
| Models & Validation | Fit five regression algorithms or the Bayesian candidate to eligible supplied records; inspect actual errors and saved versions; run explicit physics utilities |
| Dataset & Expert Review | Search saved experiments, record reviewer observations and independent reference measurements, export original bytes and results |

The app starts empty. No patient, performance number, fake pupil or calibrated eye-power result is seeded. Automatic localizations are candidates. Missing observations remain missing. Synthetic fixtures exist only for software verification.

## Install and run on Windows

Use a new folder for this separate Lab, not your original EYE project. Python3.12 is the tested runtime family. Install FFmpeg/ffprobe and make them available on PATH for video processing. From PowerShell in this repository:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
ffmpeg -version
ffprobe -version
.\.venv\Scripts\python.exe -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir data
```

After installation, you can also start the server with `powershell -ExecutionPolicy Bypass -File .\tools\windows\start_lab.ps1`. The launcher checks the local environment and FFmpeg.

Open http://127.0.0.1:8765 in your browser. Keep the terminal running. Stop with Ctrl+C and restart with the same data directory to retain your records. The server binds only to loopback. Run one service per data directory, and restart after code changes.

Linux uses `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt`, then `.venv/bin/python -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir data`.

Dependencies require a package index or compatible offline wheels. Python requirements do not install the external FFmpeg/ffprobe executables or Android SDK. PyTorch is an optional separate dependency for the Python CNN/hybrid module. Missing dependencies produce an unavailable/error state, not substitute results. Actual Windows execution and CMF acquisition still need verification on your equipment.

## DroidCam on Windows (primary acquisition)

Use your already working DroidCam Windows client and phone connection (USB or Wi-Fi). Start its video preview, then open the Lab at `http://127.0.0.1:8765` in a browser that supports webcam access and MediaRecorder. Allow camera permission, refresh the camera list and select the actual DroidCam video input. The browser uses the Windows virtual webcam; no custom APK, ADB or backend camera driver is required for this workflow.

In Capture Studio choose Live Capture, declare the actual connection method and record an inert target. For a USB/Wi-Fi comparison, use the same nonempty pair ID, target ID, source-pixel chart ROI, stationary-target assertion and recording settings on both recordings. Requested browser constraints and observed track settings are retained separately. A user-declared USB/Wi-Fi label is not independent verification of transport. Stop recording, save the resulting media and metadata, and let the existing local job process it. The live preview is for framing; quality measurements are computed from the saved decoded stream.

The quality workspace shows every decoded frame, including frames excluded by explicit optical sampling, source presentation timing, brightness/RGB, clipping, sharpness/motion and compression-artifact proxies. It preserves detector quality separately. Save actual comparison JSON or export the experiment. Measurements describe acquisition diagnostics; no universal winner, retinal-reflex confirmation or eye-power accuracy follows from a sharper frame. See [research/DROIDCAM_INTEGRATION.md](research/DROIDCAM_INTEGRATION.md) for exact metadata/API and limitations.

If the browser cannot list DroidCam, check the Windows client preview, OS camera permissions, the browser permission for this loopback origin and exclusive use by another program. Codec/recording errors remain visible; partial recordings retain their error metadata where decodable. Use upload for an existing file when browser recording is unavailable. Actual Windows/DroidCam operation still requires verification on your equipment.

## Use your first nonhuman recording

1. Create an experiment with a pseudonymous participant/session ID and actual data origin. Static, Multi-view and Head-turn describe the acquisition mode; they do not measure head pose.
2. Import your original image/video. The service validates the actual file, preserves its bytes/hash and stores metadata. Source size is limited to256MiB and decoding has additional bounds.
3. Start analysis. All eligible frames are processed by default. Sampling is explicit; skipped optical observations stay missing while acquisition quality is measured on every decoded frame. Actual progress, cancellation and failures are retained.
4. Inspect source frames, candidate maps and measurements. Automatic eye/pupil candidates are not expert-confirmed retinal reflexes. Unknown anatomy remains image-side only. Manual circles refer to source pixels, not millimetres; save a correction and create a new processing run.
5. Save deliberate expert labels and comments when available. Independent clinical references are separate records. Reviewer identity, approval text and blinding declarations are assertions; the software does not authenticate them.
6. Export the experiment to retain originals, results and provenance. Keep participant recordings and fitted training payloads outside Git and release packages.

The original Stage1 interface remains at `/legacy`, along with its image manifest/import/replay routes. `tools/replay.py` preserves the deterministic manual-image workflow. Stage2 does not rewrite original OcuRisk.

## Models in simple language

Linear/Ridge/ElasticNet fit relatively simple measurement-to-target relationships. Random Forest and Gradient Boosting fit nonlinear patterns. The Bayesian logistic candidate estimates a declared binary event under explicit priors and a likelihood; its approximate probability interval is not validated disease risk. All require real eligible input records to produce research results. No model is clinically trained in the shipped empty application.

Participants, both eyes and repeated observations must stay in the same train/validation/test split. Compare models on matching targets, units and held-out reference cohorts. Low error on a different dataset does not select a winner. Full inputs, references, settings and source/runtime versions are retained with fitted artifacts. Bench and synthetic training remain distinct from clinical training.

The legacy physics utility reproduces archived arithmetic with explicitly supplied inputs and clamps. It is labelled uncalibrated and produces no clinical prediction. Power-vector conversion is a mathematical transform of supplied sphere/cylinder/axis. A calibrated camera-to-refraction model still requires physical measurements and independent reference experiments.

## Hardware and verification

Native CameraX is optional research work, not a prerequisite for DroidCam. Native video/still source and USB tools are under android/ and tools/windows/. Read android/README.md for the actual build status and available instructions. No APK or phone capability is claimed unless accompanied by completed build/device evidence. First physical steps are capability inspection and inert-target acquisition with illumination OFF. Human-eye illumination requires the separate qualified safety/research gates.

Run the Python checks with the installed environment:

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s tools/windows -p 'test_*.py' -v
python -m compileall -q ocurisk_lab tools
```

Browser scripts require Playwright and a launchable compatible browser. Read current research/verification/STAGE2* and research/STAGE2_SERVICE.md for actual test scope. Syntax and HTTP checks do not alone verify appearance, phone operation or scientific performance.

## Durable continuation

Additional checkpoints preserve every branch and unfinished working tree, source hashes, Git history, task ownership, test evidence and exact next steps. The current source milestone is packaged; overall research acceptance remains unfinished. Dependencies/build caches are excluded and recreated from recorded versions. A saved checkpoint is not a clinical validation certificate.
