"""Independent analytic adversarial fixtures. SYNTHETIC; no device/clinical validation."""
import copy
import json
import unittest
import numpy as np
from ocurisk_lab import quality

class IndependentAcquisitionQuality(unittest.TestCase):
    def summary(self, images, stamps, capture=None):
        prior=None; rows=[]
        for i,(a,t) in enumerate(zip(images,stamps)):
            rows.append({'frame_index':i,'timestamp_ns':t,'timestamp_source':'STREAM_PTS' if t is not None else 'UNAVAILABLE','quality_metrics':quality.frame_metrics(a,prior,roi=(capture or {}).get('chart_roi'))})
            prior=a
        return quality.summarize_quality(rows,{'codec':'ffv1','stream_bit_rate':None,'format_bit_rate':1000},capture_metadata=capture)
    def test_analytic_rgb_and_fraction_not_faked_exposure(self):
        a=np.array([[[255,40,60],[20,255,60]],[[20,40,255],[20,40,60]]],dtype=np.uint8)
        m=quality.frame_metrics(a)
        self.assertEqual(m['mean_rgb'],[78.75,93.75,108.75])
        self.assertAlmostEqual(m['mean_luma'],78.75*.2126+93.75*.7152+108.75*.0722)
        self.assertEqual(m['clipped_high_fraction'],.75)
        self.assertIsNone(m['laplacian_variance'])
        self.assertIsNone(m['frame_difference_mean'])
        json.dumps(m,allow_nan=False)
    def test_color_scale_changes_brightness_not_chromaticity(self):
        a=np.full((12,12,3),[20,40,60],np.uint8)
        result=self.summary([a,a*2,a*3],[0,50_000_000,100_000_000])
        self.assertGreater(result['metrics']['mean_luma']['std'],0)
        for channel in result['metrics']['rgb_chromaticity']:self.assertAlmostEqual(channel['std'],0)
        self.assertEqual(result['variability_scope'],'SCENE_MOTION_ILLUMINATION_CONFOUNDED')
        self.assertEqual(result['timing']['exact_source_dropped_frames'],'UNKNOWN')
    def test_roi_excludes_moving_background_and_uses_source_grid(self):
        a=np.full((24,24,3),30,np.uint8); b=a.copy();b[:12]=200
        roi={'x':8,'y':12,'width':8,'height':8}
        self.assertGreater(quality.frame_metrics(b,a)['frame_difference_mean'],0)
        m=quality.frame_metrics(b,a,roi=roi)
        self.assertEqual(m['frame_difference_mean'],0)
        self.assertEqual(m['mean_rgb'],[30,30,30]);self.assertEqual(m['roi'],roi)
        for invalid in ({'x':23,'y':0,'width':2,'height':1},{'x':0,'y':0,'width':1.0,'height':1}):
            with self.assertRaises(ValueError):quality.frame_metrics(a,roi=invalid)
    def test_gap_counts_are_estimates_and_do_not_overwrite_actual_count(self):
        a=np.full((8,8,3),70,np.uint8)
        s=self.summary([a]*5,[0,40_000_000,80_000_000,240_000_000,280_000_000])
        self.assertEqual(s['frame_count'],5);self.assertAlmostEqual(s['timing']['effective_fps'],100/7)
        self.assertEqual(s['timing']['interval_seconds']['median'],.04)
        self.assertEqual(s['timing']['gap_events'][0]['nominal_missing_intervals_estimate'],3)
        self.assertEqual(s['repeated_exact_decoded_adjacent_frames'],4)
        self.assertEqual(s['timing']['gap_estimate_scope'],'MEDIAN_INTERVAL_HEURISTIC_NOT_SOURCE_DROP_COUNT')
    def test_missing_timing_and_black_do_not_become_perfect_measurements(self):
        a=np.zeros((8,8,3),np.uint8)
        s=self.summary([a]*4,[0,None,20,20])
        self.assertIsNone(s['timing']['effective_fps']);self.assertEqual(s['timing']['missing_timestamps'],1)
        self.assertEqual(s['timing']['duplicate_timestamps'],1)
        self.assertEqual(s['black_chromaticity_unavailable_frames'],4)
        self.assertTrue(all(c['mean'] is None for c in s['metrics']['rgb_chromaticity']))
        json.dumps(s,allow_nan=False)
    def test_chart_edges_can_trigger_artifact_proxy_without_compression(self):
        a=np.full((24,24,3),40,np.uint8);a[:,8:16]=140
        # Exactly two 100-code transitions on an 8-pixel grid; no encoder involved.
        self.assertAlmostEqual(quality.frame_metrics(a)['block_boundary_excess'],50)
        self.assertAlmostEqual(quality.frame_metrics(np.roll(a,1,axis=1))['block_boundary_excess'],-100/21)
    def test_confounded_comparison_preserves_observed_difference_without_winner(self):
        def rec(method,level):
            c={'connection':{'method':method,'provenance':'USER_DECLARED'},'pair_id':'pair','target_id':'chart','calibration_stationary_asserted':True,'chart_roi':None,'observed_track_settings':{'width':8,'height':8,'frameRate':10},'declared_source_settings':{'provenance':'USER_DECLARED','app_version':'fixture','client_version':'fixture','filters':'none','focus':'fixed','exposure':'fixed','white_balance':'fixed'}}
            a=np.full((8,8,3),level,np.uint8)
            return {'job_id':method,'capture_metadata':c,'acquisition_quality':self.summary([a,a],[0,100_000_000],c)}
        usb,wifi=rec('USB',60),rec('WIFI',90)
        wifi['capture_metadata']['target_id']='different-chart'
        r=quality.compare_recordings([usb,wifi])
        self.assertEqual(r['status'],'INELIGIBLE_CONFOUNDED')
        self.assertIn('UNMATCHED_TARGET_ID',r['ineligibility_reasons'])
        self.assertAlmostEqual(r['differences']['mean_luma']['WIFI_minus_USB'],30)
        self.assertNotIn('winner',r);self.assertEqual(r['difference_scope'],'DESCRIPTIVE_OBSERVED_ONLY_NOT_ATTRIBUTABLE')
        wifi['capture_metadata']['target_id']='chart'
        usb['source_sha256']=wifi['source_sha256']='same-real-source-hash'
        reused=quality.compare_recordings([usb,wifi])
        self.assertIn('REUSED_IDENTICAL_SOURCE_NOT_INDEPENDENT_ACQUISITIONS',reused['ineligibility_reasons'])
        self.assertEqual(reused['status'],'INELIGIBLE_CONFOUNDED')
        wifi['source_sha256']='independent-source-hash'
        wifi['capture_metadata']['recorder_status']='PARTIAL'
        incomplete=quality.compare_recordings([usb,wifi])
        self.assertIn('RECORDER_INCOMPLETE',incomplete['ineligibility_reasons'])
        self.assertEqual(incomplete['status'],'INELIGIBLE_CONFOUNDED')
        self.assertIn('mean_luma',incomplete['differences'])
    def test_no_verified_transport_or_nonfinite_metadata(self):
        for c in ({'connection':{'method':'USB','provenance':'VERIFIED'}},{'browser_video_callbacks':[{'mediaTime':float('nan')}]},{'observed_track_settings':{'frameRate':False}}):
            with self.assertRaises(ValueError):quality.validate_capture_metadata(c)

class IndependentArchivalIntegrity(unittest.TestCase):
    def test_appended_attachment_preserves_history_but_cannot_relabel_current_result(self):
        import io, tempfile, threading, time, urllib.request, urllib.error, zipfile
        from PIL import Image
        from ocurisk_lab.server import create_server
        with tempfile.TemporaryDirectory() as folder:
            server=create_server('127.0.0.1',0,folder)
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            base=f'http://127.0.0.1:{server.server_address[1]}'
            def request(path,value=None,raw=None):
                data=raw if raw is not None else json.dumps(value).encode() if value is not None else None
                with urllib.request.urlopen(urllib.request.Request(base+path,data=data,headers={'Content-Type':'application/octet-stream' if raw is not None else 'application/json'}),timeout=20) as response:
                    payload=response.read()
                    return json.loads(payload) if response.headers.get_content_type()=='application/json' else payload
            try:
                e=request('/api/experiments',{'title':'Independent SYNTHETIC archive fixture','participant_id':'fixture','session_id':'archive','mode':'STATIC','data_origin':'SYNTHETIC','approval_reference':None,'notes':''})
                image=io.BytesIO();Image.new('RGB',(16,16),(70,80,90)).save(image,format='PNG')
                m=request(f'/api/experiments/{e["experiment_id"]}/media/fixture.png',raw=image.getvalue())
                j=request(f'/api/media/{m["media_id"]}/process',{'sample_every':1,'algorithms':['BOUNDARY_Y_RE'],'identity_confirmed':False,'upright_confirmed':False,'annotations':{}})
                for _ in range(200):
                    j=request('/api/jobs/'+j['job_id'])
                    if j['state'] in ('FAILED','COMPLETED','CANCELLED'):break
                    time.sleep(.02)
                self.assertEqual(j['state'],'COMPLETED',j.get('error'))
                before=copy.deepcopy(j['options']['capture_sidecar_snapshot'])
                attachment=b'{"origin":"SYNTHETIC","note":"later actual attachment"}'
                request(f'/api/media/{m["media_id"]}/sidecars/later.json',raw=attachment)
                with self.assertRaises(urllib.error.HTTPError):request('/api/jobs/'+j['job_id'])
                exported=request(f'/api/experiments/{e["experiment_id"]}/export')
                with zipfile.ZipFile(io.BytesIO(exported)) as archive:
                    historical=json.loads(archive.read(f'jobs/{j["job_id"]}/job.json'))
                    self.assertEqual(historical['options']['capture_sidecar_snapshot'],before)
                    self.assertEqual(archive.read(f'media/{m["media_id"]}/sidecars/later.json'),attachment)
                j['result']['acquisition_quality']['frame_count']=9000
                server.store.update_job(j)
                with self.assertRaises(urllib.error.HTTPError):request(f'/api/experiments/{e["experiment_id"]}/export')
            finally:
                server.shutdown();server.jobs.shutdown();server.server_close()

if __name__=='__main__':unittest.main()
