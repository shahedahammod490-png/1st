import math
import unittest
from ocurisk_lab.evaluation import regression_metrics, classification_metrics, audit_partition


class EvaluationTests(unittest.TestCase):
    def test_independent_numeric_reference(self):
        result = regression_metrics([(2, 1), (1, 2), (5, 3)])
        self.assertAlmostEqual(result['mae'], 4 / 3)
        self.assertAlmostEqual(result['rmse'], math.sqrt(2))
        self.assertAlmostEqual(result['bias'], 2 / 3)
        self.assertAlmostEqual(result['sample_sd_error'], math.sqrt(7 / 3))

    def test_empty_and_one_do_not_invent_variance(self):
        self.assertIsNone(regression_metrics([])['mae'])
        self.assertIsNone(regression_metrics([(0, 0)])['limits_of_agreement_95_normal'])
        self.assertEqual(regression_metrics([(0, 0)])['mae'], 0)
        with self.assertRaises(ValueError):
            regression_metrics([(float('nan'), 0)])

    def test_large_finite_error_stable_rmse_and_overflow_rejected(self):
        result = regression_metrics([(1e200, 0), (1e200, 0)])
        self.assertEqual(result['rmse'], 1e200)
        self.assertTrue(all(math.isfinite(value) for key, value in result.items() if isinstance(value, float)))
        for pair in [(1e308, -1e308), (10**1000, 0), ('2', 0), (True, 0)]:
            with self.subTest(pair=pair), self.assertRaises(ValueError):
                regression_metrics([pair])

    def test_empty_partition_has_no_integrity_evidence(self):
        result = audit_partition([])
        self.assertEqual(result['records'], 0)
        self.assertIsNone(result['partition_integrity_pass'])

    def test_abstention_and_undefined_denominators(self):
        r = classification_metrics([(True, True), (False, False), (None, True)])
        self.assertEqual(r['coverage'], 2 / 3)
        self.assertEqual(r['abstained'], 1)
        self.assertEqual(r['sensitivity_accepted'], 1)
        self.assertIsNone(classification_metrics([(None, True)])['sensitivity_accepted'])
        with self.assertRaises(ValueError):
            classification_metrics([(1, True)])

    def test_participant_and_exact_duplicate_leakage(self):
        r = audit_partition([{'participant_id':'p1','split':'train','sha256':['a'*64]},
                             {'participant_id':'p1','split':'test','sha256':['a'*64]}])
        self.assertFalse(r['partition_integrity_pass'])
        self.assertEqual(len(r['issues']), 2)

    def test_both_eyes_same_subject_allowed_same_partition(self):
        r = audit_partition([{'participant_id':'p1','split':'train','sha256':['a'*64]},
                             {'participant_id':'p1','split':'train','sha256':['b'*64]}])
        self.assertTrue(r['partition_integrity_pass'])


if __name__ == '__main__':
    unittest.main()
