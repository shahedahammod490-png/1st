"""SYNTHETIC image engineering fixtures only; no optical or clinical evidence."""
import hashlib
import json
import math
from pathlib import Path
import tempfile
import unittest

import numpy as np
from PIL import Image

from ocurisk_lab.optical import analyze_frame


def circle(cx=64, cy=64, radius=40):
    return {"cx_px": cx, "cy_px": cy, "radius_px": radius, "source": "MANUAL_ANNOTATION"}


class SyntheticOpticalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.image = self.root / 'SYNTHETIC.png'

    def tearDown(self):
        self.temp.cleanup()

    def run_image(self, data, eyes=None, config=None, output='out'):
        Image.fromarray(np.asarray(data, dtype=np.uint8)).save(self.image)
        return analyze_frame(self.image, eyes or {"OD": circle(), "OS": None}, self.root/output, config)

    def test_missing_is_null_not_numeric_fallback(self):
        result = self.run_image(np.full((128,128,3),90), {"OD":None,"OS":None})
        for record in result['eyes'].values():
            self.assertEqual(record['status'],'INCONCLUSIVE')
            self.assertEqual(record['artifacts'],{})
            self.assertIsNone(record['prediction'])
            self.assertIsNone(record['uncertainty'])
            self.assertTrue(all(m['value'] is None for m in record['measurements'].values()))
        json.dumps(result,allow_nan=False)

    def test_uniform_colors_reject_background_candidate_even_edge_clipped(self):
        for color in ([0,0,0],[90,90,90],[255,255,255],[200,20,20]):
            for annotation in (circle(),circle(0,0,40)):
                with self.subTest(color=color,annotation=annotation):
                    result = self.run_image(np.tile(color,(128,128,1)), {'OD':annotation,'OS':None})['eyes']['OD']
                    m = result['measurements']
                    self.assertEqual(m['candidate_crescent_fraction']['value'],0)
                    self.assertEqual(m['glint_candidate_fraction']['value'],0)
                    self.assertEqual(m['gradient_magnitude']['value'],0)
                    self.assertIsNone(m['gradient_angle']['value'])
                    self.assertIsNone(m['clinical_gradability']['value'])
                    with Image.open(self.root/'out'/result['artifacts']['candidate_crescent_mask']) as image:
                        self.assertFalse(np.asarray(image).any())
                    if annotation['cx_px'] == 0:
                        self.assertIn('ANNOTATED_CIRCLE_EDGE_CLIPPED_DIAGNOSTICS_ONLY',result['reasons'])
                        self.assertEqual(result['status'],'INCONCLUSIVE')
                        self.assertEqual(result['feature_validity'],'INVALID_EDGE_CLIPPED_MANUAL_ANNOTATION')
                        self.assertTrue(all(item['validity']=='DIAGNOSTIC_ONLY_INVALID_MANUAL_ANNOTATION' for item in m.values()))
                    # Legacy floor is explicitly not our candidate area.
                    expected_old = None if annotation['cy_px'] == 0 else 0.08
                    self.assertEqual(m['ADAPTED_OLD_brightness_ratio']['value'],expected_old)

    def test_analytic_gradient_normalized_radius_sign_units_and_polar_angle(self):
        yy,xx = np.mgrid[:128,:128]
        # Code values exactly planar: +1 code/pixel right, +2 code/pixel down.
        plane = 60 + xx + 2*yy
        # Use smaller radius/center to avoid saturation in actual annotated samples.
        data = np.repeat(np.clip(plane,0,255)[...,None],3,axis=2)
        result = self.run_image(data,{'OD':circle(40,40,20),'OS':None})['eyes']['OD']
        m = result['measurements']
        self.assertAlmostEqual(m['gradient_x']['value'],20/255,places=8)
        self.assertAlmostEqual(m['gradient_y']['value'],40/255,places=8)
        self.assertEqual(m['gradient_x']['unit'],'Y_fraction_per_annotated_radius')
        self.assertAlmostEqual(m['gradient_angle']['value'],math.degrees(math.atan2(2,1)),places=8)
        polar = np.array(m['polar_Y']['value'])
        self.assertEqual(polar.shape,(16,72))
        radii = np.array(m['polar_radius_centers']['value'])
        angles = np.deg2rad(m['polar_angle_centers']['value'])
        expected = 180/255 + radii[:,None]*(20/255*np.cos(angles)+40/255*np.sin(angles))
        np.testing.assert_allclose(polar,expected,atol=1e-12)
        with Image.open(self.root/'out'/result['artifacts']['polar']) as image:
            self.assertEqual(image.size,(72,16))

    def test_gradient_left_up_orientation(self):
        yy,xx = np.mgrid[:128,:128]
        plane = 255-xx-yy
        data = np.repeat(plane[...,None],3,axis=2)
        m = self.run_image(data)['eyes']['OD']['measurements']
        self.assertAlmostEqual(m['gradient_x']['value'],-40/255,places=8)
        self.assertAlmostEqual(m['gradient_y']['value'],-40/255,places=8)
        self.assertAlmostEqual(m['gradient_angle']['value'],225,places=8)

    def test_small_glint_exclusion_and_large_bright_region_not_glint(self):
        data = np.full((128,128,3),40,dtype=np.uint8)
        data[58:61,58:61] = 255
        data[54:57,70:73] = 255
        result = self.run_image(data)['eyes']['OD']
        self.assertEqual(result['measurements']['glint_candidate_component_count']['value'],2)
        with Image.open(self.root/'out'/result['artifacts']['feature_analysis_mask']) as image:
            mask = np.asarray(image)>0
        with Image.open(self.root/'out'/result['artifacts']['glint_candidate_mask']) as image:
            glint = np.asarray(image)>0
        self.assertFalse((mask & glint).any())
        data[30:100,30:100] = 255
        result = self.run_image(data)['eyes']['OD']
        self.assertEqual(result['measurements']['glint_candidate_fraction']['value'],0)

    def test_connected_candidate_touching_boundary_not_internal_blob(self):
        yy,xx = np.mgrid[:128,:128]
        disk = (xx-64)**2 + (yy-64)**2 <= 40**2
        data = np.full((128,128,3),40,dtype=np.uint8)
        data[disk & (yy>88)] = [190,30,30]
        result = self.run_image(data)['eyes']['OD']
        self.assertGreater(result['measurements']['candidate_crescent_fraction']['value'],0)
        self.assertEqual(result['measurements']['candidate_crescent_component_count']['value'],1)
        data = np.full((128,128,3),40,dtype=np.uint8)
        data[60:68,60:68] = [190,30,30]
        result = self.run_image(data)['eyes']['OD']
        self.assertEqual(result['measurements']['candidate_crescent_fraction']['value'],0)

    def test_independent_anatomical_eyes_no_spatial_label_guess(self):
        data = np.full((128,256,3),30,dtype=np.uint8)
        data[:,128:] = [120,10,10]
        eyes = {'OD':circle(190,64,35),'OS':circle(60,64,35)}
        both = self.run_image(data,eyes)['eyes']
        od_only = self.run_image(data,{'OD':eyes['OD'],'OS':None},output='od')['eyes']['OD']
        self.assertEqual(both['OD'],od_only)
        self.assertGreater(both['OD']['measurements']['mean_RD']['value'],both['OS']['measurements']['mean_RD']['value'])
        self.assertIsNone(both['OD']['prediction'])

    def test_edge_clipping_keeps_missing_polar_null_and_outside_empty(self):
        data = np.full((128,128,3),100,dtype=np.uint8)
        record = self.run_image(data,{'OD':circle(0,64,40),'OS':circle(-100,64,20)})['eyes']
        self.assertGreater(record['OD']['measurements']['valid_pupil_fraction']['value'],0)
        self.assertLess(record['OD']['measurements']['valid_pupil_fraction']['value'],1)
        self.assertTrue(any(v is None for row in record['OD']['measurements']['polar_Y']['value'] for v in row))
        self.assertEqual(record['OS']['status'],'INCONCLUSIVE')
        self.assertIsNone(record['OS']['measurements']['candidate_crescent_fraction']['value'])

    def test_deterministic_json_and_artifact_bytes_all_pngs_present(self):
        yy,xx = np.mgrid[:128,:128]
        data = np.stack((xx,yy,np.full_like(xx,30)),axis=2)
        first = self.run_image(data,output='first')
        second = analyze_frame(self.image,{'OD':circle(),'OS':None},self.root/'second')
        self.assertEqual(json.dumps(first,sort_keys=True,allow_nan=False),json.dumps(second,sort_keys=True,allow_nan=False))
        required = {'raw_crop','normalized_crop','pupil_mask','glint_candidate_mask','candidate_crescent_mask','RD','RE','Y','gradient','polar'}
        self.assertTrue(required <= set(first['eyes']['OD']['artifacts']))
        for name in first['eyes']['OD']['artifacts'].values():
            self.assertEqual(Path(name).name,name)
            self.assertEqual(hashlib.sha256((self.root/'first'/name).read_bytes()).digest(),hashlib.sha256((self.root/'second'/name).read_bytes()).digest())

    def test_invalid_inputs_rejected_nan_json_unsupported_domains(self):
        Image.fromarray(np.zeros((128,128,3),dtype=np.uint8)).save(self.image)
        cases = [({'OD':circle(radius=0),'OS':None},None),({'OD':circle(cx=float('nan')),'OS':None},None),({'OD':circle(radius=float('inf')),'OS':None},None),({'OD':circle(cx=True),'OS':None},None),({'OD':circle(cx=1e100),'OS':None},None),({'OD':circle(),'OS':circle(radius=1e100)},None),({'OD':circle(),'OS':None},{'candidate_min_contrast':float('nan')}),({'OD':circle(),'OS':None},{'rd_epsilon':1e-320}),({'OD':circle(),'OS':None},{'normalized_size':144}),({'OD':circle(),'OS':None},{'glint_max_pupil_fraction':1.2}),({'OD':circle(),'OS':None},{'polar_angular_bins':71}),({'OD':circle(),'OS':None},{'unknown':0}),({'OD':circle(),'OS':None},{'adapted_old_brightness_ratio':1}),({'OD':{**circle(),'source':'AUTOMATIC'},'OS':None},None),({'OD':None},None)]
        for i,(eyes,config) in enumerate(cases):
            output = self.root/f'invalid_{i}'
            with self.subTest(i=i), self.assertRaises(ValueError):
                analyze_frame(self.image,eyes,output,config)
            self.assertFalse(output.exists())

    def test_anatomical_annotation_conflict_identical_intersecting_contained_but_not_tangent(self):
        data = np.full((128,128,3),75,dtype=np.uint8)
        conflicts = [
            {'OD':circle(),'OS':circle()},
            {'OD':circle(40,64,20),'OS':circle(70,64,20)},
            {'OD':circle(64,64,40),'OS':circle(64,64,10)},
        ]
        for eyes in conflicts:
            with self.subTest(eyes=eyes):
                result = self.run_image(data,eyes)
                for record in result['eyes'].values():
                    self.assertEqual(record['status'],'INCONCLUSIVE')
                    self.assertIn('ANATOMICAL_ANNOTATION_CONFLICT',record['reasons'])
                    self.assertEqual(record['feature_validity'],'INVALID_OVERLAPPING_ANATOMICAL_MANUAL_ANNOTATIONS')
                    self.assertEqual(record['artifact_validity'],'DIAGNOSTIC_ONLY_ANATOMICAL_ANNOTATION_CONFLICT')
                    self.assertTrue(record['artifacts'])
                    self.assertTrue(all(item['validity']=='DIAGNOSTIC_ONLY_ANATOMICAL_ANNOTATION_CONFLICT' for item in record['measurements'].values()))
                    self.assertIsNone(record['prediction'])
        tangent = self.run_image(data,{'OD':circle(40,64,20),'OS':circle(80,64,20)})
        for record in tangent['eyes'].values():
            self.assertEqual(record['status'],'FEATURES_COMPUTED')
            self.assertNotIn('ANATOMICAL_ANNOTATION_CONFLICT',record['reasons'])

    def test_named_master_channel_features_and_epsilon(self):
        color = [128,32,64]
        record = self.run_image(np.tile(color,(128,128,1)))['eyes']['OD']
        m = record['measurements']
        self.assertAlmostEqual(m['mean_RD']['value'],128/49,places=10)
        self.assertAlmostEqual(m['mean_RE']['value'],80/255,places=10)
        self.assertAlmostEqual(m['mean_Y']['value'],88/255,places=10)
        altered = self.run_image(np.tile(color,(128,128,1)),config={'rd_epsilon':2/255})['eyes']['OD']
        self.assertAlmostEqual(altered['measurements']['mean_RD']['value'],128/50,places=10)

    def test_replay_cli_source_hashes_artifact_bytes_and_no_overwrite(self):
        import subprocess
        import sys
        Image.fromarray(np.full((128,128,3),70,dtype=np.uint8)).save(self.image)
        eyes_file = self.root/'SYNTHETIC_eyes.json'
        eyes_file.write_text(json.dumps({'OD':circle(),'OS':None}),encoding='utf-8')
        output = self.root/'replay'
        tool = Path(__file__).resolve().parents[1]/'tools'/'replay.py'
        command = [sys.executable,str(tool),'--image',str(self.image),'--eyes-json',str(eyes_file),'--output-dir',str(output)]
        process = subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(process.returncode,0,process.stderr)
        report = json.loads((output/'replay_report.json').read_text())
        self.assertTrue(report['result_json_identical'])
        self.assertTrue(report['artifact_bytes_identical'])
        self.assertEqual(report['source_sha256'],hashlib.sha256(self.image.read_bytes()).hexdigest())
        for name,digest in report['artifact_sha256'].items():
            self.assertEqual(hashlib.sha256((output/'artifacts'/name).read_bytes()).hexdigest(),digest)
        self.assertNotEqual(subprocess.run(command,capture_output=True).returncode,0)

    def test_pupil_mask_excludes_background_features(self):
        yy,xx = np.mgrid[:128,:128]
        disk = (xx-64)**2+(yy-64)**2 <= 41**2
        data = np.full((128,128,3),255,dtype=np.uint8)
        data[disk] = 60
        record = self.run_image(data)['eyes']['OD']
        self.assertEqual(record['measurements']['candidate_crescent_fraction']['value'],0)
        self.assertEqual(record['measurements']['mean_RE']['value'],0)


if __name__ == '__main__':
    unittest.main()
