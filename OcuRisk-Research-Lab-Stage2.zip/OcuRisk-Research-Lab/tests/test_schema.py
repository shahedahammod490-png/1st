import copy
import unittest

from ocurisk_lab.schema import ValidationError, validate_manifest


def manifest():
    return {'schema_version': '1.0', 'capture_id': 'capture_1', 'participant_id': 'p', 'session_id': 's', 'device_id': 'd', 'mode': 'CONTROL', 'data_origin': 'SYNTHETIC', 'approval_reference': None, 'illumination': {'requested': 'UNKNOWN', 'reported': 'UNKNOWN', 'physical_verified': False, 'evidence_id': None}, 'distance_m': None, 'phone_pose': None, 'head_pose': None, 'mirrored': None, 'image_rotation_deg': None, 'timestamp_source': 'UNAVAILABLE', 'frames': [{'frame_index': 0, 'timestamp_ns': None, 'source_file': 'source.png', 'sha256': '0'*64, 'eyes': {'OD': {'cx_px': 0, 'cy_px': 0, 'radius_px': 1, 'source': 'MANUAL_ANNOTATION'}, 'OS': None}}]}


class SchemaTests(unittest.TestCase):
    def test_missingness_and_zero_preserved(self):
        data = manifest()
        data['phone_pose'] = {'yaw': 0}
        data['image_rotation_deg'] = 0
        self.assertIs(validate_manifest(data), data)
        self.assertEqual(data['frames'][0]['eyes']['OD']['cx_px'], 0)
        self.assertIsNone(data['frames'][0]['eyes']['OS'])
        self.assertIsNone(data['distance_m'])

    def test_invalid_fields_and_values_rejected(self):
        mutations = [lambda m: m.update(capture_id='../bad'), lambda m: m.update(device_id='é'), lambda m: m.update(distance_m=0), lambda m: m.update(distance_m=float('nan')), lambda m: m.update(phone_pose={'x': float('inf')}), lambda m: m.update(phone_pose={'x': 10**1000}), lambda m: m.update(mirrored=0), lambda m: m.update(image_rotation_deg=True), lambda m: m.update(data_origin='REAL_APPROVED'), lambda m: m['illumination'].update(physical_verified=True), lambda m: m['frames'][0].update(frame_index=True), lambda m: m['frames'][0].update(timestamp_ns='1.2'), lambda m: m['frames'][0].update(source_file='..\\source.png'), lambda m: m['frames'][0]['eyes'].pop('OS'), lambda m: m['frames'][0]['eyes']['OD'].update(radius_px=0), lambda m: m['frames'][0]['eyes']['OD'].update(cx_px=float('inf')), lambda m: m['frames'][0]['eyes']['OD'].update(source='AUTOMATIC'), lambda m: m.update(unexpected=True)]
        for mutation in mutations:
            data=manifest()
            mutation(data)
            with self.subTest(data=data), self.assertRaises(ValidationError):
                validate_manifest(data)

    def test_known_timestamps_strictly_increase_across_missing(self):
        data=manifest()
        data['frames'][0]['timestamp_ns']='0'
        for index,timestamp in ((1,None),(2,'1')):
            frame=copy.deepcopy(data['frames'][0]);frame.update(frame_index=index,timestamp_ns=timestamp,source_file=f'f{index}.png',sha256=str(index)*64);data['frames'].append(frame)
        validate_manifest(data)
        data['frames'][2]['timestamp_ns']='0'
        with self.assertRaises(ValidationError):
            validate_manifest(data)

    def test_real_approval_and_claimed_verification_require_references(self):
        data=manifest();data.update(data_origin='REAL_APPROVED',approval_reference='study-approval-record')
        data['illumination'].update(physical_verified=True,evidence_id='measurement_1')
        validate_manifest(data)


if __name__=='__main__':
    unittest.main()
