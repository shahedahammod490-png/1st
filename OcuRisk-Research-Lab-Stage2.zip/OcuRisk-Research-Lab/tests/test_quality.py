"""Explicit synthetic engineering fixtures; no hardware or clinical evidence."""
import copy
import json
import unittest
import numpy as np
from PIL import Image, ImageFilter
from ocurisk_lab import quality as q

class QualityTests(unittest.TestCase):
    def record(self,a,t=0,i=0,roi=None):
        return {'frame_index':i,'timestamp_ns':t,'timestamp_source':'STREAM_PTS' if t is not None else 'UNAVAILABLE','quality_metrics':q.frame_metrics(a,roi=roi)}
    def test_analytic_color_clipping(self):
        a=np.zeros((16,16,3),dtype=np.uint8); a[:]=[255,100,50]
        m=q.frame_metrics(a)
        self.assertAlmostEqual(m['mean_luma'],255*.2126+100*.7152+50*.0722)
        self.assertEqual(m['mean_rgb'],[255.,100.,50.]); self.assertEqual(m['clipped_high_fraction'],1)
        self.assertEqual(m['clipped_low_fraction'],0); self.assertEqual(m['laplacian_variance'],0)
        self.assertIsNone(m['frame_difference_mean']); json.dumps(m,allow_nan=False)
    def test_blur_order_fixed_scene(self):
        yy,xx=np.indices((64,64)); a=np.repeat((((xx//4+yy//4)%2)*200+20).astype(np.uint8)[...,None],3,axis=2)
        blurred=np.array(Image.fromarray(a).filter(ImageFilter.GaussianBlur(2)))
        self.assertGreater(q.frame_metrics(a)['laplacian_variance'],q.frame_metrics(blurred)['laplacian_variance'])
    def test_roi_and_first_mismatch(self):
        a=np.full((16,16,3),100,dtype=np.uint8)
        self.assertEqual(q.frame_metrics(a,roi={'x':2,'y':3,'width':5,'height':5})['scope'],'CHART_ROI')
        with self.assertRaises(ValueError): q.frame_metrics(a,roi={'x':15,'y':0,'width':2,'height':2})
        self.assertIsNone(q.frame_metrics(a,np.zeros((2,2,3),dtype=np.uint8))['frame_difference_mean'])
        self.assertEqual(q.frame_metrics(a,a)['frame_difference_mean'],0)
    def test_timing_gap_vfr(self):
        a=np.full((16,16,3),100,dtype=np.uint8)
        s=q.summarize_quality([self.record(a,t,i) for i,t in enumerate([0,100000000,200000000,500000000])],{'codec':'ffv1'})
        self.assertEqual(s['frame_count'],4); self.assertEqual(s['timing']['effective_fps'],6)
        self.assertEqual(len(s['timing']['gap_events']),1); self.assertEqual(s['timing']['gap_events'][0]['nominal_missing_intervals_estimate'],2)
        self.assertEqual(s['timing']['exact_source_dropped_frames'],'UNKNOWN'); self.assertEqual(s['repeated_exact_decoded_adjacent_frames'],3)
    def test_missing_duplicate_nonmonotonic(self):
        a=np.zeros((2,2,3),dtype=np.uint8)
        for ts in ([None],[0,0],[10,0],[0,None,20]):
            s=q.summarize_quality([self.record(a,t,i) for i,t in enumerate(ts)],{'kind':'IMAGE'})
            self.assertIsNone(s['timing']['effective_fps']); json.dumps(s,allow_nan=False)
        self.assertEqual(s['black_chromaticity_unavailable_frames'],3)
        self.assertIsNone(s['metrics']['rgb_chromaticity'][0]['mean'])
    def test_ramp_small_empty(self):
        a=np.repeat(np.tile(np.arange(16,dtype=np.uint8),(16,1))[...,None],3,axis=2)
        self.assertAlmostEqual(q.frame_metrics(a)['laplacian_variance'],0)
        self.assertEqual(q.summarize_quality([], {})['frame_count'],0)
        self.assertIsNone(q.frame_metrics(np.zeros((1,1,3),dtype=np.uint8))['edge_strength'])
    def test_config_validation(self):
        for cfg in ({'gap_factor':True},{'gap_factor':float('nan')},{'oops':1},{'clip_low_code':250},{'warning_clipped_fraction':2}):
            with self.assertRaises(ValueError): q.validate_config(cfg)
        with self.assertRaises(ValueError): q.frame_metrics(np.zeros((2,2,3),dtype=float))
    def test_comparison_match_and_confounds(self):
        roi={'x':0,'y':0,'width':16,'height':16}; a=np.full((16,16,3),100,dtype=np.uint8)
        def rec(method):
            c={'pair_id':'p','target_id':'chart','chart_roi':roi,'calibration_stationary_asserted':True,'declared_source_settings':{'provenance':'USER_DECLARED','app_version':'fixture','client_version':'fixture','filters':'none','focus':'locked','exposure':'locked','white_balance':'locked'},'observed_track_settings':{'width':16,'height':16,'frameRate':10},'connection':{'method':method,'provenance':'USER_DECLARED'}}
            s=q.summarize_quality([self.record(a,0,0,roi),self.record(a,100000000,1,roi)],{'codec':'ffv1'},capture_metadata=c)
            return {'job_id':method,'acquisition_quality':s,'capture_metadata':c}
        usb,wifi=rec('USB'),rec('WIFI'); report=q.compare_recordings([usb,wifi])
        self.assertEqual(report['status'],'ELIGIBLE_DESCRIPTIVE_COMPARISON'); self.assertEqual(report['differences']['mean_luma']['WIFI_minus_USB'],0)
        for field,value in [('target_id','other'),('pair_id',None),('chart_roi',None),('calibration_stationary_asserted',False)]:
            bad=copy.deepcopy(wifi); bad['capture_metadata'][field]=value
            confounded=q.compare_recordings([usb,bad])
            self.assertEqual(confounded['status'],'INELIGIBLE_CONFOUNDED')
            self.assertIn('mean_luma',confounded['differences'])
        for partial in ({'recorder_status':'PARTIAL'}, {'recorder_status':'ERROR'}, {'recorder_status':'COMPLETE','recorder_error':'capture failure'}):
            bad=copy.deepcopy(wifi); bad['capture_metadata'].update(partial)
            report=q.compare_recordings([usb,bad])
            self.assertEqual(report['status'],'INELIGIBLE_CONFOUNDED')
            self.assertIn('RECORDER_INCOMPLETE',report['ineligibility_reasons'])
            self.assertIn('mean_luma',report['differences'])
        usb['source_sha256']=wifi['source_sha256']='a'*64
        self.assertIn('REUSED_IDENTICAL_SOURCE_NOT_INDEPENDENT_ACQUISITIONS',q.compare_recordings([usb,wifi])['ineligibility_reasons'])
        del usb['source_sha256']; del wifi['source_sha256']
        for r in (usb,wifi):
            r['capture_metadata']['chart_roi']=None
        self.assertEqual(q.compare_recordings([usb,wifi])['status'],'ELIGIBLE_DESCRIPTIVE_COMPARISON')
    def test_block_grid_chromaticity_and_motion(self):
        a=np.full((32,32,3),50,dtype=np.uint8); a[:,8:16]=150; a[:,24:]=150
        self.assertGreater(q.frame_metrics(a)['block_boundary_excess'],0)
        red=np.full((32,32,3),[100,50,50],dtype=np.uint8); blue=np.full((32,32,3),[50,50,100],dtype=np.uint8)
        s=q.summarize_quality([self.record(red,0,0),self.record(blue,100000000,1)],{})
        self.assertGreater(s['metrics']['rgb_chromaticity'][0]['std'],0)
        self.assertIsNone(s['motion_sharpness_association']['pearson_correlation'])
        self.assertEqual(q.frame_metrics(red,blue)['frame_difference_mean'],100/3)
        self.assertEqual(len(s['provenance']['config_sha256']),64)

    def test_capture_validation(self):
        for c in ({'observed_track_settings':{'frameRate':True}}, {'recorder_bytes':True}, {'connection':{'method':'USB'}},{'calibration_stationary_asserted':1},{'browser_video_callbacks':[{'mediaTime':float('inf')}]},{'chart_roi':{'x':0,'y':0,'width':True,'height':3}}):
            with self.assertRaises(ValueError): q.validate_capture_metadata(c)

if __name__=='__main__': unittest.main()
