import base64
import copy
import hashlib
import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from PIL import Image

from ocurisk_lab.schema import ValidationError
from ocurisk_lab.server import MAX_REQUEST_BYTES, create_server, strict_json
from ocurisk_lab.store import Store


def payload(capture_id='capture_1', color=(12,24,36)):
    stream=io.BytesIO();Image.new('RGB',(32,24),color).save(stream,format='PNG');raw=stream.getvalue()
    manifest={'schema_version':'1.0','capture_id':capture_id,'participant_id':'p','session_id':'s','device_id':'d','mode':'CONTROL','data_origin':'SYNTHETIC','approval_reference':None,'illumination':{'requested':'UNKNOWN','reported':'UNKNOWN','physical_verified':False,'evidence_id':None},'distance_m':None,'phone_pose':None,'head_pose':None,'mirrored':None,'image_rotation_deg':None,'timestamp_source':'UNAVAILABLE','frames':[{'frame_index':0,'timestamp_ns':None,'source_file':'source.png','sha256':hashlib.sha256(raw).hexdigest(),'eyes':{'OD':{'cx_px':0,'cy_px':0,'radius_px':3,'source':'MANUAL_ANNOTATION'},'OS':None}}]}
    return {'manifest':manifest,'files':[{'name':'source.png','base64':base64.b64encode(raw).decode()}]}


def mock_analyzer(image_path, eyes, output_dir, config=None):
    records={}
    for eye,annotation in eyes.items():
        if annotation is None:
            records[eye]={'status':'INCONCLUSIVE','reasons':['MISSING_ANNOTATION'],'measurements':{'candidate':{'value':None,'unit':'arbitrary'}},'artifacts':{},'prediction':None,'uncertainty':None}
        else:
            name=f'{eye}_raw.png'
            with Image.open(image_path) as image:
                image.save(output_dir/name)
            records[eye]={'status':'FEATURES_COMPUTED','reasons':[],'measurements':{'candidate':{'value':0,'unit':'arbitrary'}},'artifacts':{'raw':name},'prediction':None,'uncertainty':None}
    return {'algorithm_id':'SYNTHETIC_TEST_BOUNDARY','algorithm_version':'1','config':{},'eyes':records}


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=Store(self.temp.name,mock_analyzer)

    def test_empty_import_roundtrip_persistence_process_export_data(self):
        self.assertEqual(self.store.captures(),[]);self.assertEqual(self.store.runs(),[])
        data=payload();self.store.import_capture(data)
        self.assertEqual(Store(self.temp.name).capture('capture_1'),data['manifest'])
        run=self.store.process('capture_1')
        self.assertEqual(self.store.run(run['run_id']),run)
        self.assertEqual(run['frames'][0]['analysis']['eyes']['OD']['measurements']['candidate']['value'],0)
        self.assertIsNone(run['frames'][0]['analysis']['eyes']['OS']['measurements']['candidate']['value'])
        self.assertTrue(self.store.artifact_path(run['run_id'],'f0__OD_raw.png').is_file())
        second=self.store.process('capture_1');self.assertNotEqual(run['run_id'],second['run_id']);self.assertEqual(self.store.run(run['run_id']),run)

    def test_hash_failure_duplicate_and_decode_failure_are_atomic(self):
        bad=payload();bad['files'][0]['base64']=base64.b64encode(b'not image').decode()
        for update_hash in (False,True):
            if update_hash:bad['manifest']['frames'][0]['sha256']=hashlib.sha256(b'not image').hexdigest()
            with self.assertRaises(ValidationError):self.store.import_capture(bad)
            self.assertEqual(self.store.captures(),[])
            self.assertEqual(list(self.store.captures_dir.iterdir()),[])
        self.store.import_capture(payload())
        with self.assertRaises(ValidationError):self.store.import_capture(payload('different'))
        self.assertEqual(len(self.store.captures()),1)
        self.assertFalse((self.store.captures_dir/'different').exists())

    def test_frame_isolation_and_known_timestamp_zero(self):
        data=payload();extra=payload('other',(45,67,89));frame=extra['manifest']['frames'][0];frame.update(frame_index=7,source_file='second.png',timestamp_ns='1',eyes={'OD':None,'OS':{'cx_px':5,'cy_px':5,'radius_px':2,'source':'MANUAL_ANNOTATION'}});data['manifest']['frames'][0]['timestamp_ns']='0';data['manifest']['frames'].append(frame);extra['files'][0]['name']='second.png';data['files'].append(extra['files'][0]);self.store.import_capture(data);run=self.store.process('capture_1')
        self.assertEqual([f['timestamp_ns'] for f in run['frames']],['0','1'])
        self.assertEqual(set(run['artifact_files']),{'f0__OD_raw.png','f7__OS_raw.png'})
        self.assertEqual(run['frames'][1]['analysis']['eyes']['OD']['artifacts'],{})

    def test_failed_processing_or_tampered_source_has_no_completed_run(self):
        self.store.import_capture(payload())
        def broken(*args,**kwargs):raise RuntimeError('test failure')
        self.store.analyzer=broken
        with self.assertRaises(RuntimeError):self.store.process('capture_1')
        self.assertEqual(self.store.runs(),[]);self.assertEqual(list(self.store.runs_dir.iterdir()),[])
        self.store.analyzer=mock_analyzer;self.store.image_path('capture_1','source.png').write_bytes(b'tampered')
        with self.assertRaises(ValidationError):self.store.process('capture_1')
        self.assertEqual(self.store.runs(),[])

    def test_nonfinite_result_and_unsafe_artifact_not_persisted(self):
        self.store.import_capture(payload())
        for unsafe in (False,True):
            def bad(*args,**kwargs):
                result=mock_analyzer(*args,**kwargs)
                if unsafe:result['eyes']['OD']['artifacts']['raw']='../lab.sqlite3'
                else:result['eyes']['OD']['measurements']['candidate']['value']=float('nan')
                return result
            self.store.analyzer=bad
            with self.assertRaises(ValidationError):self.store.process('capture_1')
            self.assertEqual(self.store.runs(),[])

    def test_all_alpha_bearing_images_rejected_including_opaque(self):
        for alpha in (0,255):
            data=payload();stream=io.BytesIO();Image.new('RGBA',(32,24),(1,2,3,alpha)).save(stream,format='PNG');raw=stream.getvalue()
            data['manifest']['frames'][0]['sha256']=hashlib.sha256(raw).hexdigest();data['files'][0]['base64']=base64.b64encode(raw).decode()
            with self.assertRaises(ValidationError):self.store.import_capture(data)
            self.assertEqual(self.store.captures(),[])

    def test_actual_optical_boundary_and_source_hashes(self):
        self.store.analyzer=None;data=payload();data['manifest']['frames'][0]['eyes']['OD'].update(cx_px=16,cy_px=12,radius_px=5)
        self.store.import_capture(data);run=self.store.process('capture_1')
        self.assertFalse(run['execution_fingerprint']['injected_test_boundary'])
        for relative,digest in run['source_hashes'].items():
            self.assertEqual(hashlib.sha256((Path(__file__).resolve().parents[1]/relative).read_bytes()).hexdigest(),digest)
        self.assertGreater(len(run['artifact_files']),0)
        self.assertIsNone(run['frames'][0]['analysis']['eyes']['OS']['prediction'])
        second=self.store.process('capture_1')
        self.assertEqual(run['source_hashes'],second['source_hashes'])
        self.assertEqual(run['execution_fingerprint'],second['execution_fingerprint'])
        self.assertEqual(run['frames'],second['frames'])

    def test_optical_import_time_source_hash_mismatch_rejects_run(self):
        from ocurisk_lab import optical
        self.store.analyzer=None;self.store.import_capture(payload())
        with patch.object(optical,'SOURCE_SHA256_AT_IMPORT','0'*64):
            with self.assertRaisesRegex(ValidationError,'Optical source changed'):
                self.store.process('capture_1')
        self.assertEqual(self.store.runs(),[])


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.server=create_server('127.0.0.1',0,self.temp.name,mock_analyzer)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.cleanup)

    def cleanup(self):
        self.server.shutdown();self.server.server_close();self.thread.join();self.temp.cleanup()

    def request(self,method,path,body=None,headers=None,raw=False):
        conn=http.client.HTTPConnection('127.0.0.1',self.server.server_address[1],timeout=5)
        args={'Content-Type':'application/json'};args.update(headers or {})
        body=json.dumps(body).encode() if body is not None and not raw else body
        conn.request(method,path,body=body,headers=args);response=conn.getresponse();data=response.read();status=response.status;ctype=response.getheader('Content-Type');conn.close()
        return status,json.loads(data) if ctype.startswith('application/json') else data

    def test_actual_http_import_process_inspect_artifact_export(self):
        self.assertEqual(self.request('GET','/api/captures'),(200,[]))
        self.assertEqual(self.request('GET','/api/runs'),(200,[]))
        self.assertEqual(self.request('POST','/api/captures',payload())[0],201)
        code,run=self.request('POST','/api/captures/capture_1/process',{});self.assertEqual(code,201)
        run_id=run['run_id'];self.assertEqual(self.request('GET',f'/api/export/{run_id}'),(200,run));self.assertEqual(self.request('GET',f'/api/runs/{run_id}'),(200,run))
        self.assertEqual(self.request('GET','/api/images/capture_1/source.png')[0],200)
        code,image=self.request('GET',f'/api/artifacts/{run_id}/f0__OD_raw.png');self.assertEqual(code,200);self.assertTrue(image.startswith(b'\x89PNG'))
        self.assertEqual(self.request('GET',f'/api/artifacts/{run_id}/result.json')[0],400)

    def test_cross_origin_dns_rebinding_content_type_size_and_paths(self):
        rejected=[({'Origin':'http://evil.example'},payload()),({'Host':'evil.example'},payload()),({'Sec-Fetch-Site':'cross-site'},payload()),({'Content-Type':'text/plain'},payload()),({'Content-Length':str(MAX_REQUEST_BYTES+1)},None)]
        for headers,body in rejected:
            with self.subTest(headers=headers):self.assertEqual(self.request('POST','/api/captures',body,headers)[0],400)
        for path in ('/api/images/capture_1/%2e%2e','/api/images/capture_1/a%5cb.png','/api/health?ignored=1','/api/health'):
            headers={'Host':'evil.example'} if path=='/api/health' else None
            self.assertEqual(self.request('GET',path,headers=headers)[0],400)
        self.assertEqual(self.server.store.captures(),[])

    def test_strict_json_and_get_cannot_process_or_write(self):
        for raw in (b'{"value":NaN}',b'{"value":1,"value":2}',b'{"value":Infinity}'):
            self.assertEqual(self.request('POST','/api/captures',raw,raw=True)[0],400)
        self.request('POST','/api/captures',payload())
        before={str(p.relative_to(self.temp.name)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(self.temp.name).rglob('*') if p.is_file()}
        self.assertEqual(self.request('GET','/api/captures/capture_1/process')[0],404)
        for path in ('/','/app.js','/style.css','/api/health','/api/status','/api/captures','/api/runs'):
            self.assertEqual(self.request('GET',path)[0],200)
        after={str(p.relative_to(self.temp.name)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(self.temp.name).rglob('*') if p.is_file()}
        self.assertEqual(before,after);self.assertEqual(self.server.store.runs(),[])

    def test_public_bind_rejected(self):
        for host in ('0.0.0.0','::','example.com','192.168.1.1'):
            with self.assertRaises(ValidationError):create_server(host,0,self.temp.name)


if __name__=='__main__':
    unittest.main()
