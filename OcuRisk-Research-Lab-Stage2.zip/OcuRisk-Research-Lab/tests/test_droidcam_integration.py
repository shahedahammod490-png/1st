"""Actual local HTTP/import/decode provenance tests; fixtures are synthetic."""
import io
import json
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import unittest
import urllib.request
import urllib.error
import zipfile
from PIL import Image
from ocurisk_lab.server import create_server

class DroidCamIntegration(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.server=create_server('127.0.0.1',0,self.tmp.name)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base=f'http://127.0.0.1:{self.server.server_address[1]}'
        self.experiment=self.request('/api/experiments',{'title':'Synthetic acquisition fixture','participant_id':'synthetic','session_id':'fixture','mode':'STATIC','data_origin':'SYNTHETIC','approval_reference':None,'notes':''})
    def tearDown(self):
        self.server.shutdown();self.server.jobs.shutdown();self.server.server_close();self.tmp.cleanup()
    def request(self,path,payload=None,raw=None):
        data=raw if raw is not None else json.dumps(payload).encode() if payload is not None else None
        headers={'Content-Type':'application/octet-stream' if raw is not None else 'application/json'}
        with urllib.request.urlopen(urllib.request.Request(self.base+path,data=data,headers=headers),timeout=20) as response:
            body=response.read()
            return json.loads(body) if response.headers.get_content_type()=='application/json' else body
    def metadata(self,method):
        return {'schema_version':1,'capture_source':'BROWSER_DROIDCAM','connection':{'method':method,'provenance':'USER_DECLARED'},'pair_id':'synthetic-pair','target_id':'inert-fixture','calibration_stationary_asserted':True,'chart_roi':{'x':0,'y':0,'width':32,'height':32},'requested_constraints':{'width':32},'observed_track_settings':{'width':32,'frameRate':5},'declared_source_settings':{'provenance':'USER_DECLARED','app_version':'synthetic fixture','client_version':'synthetic fixture','filters':'none asserted fixture','focus':'fixture fixed','exposure':'fixture fixed','white_balance':'fixture fixed','notes':'SYNTHETIC only'},'browser_mime_type':'video/x-matroska','browser_video_callbacks':[{'mediaTime':0,'presentedFrames':1,'performance_time_ms':0}]}
    def import_source(self,video=False,color_shift=0):
        eid=self.experiment['experiment_id']
        if video:
            root=Path(self.tmp.name)/'fixtures';root.mkdir(exist_ok=True)
            for i in range(4):Image.new('RGB',(32,32),(80+i*20+color_shift,80,80)).save(root/f'{i:02d}.png')
            path=root/'synthetic.mkv';subprocess.run(['ffmpeg','-v','error','-y','-framerate','5','-i',str(root/'%02d.png'),'-c:v','ffv1',str(path)],check=True)
            raw=path.read_bytes();name='synthetic.mkv'
        else:
            b=io.BytesIO();Image.new('RGB',(32,32),(80,80,80)).save(b,format='PNG');raw=b.getvalue();name='synthetic.png'
        return self.request(f'/api/experiments/{eid}/media/{name}',raw=raw)
    def process(self,media,metadata=None):
        payload={'sample_every':2,'algorithms':['BOUNDARY_Y_RE'],'identity_confirmed':False,'upright_confirmed':False,'annotations':{}}
        if metadata is not None:payload['capture_metadata']=metadata
        job=self.request(f'/api/media/{media["media_id"]}/process',payload)
        for _ in range(200):
            job=self.request('/api/jobs/'+job['job_id'])
            if job['state'] in ('COMPLETED','FAILED','CANCELLED'):break
            time.sleep(.02)
        self.assertEqual(job['state'],'COMPLETED',job.get('error'))
        return job
    def test_every_frame_metadata_compare_export_and_tamper(self):
        jobs=[]
        for method in ('USB','WIFI'):
            media=self.import_source(video=True,color_shift=0 if method=='USB' else 1);metadata=self.metadata(method)
            raw=json.dumps(metadata,indent=2).encode()
            self.request(f'/api/media/{media["media_id"]}/sidecars/capture-quality.json',raw=raw)
            job=self.process(media);jobs.append(job)
            self.assertEqual(job['options']['capture_metadata'],metadata)
            self.assertEqual(job['result']['capture_metadata'],metadata)
            self.assertEqual(job['result']['acquisition_quality']['frame_count'],4)
            self.assertEqual(job['result']['acquisition_quality']['timing']['effective_fps'],5)
            self.assertIn('quality.py',job['result']['service_provenance']['source_hashes'])
            for frame in job['result']['frames']:
                self.assertIsInstance(frame['acquisition_quality'],dict)
                if not frame['sampled']:self.assertIsNone(frame['quality']);self.assertIsNone(frame['eyes'])
            quality_artifact=self.request(f'/api/jobs/{job["job_id"]}/artifacts/acquisition-quality.json')
            self.assertEqual(quality_artifact['capture_metadata'],metadata)
            exported=self.request(f'/api/experiments/{self.experiment["experiment_id"]}/export')
            with zipfile.ZipFile(io.BytesIO(exported)) as archive:
                self.assertEqual(archive.read(f'media/{media["media_id"]}/sidecars/capture-quality.json'),raw)
        ids=[j['job_id'] for j in jobs]
        report=self.request('/api/quality/compare',{'job_ids':ids})
        self.assertEqual(report['status'],'ELIGIBLE_DESCRIPTIVE_COMPARISON')
        self.assertEqual(report['groups']['USB'],[ids[0]])
        self.assertEqual(report['differences']['effective_fps']['WIFI_minus_USB'],0)
        jid=ids[0];path=self.server.store.jobs_dir/jid/'acquisition-quality.json';path.write_text('{}')
        with self.assertRaises(urllib.error.HTTPError) as caught:self.request('/api/quality/compare',{'job_ids':ids})
        self.assertEqual(caught.exception.code,400)
        with self.assertRaises(urllib.error.HTTPError):self.request(f'/api/experiments/{self.experiment["experiment_id"]}/export')
    def test_payload_metadata_is_immutable_and_bad_options_rejected(self):
        media=self.import_source();mid=media['media_id'];metadata=self.metadata('USB')
        job=self.process(media,metadata)
        self.assertEqual(len(self.server.store.records('sidecar',mid)),1)
        with self.assertRaises(urllib.error.HTTPError):self.process(media,self.metadata('WIFI'))
        for bad in ({'job_ids':[job['job_id'],job['job_id']]},{'job_ids':[]},{'job_ids':['missing','other'],'extra':1}):
            with self.assertRaises(urllib.error.HTTPError) as caught:self.request('/api/quality/compare',bad)
            self.assertEqual(caught.exception.code,400)
        with self.assertRaises(urllib.error.HTTPError):self.request(f'/api/media/{mid}/sidecars/capture-quality.json',raw=json.dumps(metadata).encode())
        second=self.import_source();bad=self.metadata('USB');bad['chart_roi']['width']=33
        with self.assertRaises(urllib.error.HTTPError):self.request(f'/api/media/{second["media_id"]}/sidecars/capture-quality.json',raw=json.dumps(bad).encode())
        self.assertEqual(self.server.store.records('sidecar',second['media_id']),[])
        # An appended sidecar invalidates old job input provenance, requiring a new run.
        self.request(f'/api/media/{mid}/sidecars/extra.json',raw=b'{"actual":"attachment"}')
        with self.assertRaises(urllib.error.HTTPError):self.request(f'/api/jobs/{job["job_id"]}/artifacts/acquisition-quality.json')
        exported=self.request(f'/api/experiments/{self.experiment["experiment_id"]}/export')
        with zipfile.ZipFile(io.BytesIO(exported)) as archive:
            scope=json.loads(archive.read(f'jobs/{job["job_id"]}/export-input-scope.json'))
            self.assertFalse(scope['snapshot_matches_current_attachments'])
            self.assertEqual(scope['historical_sidecar_snapshot'],job['options']['capture_sidecar_snapshot'])
            self.assertEqual(archive.read(f'media/{mid}/sidecars/extra.json'),b'{"actual":"attachment"}')
        (self.server.store.media_dir/mid/'sidecars'/'extra.json').write_text('{}')
        with self.assertRaises(urllib.error.HTTPError):self.request(f'/api/experiments/{self.experiment["experiment_id"]}/export')
    def test_comparison_does_not_trust_mutated_database_summary(self):
        jobs=[self.process(self.import_source(),self.metadata(method)) for method in ('USB','WIFI')]
        job=jobs[0];job['result']['acquisition_quality']['frame_count']=999
        self.server.store.update_job(job)
        with self.assertRaises(urllib.error.HTTPError) as caught:self.request('/api/quality/compare',{'job_ids':[j['job_id'] for j in jobs]})
        self.assertEqual(caught.exception.code,400)
        with self.assertRaises(urllib.error.HTTPError):self.request(f'/api/experiments/{self.experiment["experiment_id"]}/export')

class CheckpointPerformance(unittest.TestCase):
    def test_aggregate_computed_once_and_final_checkpoint_complete(self):
        from unittest.mock import patch
        from ocurisk_lab import video, quality
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for i in range(12):Image.new('RGB',(32,32),(80+i,80,80)).save(root/f'{i:02d}.png')
            source=root/'synthetic.mkv'
            subprocess.run(['ffmpeg','-v','error','-framerate','5','-i',str(root/'%02d.png'),'-c:v','ffv1',str(source)],check=True)
            observed=[]
            def progress(value):
                checkpoint=json.loads((root/'out'/'result.partial.json').read_text())
                observed.append(checkpoint)
                self.assertIsNone(checkpoint['acquisition_quality'])
                self.assertIsNone(checkpoint['candidate_quality_ranking'])
            with patch('ocurisk_lab.video.quality.summarize_quality',wraps=quality.summarize_quality) as summarize:
                result=video.analyze_media(source,root/'out',media={},options={'sample_every':10},progress=progress)
                self.assertEqual(summarize.call_count,1)
            self.assertEqual(result['status'],'COMPLETED')
            self.assertEqual(len(result['frames']),12)
            self.assertEqual(result['acquisition_quality']['frame_count'],12)
            self.assertEqual(json.loads((root/'out'/'result.partial.json').read_text()),result)
            self.assertTrue(observed)
