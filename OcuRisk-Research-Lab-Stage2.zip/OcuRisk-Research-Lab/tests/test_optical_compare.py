import tempfile
from pathlib import Path
import unittest
import numpy as np
from PIL import Image
from ocurisk_lab.optical_compare import compare
class CompareTests(unittest.TestCase):
 def test_distinct_masks_common_roi(self):
  rgb=np.full((128,128,3),40,dtype='uint8'); rgb[88:105,35:94]=[160,160,160]; rgb[24:40,35:94]=[60,0,0]
  with tempfile.TemporaryDirectory() as tmp:
   result=compare(rgb,{'cx_px':64,'cy_px':64,'radius_px':40},tmp,'synthetic')
   masks=[np.asarray(Image.open(Path(tmp)/result[a]['artifacts']['candidate_mask'])) for a in ('BOUNDARY_Y','BOUNDARY_RE','BOUNDARY_Y_RE')]
   self.assertTrue(np.array_equal(masks[2]>0,(masks[0]>0)|(masks[1]>0))); self.assertFalse(np.array_equal(masks[0],masks[1])); self.assertFalse(np.array_equal(masks[0],masks[2])); self.assertEqual(len({r['roi_sha256'] for r in result.values()}),1)
