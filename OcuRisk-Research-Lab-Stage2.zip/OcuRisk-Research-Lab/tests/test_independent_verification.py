"""Adversarial verifier-owned engineering tests; all images are SYNTHETIC.

Passing these tests provides no optical, camera, clinical or safety validation.
"""
import base64
import copy
import hashlib
import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image

from ocurisk_lab.optical import analyze_frame
from ocurisk_lab.schema import ValidationError, validate_manifest
from ocurisk_lab.server import create_server, strict_json
from ocurisk_lab.store import Store, source_snapshot


def circle(cx=24, cy=24, radius=12):
    return dict(cx_px=cx, cy_px=cy, radius_px=radius, source='MANUAL_ANNOTATION')


def encoded_image(rgb=None, mode='RGB'):
    if rgb is None:
        rgb = np.full((64, 128, 3), 70, dtype=np.uint8)
        rgb[:, 64:] = [130, 40, 30]
        rgb[20:32, 18:32] = [150, 70, 50]
    stream = io.BytesIO()
    Image.fromarray(rgb, mode=mode).save(stream, format='PNG')
    return stream.getvalue()


def capture_payload(raw=None):
    raw = encoded_image() if raw is None else raw
    digest = hashlib.sha256(raw).hexdigest()
    manifest = dict(schema_version='1.0', capture_id='verifier_capture',
                    participant_id='synthetic_subject', session_id='session',
                    device_id='synthetic_device', mode='VIDEO_RIGHT',
                    data_origin='SYNTHETIC', approval_reference=None,
                    illumination=dict(requested='UNKNOWN', reported='UNKNOWN',
                                      physical_verified=False, evidence_id=None),
                    distance_m=None, phone_pose=None, head_pose=None,
                    mirrored=None, image_rotation_deg=None,
                    timestamp_source='UNMEASURED', frames=[
                        dict(frame_index=0, timestamp_ns=None, source_file='frame.png',
                             sha256=digest, eyes=dict(OD=circle(), OS=circle(96)))])
    return dict(manifest=manifest, files=[dict(name='frame.png', base64=base64.b64encode(raw).decode())])


class IndependentOpticalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.image = self.root / 'source.png'
        self.image.write_bytes(encoded_image())

    def tearDown(self):
        self.temp.cleanup()

    def run_analysis(self, eyes, folder='run'):
        return analyze_frame(self.image, eyes, self.root / folder)

    def test_absent_eye_remains_null_and_inconclusive(self):
        eye = self.run_analysis(dict(OD=circle(), OS=None))['eyes']['OS']
        self.assertEqual(eye['status'], 'INCONCLUSIVE')
        self.assertTrue(all(m['value'] is None for m in eye['measurements'].values()))
        self.assertEqual(eye['artifacts'], {})

    def test_mutating_os_never_changes_od(self):
        a = self.run_analysis(dict(OD=circle(), OS=circle(96)), 'one')
        b = self.run_analysis(dict(OD=circle(), OS=None), 'two')
        self.assertEqual(a['eyes']['OD'], b['eyes']['OD'])
        self.assertNotEqual(a['eyes']['OD']['measurements']['mean_RD'],
                            a['eyes']['OS']['measurements']['mean_RD'])

    def test_repeat_results_and_artifact_bytes_identical(self):
        eyes = dict(OD=circle(), OS=circle(96))
        a = self.run_analysis(eyes, 'one')
        b = self.run_analysis(eyes, 'two')
        self.assertEqual(a, b)
        for eye in a['eyes'].values():
            for name in eye['artifacts'].values():
                self.assertEqual((self.root/'one'/name).read_bytes(),
                                 (self.root/'two'/name).read_bytes())

    def test_black_preserves_zero_without_fake_prediction(self):
        self.image.write_bytes(encoded_image(np.zeros((64, 128, 3), dtype=np.uint8)))
        result = self.run_analysis(dict(OD=circle(), OS=None))
        eye = result['eyes']['OD']
        self.assertEqual(eye['measurements']['mean_Y']['value'], 0)
        self.assertEqual(eye['measurements']['gradient_magnitude']['value'], 0)
        self.assertEqual(eye['measurements']['mean_RE']['value'], 0)
        self.assertEqual(eye['measurements']['mean_RD']['value'], 0)
        self.assertEqual(eye['measurements']['candidate_crescent_fraction']['value'], 0)
        self.assertEqual(eye['measurements']['ADAPTED_OLD_brightness_ratio']['value'], 0.08)
        self.assertIn('NOT detected crescent area', result['feature_definitions']['ADAPTED_OLD'])
        self.assertIsNone(eye['prediction'])
        self.assertIsNone(eye['uncertainty'])
        self.assertIsNone(eye['measurements']['clinical_gradability']['value'])
        json.dumps(result, allow_nan=False)

    def test_partially_outside_circle_is_inconclusive(self):
        eye = self.run_analysis(dict(OD=circle(1, 24, 12), OS=None))['eyes']['OD']
        self.assertLess(eye['measurements']['valid_pupil_fraction']['value'], 1)
        self.assertEqual(eye['status'], 'INCONCLUSIVE',
                         'Partial annotation must not have ordinary success status')

    def test_fully_outside_circle_is_inconclusive(self):
        eye = self.run_analysis(dict(OD=circle(-30, 24, 8), OS=None))['eyes']['OD']
        self.assertEqual(eye['status'], 'INCONCLUSIVE')
        self.assertIsNone(eye['measurements']['mean_Y']['value'])

    def test_same_region_cannot_be_accepted_as_both_anatomical_eyes(self):
        result = self.run_analysis(dict(OD=circle(), OS=circle()))
        for eye in result['eyes'].values():
            self.assertEqual(eye['status'], 'INCONCLUSIVE')
            self.assertIn('ANATOMICAL_ANNOTATION_CONFLICT', eye['reasons'])
            self.assertIsNone(eye['prediction'])

    def test_invalid_annotations_reject_nonfinite_and_bool(self):
        for value in [float('nan'), float('inf'), True]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.run_analysis(dict(OD=circle(value), OS=None))

    def test_overexposed_image_cannot_create_candidate_crescent(self):
        self.image.write_bytes(encoded_image(np.full((64,128,3),255,dtype=np.uint8)))
        eye = self.run_analysis(dict(OD=circle(), OS=None))['eyes']['OD']
        self.assertEqual(eye['measurements']['candidate_crescent_fraction']['value'], 0)
        self.assertIn('WHOLE_IMAGE_OVEREXPOSURE_HEURISTIC_TRIGGERED', eye['reasons'])
        self.assertIsNone(eye['prediction'])


class IndependentImportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_hash_mismatch_never_persists(self):
        payload = capture_payload()
        payload['manifest']['frames'][0]['sha256'] = '0'*64
        with self.assertRaises(ValidationError):
            self.store.import_capture(payload)
        self.assertEqual(self.store.captures(), [])
        self.assertEqual(list(self.store.captures_dir.iterdir()), [])

    def test_real_origin_without_approval_rejected(self):
        manifest = capture_payload()['manifest']
        manifest['data_origin'] = 'REAL_APPROVED'
        with self.assertRaises(ValidationError):
            validate_manifest(manifest)

    def test_zero_timestamp_and_missing_distance_not_imputed(self):
        payload = capture_payload()
        payload['manifest']['frames'][0]['timestamp_ns'] = '0'
        self.store.import_capture(payload)
        result = self.store.process('verifier_capture')
        self.assertEqual(result['frames'][0]['timestamp_ns'], '0')
        self.assertIsNone(result['manifest']['distance_m'])
        self.assertIsNone(result['manifest']['phone_pose'])
        self.assertIsNone(result['prediction'])

    def test_duplicate_or_reversed_known_timestamps_rejected(self):
        for second in ['1', '0']:
            manifest = capture_payload()['manifest']
            manifest['frames'][0]['timestamp_ns'] = '1'
            next_frame = copy.deepcopy(manifest['frames'][0])
            next_frame.update(frame_index=1, timestamp_ns=second,
                              source_file='frame2.png', sha256='0'*64)
            manifest['frames'].append(next_frame)
            with self.subTest(second=second), self.assertRaises(ValidationError):
                validate_manifest(manifest)

    def test_paths_and_extension_spoof_rejected(self):
        for filename in ['../frame.png', 'sub/frame.png', r'..\frame.png', 'frame.jpg']:
            payload = capture_payload()
            payload['manifest']['frames'][0]['source_file'] = filename
            payload['files'][0]['name'] = filename
            with self.subTest(filename=filename), self.assertRaises(ValidationError):
                self.store.import_capture(payload)

    def test_duplicate_hash_across_captures_rejected(self):
        payload = capture_payload()
        self.store.import_capture(payload)
        payload['manifest']['capture_id'] = 'second'
        with self.assertRaises(ValidationError):
            self.store.import_capture(payload)
        self.assertEqual(len(self.store.captures()), 1)

    def test_transparent_image_rejected_at_import(self):
        rgba = np.full((64,128,4),255,dtype=np.uint8)
        rgba[:,:,3] = 64
        payload = capture_payload(encoded_image(rgba, mode='RGBA'))
        with self.assertRaises(ValidationError):
            self.store.import_capture(payload)
        self.assertEqual(self.store.captures(), [])

    def test_opaque_alpha_capture_is_rejected_or_processable(self):
        rgba = np.full((64,128,4),255,dtype=np.uint8)
        rgba[:,:,:3] = 80
        payload = capture_payload(encoded_image(rgba, mode='RGBA'))
        try:
            self.store.import_capture(payload)
        except ValidationError:
            self.assertEqual(self.store.captures(), [])
            return
        # An accepted import must satisfy the processing decoder's contract.
        run = self.store.process('verifier_capture')
        self.assertEqual(len(run['frames']), 1)

    def test_tampered_stored_image_blocks_run(self):
        self.store.import_capture(capture_payload())
        path = self.store.image_path('verifier_capture', 'frame.png')
        path.write_bytes(encoded_image(np.zeros((64,128,3),dtype=np.uint8)))
        with self.assertRaises(ValidationError):
            self.store.process('verifier_capture')
        self.assertEqual(self.store.runs(), [])

    def test_run_retains_actual_implementation_hashes(self):
        self.store.import_capture(capture_payload())
        run = self.store.process('verifier_capture')
        hashes = run.get('source_hashes')
        self.assertIsInstance(hashes, dict, 'Source hashes required for replay provenance')
        self.assertIn('ocurisk_lab/optical.py', hashes)
        project = Path(__file__).resolve().parents[1]
        for path, digest in hashes.items():
            self.assertRegex(digest, r'^[0-9a-f]{64}$')
            self.assertEqual(digest, hashlib.sha256((project/path).read_bytes()).hexdigest())

    def test_constant_only_source_change_rejects_cached_algorithm(self):
        # Simulate edited source reads without modifying any implementation file.
        real_read = Path.read_bytes
        def changed_read(path):
            content = real_read(path)
            if path.name == 'optical.py':
                replacement = content.replace(b'"signal_min_range": 0.02,',
                                              b'"signal_min_range": 0.03,')
                self.assertNotEqual(replacement, content)
                return replacement
            return content
        with patch.object(Path, 'read_bytes', changed_read):
            with self.assertRaises(ValidationError):
                source_snapshot(analyze_frame)

    def test_unsafe_artifact_paths_rejected(self):
        self.store.import_capture(capture_payload())
        run = self.store.process('verifier_capture')
        for path in ['../result.json', 'result.json', r'..\result.json']:
            with self.subTest(path=path), self.assertRaises(ValidationError):
                self.store.artifact_path(run['run_id'], path)


class IndependentServerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.server = create_server('127.0.0.1', 0, self.temp.name)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.port = self.server.server_address[1]

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def request(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=10)
        conn.request(method, path, body=body, headers=headers or {})
        response = conn.getresponse()
        result = response.status, response.read(), dict(response.getheaders())
        conn.close()
        return result

    def test_cross_origin_and_dns_rebind_hosts_rejected(self):
        status, _, _ = self.request('GET','/api/captures',headers={'Host':'evil.example'})
        self.assertEqual(status, 400)
        for headers in [dict(Origin='https://evil.example'), {'Sec-Fetch-Site':'cross-site'}]:
            headers['Content-Type'] = 'application/json'
            status, _, _ = self.request('POST','/api/captures',b'{}',headers)
            self.assertEqual(status, 400)
        self.assertEqual(self.server.store.captures(), [])

    def test_public_bind_rejected(self):
        for host in ['0.0.0.0', '192.168.1.1', 'example.com']:
            with self.subTest(host=host), self.assertRaises(ValidationError):
                create_server(host, 0, self.temp.name)

    def test_capabilities_distinguish_research_models_from_clinical_validity(self):
        status, raw, headers = self.request('GET','/api/status')
        result = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(result['phone_connection'],'NOT_VERIFIED')
        self.assertEqual(result['physical_illumination'],'NOT_VERIFIED')
        self.assertEqual(result['advanced_models'],'IMPLEMENTED_UNTRAINED_OR_RESEARCH_ONLY')
        self.assertEqual(result['clinical_prediction'],'AWAITING_REFERENCE_DATA')
        self.assertIsNone(result['verified_reference_dataset'])
        self.assertIsNone(result['uncertainty'])
        self.assertIsNone(result['prediction'])
        self.assertEqual(headers['X-Content-Type-Options'],'nosniff')

    def test_strict_json_rejects_duplicate_keys_and_nan(self):
        for raw in [b'{"mode":1,"mode":2}', b'{"value":NaN}', b'{"x":Infinity}']:
            with self.subTest(raw=raw), self.assertRaises(ValidationError):
                strict_json(raw)

    def test_http_roundtrip_and_export_actual_measurements(self):
        payload = capture_payload()
        status, _, _ = self.request('POST','/api/captures',json.dumps(payload),
                                    {'Content-Type':'application/json'})
        self.assertEqual(status, 201)
        status, raw, _ = self.request('POST','/api/captures/verifier_capture/process','{}',
                                      {'Content-Type':'application/json'})
        self.assertEqual(status, 201)
        run = json.loads(raw)
        self.assertIsNone(run['prediction'])
        self.assertEqual(run['manifest']['mode'], 'VIDEO_RIGHT')
        self.assertEqual(set(run['frames'][0]['analysis']['eyes']), {'OD','OS'})
        status, raw, _ = self.request('GET','/api/export/'+run['run_id'])
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw), run)
        artifact = run['artifact_files'][0]
        status, raw, _ = self.request('GET','/api/artifacts/'+run['run_id']+'/'+artifact)
        self.assertEqual(status, 200)
        self.assertEqual(raw, self.server.store.artifact_path(run['run_id'], artifact).read_bytes())


if __name__ == '__main__':
    unittest.main()
