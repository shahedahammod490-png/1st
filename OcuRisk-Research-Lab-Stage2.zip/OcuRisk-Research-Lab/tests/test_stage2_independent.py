"""Verifier-owned Stage 2 adversarial tests. Every fixture is SYNTHETIC.

These tests do not establish optical validity, clinical performance or safety.
"""
import copy
import hashlib
import http.client
import io
import json
import math
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import time
import unittest
import zipfile

import numpy as np
from PIL import Image


def synthetic_records(algorithm='LINEAR'):
    rows = []
    for i, x in enumerate([-3., -2., -1., 0., 1., 2., 4., 5.]):
        rows.append({'participant_id': f'synthetic_{i}',
                     'split': 'train' if i < 6 else 'test',
                     'features': {'image_feature': x}, 'target': 2*x + 3,
                     'data_origin': 'SYNTHETIC', 'target_origin': 'SYNTHETIC'})
    return {'algorithm': algorithm,
            'dataset': {'target_name': 'synthetic_linear_target',
                        'target_unit': 'arbitrary_test_units', 'records': rows},
            'config': {}}


class IndependentStage2Models(unittest.TestCase):
    def setUp(self):
        from ocurisk_lab.models import ModelLab
        self.temp = tempfile.TemporaryDirectory()
        self.lab = ModelLab(Path(self.temp.name))

    def tearDown(self):
        self.temp.cleanup()

    def test_five_estimators_fit_actual_data_with_independent_errors(self):
        for algorithm in ('LINEAR', 'RIDGE', 'ELASTIC_NET', 'RANDOM_FOREST', 'GRADIENT_BOOSTING'):
            with self.subTest(algorithm=algorithm):
                payload = synthetic_records(algorithm)
                result = self.lab.train(payload)
                predicted = self.lab.predict(result['model_id'], [{'image_feature': 4.}, {'image_feature': 5.}])
                values = np.array([p['value'] for p in predicted['predictions']])
                errors = values - np.array([11., 13.])
                self.assertAlmostEqual(result['evaluation']['test']['mae'], np.abs(errors).mean())
                self.assertAlmostEqual(result['evaluation']['test']['rmse'], np.sqrt((errors**2).mean()))
                self.assertAlmostEqual(result['evaluation']['test']['bias'], errors.mean())
                self.assertEqual(result['clinical_status'], 'NOT_VALIDATED')
                self.assertTrue(all(p['clinical_prediction'] is None for p in predicted['predictions']))
                if algorithm == 'LINEAR':
                    np.testing.assert_allclose(values, [11., 13.], atol=1e-10)

    def test_scaler_is_training_only_and_original_payload_frozen(self):
        payload = synthetic_records()
        original = copy.deepcopy(payload)
        result = self.lab.train(payload)
        self.assertEqual(result['scaler']['mean'], [-.5])
        self.assertAlmostEqual(result['evaluation']['test']['train_mean_baseline']['mae'], 10.)
        payload['dataset']['records'][0]['target'] = 999.
        persisted = self.lab.model(result['model_id'])
        self.assertEqual(persisted['payload'], original)
        self.assertEqual(persisted['payload'], result['payload'])

    def test_grouped_cv_uses_only_training_subjects(self):
        payload = synthetic_records('RIDGE')
        payload['config'] = {'cv_folds': 3}
        result = self.lab.train(payload)
        cv = result['cross_validation']
        self.assertEqual(len(cv['folds']), 3)
        self.assertEqual(sum(f['n'] for f in cv['folds']), 6)
        self.assertIn('training', cv['method'])

    def test_subject_and_exact_feature_leakage_rejected(self):
        payload = synthetic_records()
        payload['dataset']['records'][-1]['participant_id'] = 'synthetic_0'
        with self.assertRaises(ValueError):
            self.lab.train(payload)
        payload = synthetic_records()
        payload['dataset']['records'][-1]['features'] = {'image_feature': -3.}
        # A changed label must not hide duplicated predictors across splits.
        with self.assertRaises(ValueError):
            self.lab.train(payload)

    def test_nonfinite_bool_mixed_origin_and_direct_target_leakage_rejected(self):
        for value in (True, float('nan'), float('inf')):
            with self.subTest(value=repr(value)):
                payload = synthetic_records()
                payload['dataset']['records'][0]['features']['image_feature'] = value
                with self.assertRaises(ValueError):
                    self.lab.train(payload)
        payload = synthetic_records()
        payload['dataset']['records'][0]['data_origin'] = 'REAL_APPROVED'
        with self.assertRaises(ValueError):
            self.lab.train(payload)
        payload = synthetic_records()
        for row in payload['dataset']['records']:
            row['features'] = {'target': row['target']}
        with self.assertRaises(ValueError):
            self.lab.train(payload)

    def test_reference_reuse_across_splits_rejected(self):
        payload = synthetic_records()
        for i, row in enumerate(payload['dataset']['records']):
            row.update(data_origin='REAL_APPROVED', target_origin='INDEPENDENT_REFERENCE',
                       approval_reference='TEST_ASSERTION_NOT_A_REAL_APPROVAL',
                       reference={'source_id': 'same_reference' if i in (0, 7) else f'test_ref_{i}',
                                  'method': 'SYNTHETIC_PROTOCOL_TEST_ONLY',
                                  'examiner_id': 'SYNTHETIC_EXAMINER',
                                  'measured_at': '2026-10-09T00:00:00+00:00'})
        with self.assertRaises(ValueError):
            self.lab.train(payload)

    def test_model_hash_detects_tampering(self):
        result = self.lab.train(synthetic_records())
        file = Path(self.temp.name) / 'models' / f"{result['model_id']}.json"
        changed = json.loads(file.read_text())
        changed['estimator']['intercept'] = 900
        file.write_text(json.dumps(changed))
        with self.assertRaises(ValueError):
            self.lab.model(result['model_id'])

    def test_bayesian_explicit_priors_and_named_event_required(self):
        from ocurisk_lab.models import configuration
        with self.assertRaises(ValueError):
            configuration('BAYESIAN_LOGIT', {})
        for key in ('prior_sd', 'intercept_prior_sd'):
            c = {'prior_sd': 2., 'intercept_prior_mean': 0., 'intercept_prior_sd': 3.}
            c[key] = 0
            with self.assertRaises(ValueError):
                configuration('BAYESIAN_LOGIT', c)
        payload = synthetic_records('BAYESIAN_LOGIT')
        payload['config'] = {'prior_sd': 2., 'intercept_prior_mean': 0., 'intercept_prior_sd': 3.}
        for i, row in enumerate(payload['dataset']['records']): row['target'] = i % 2
        with self.assertRaises(ValueError): self.lab.train(payload)

    def test_bayesian_balanced_analytic_laplace_case(self):
        from ocurisk_lab.models import configuration, fit_bayes, bayes_predict
        config = configuration('BAYESIAN_LOGIT', {'prior_sd': 2., 'intercept_prior_mean': 0., 'intercept_prior_sd': 3., 'posterior_samples': 20000})
        state = fit_bayes(np.zeros((4, 1)), np.array([0., 1., 0., 1.]), config)
        # Balanced likelihood mode is zero; H00 = n/4 + 1/9, H11=1/4.
        np.testing.assert_allclose(state['map'], [0., 0.], atol=1e-9)
        np.testing.assert_allclose(state['hessian'], [[10/9, 0.], [0., .25]], atol=1e-9)
        np.testing.assert_allclose(state['covariance'], [[.9, 0.], [0., 4.]], atol=1e-9)
        p, interval = bayes_predict(state, np.zeros((1, 1)), config)
        self.assertAlmostEqual(float(p[0]), .5, delta=.015)
        self.assertTrue(0 < interval[0, 0] < .5 < interval[0, 1] < 1)

    def test_legacy_exact_formula_explicit_clamps_and_no_clinical_prediction(self):
        from ocurisk_lab.models import legacy_physics
        payload = {'crescent_ratio': .1, 'pupil_diameter_mm': 4., 'reflex_ratio': .7,
                   'working_distance_cm': 100., 'flash_eccentricity_mm': 12.,
                   'optical_constant_k': 6., 'orientation': 'TOP'}
        result = legacy_physics(payload)
        self.assertAlmostEqual(result['raw_legacy_numeric_output'], -1.25)
        self.assertEqual(result['rounded_legacy_numeric_output'], -1.25)
        self.assertIsNone(result['clinical_prediction'])
        payload['crescent_ratio'] = 1.
        result = legacy_physics(payload)
        self.assertEqual(result['requested']['crescent_ratio'], 1.)
        self.assertEqual(result['effective']['crescent_ratio'], .8)
        del payload['working_distance_cm']
        with self.assertRaises((ValueError, KeyError)): legacy_physics(payload)

    def test_power_vectors_independent_known_case(self):
        from ocurisk_lab.models import power_vectors
        p = power_vectors({'sphere_d': -1., 'cylinder_d': -2., 'axis_deg': 45.})
        self.assertAlmostEqual(p['M'], -2.)
        self.assertAlmostEqual(p['J0'], 0., places=12)
        self.assertAlmostEqual(p['J45'], 1.)
        self.assertIsNone(p['clinical_prediction'])



class IndependentStage2HTTP(unittest.TestCase):
    """Real loopback service; sources are explicitly synthetic engineering fixtures."""
    def setUp(self):
        from ocurisk_lab.server import create_server
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.server = create_server('127.0.0.1', 0, self.root)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.jobs.shutdown()
        self.server.server_close()
        self.temp.cleanup()

    def request(self, path, payload=None, raw=None, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_address[1], timeout=30)
        body = raw if raw is not None else json.dumps(payload).encode() if payload is not None else None
        h = {'Content-Type': 'application/octet-stream' if raw is not None else 'application/json'}
        h.update(headers or {})
        connection.request('POST' if body is not None else 'GET', path, body=body, headers=h)
        response = connection.getresponse(); data = response.read(); status = response.status
        content_type = response.getheader('Content-Type', '')
        connection.close()
        return status, json.loads(data) if content_type.startswith('application/json') else data

    def experiment(self, mode='STATIC'):
        status, value = self.request('/api/experiments', {'title': 'Verifier SYNTHETIC test', 'participant_id': 'synthetic_verifier', 'session_id': 'synthetic_session', 'mode': mode, 'data_origin': 'SYNTHETIC', 'approval_reference': None, 'notes': 'Engineering fixture, not participant evidence'})
        self.assertEqual(status, 201, value)
        return value['experiment_id']

    def image(self, eid=None):
        eid = eid or self.experiment()
        stream = io.BytesIO(); Image.new('RGB', (80, 64), (50, 50, 50)).save(stream, format='PNG')
        raw = stream.getvalue()
        status, media = self.request(f'/api/experiments/{eid}/media/synthetic.png', raw=raw)
        self.assertEqual(status, 201, media)
        return eid, media, raw

    def process(self, media, options=None):
        options = options or {'sample_every': 1, 'algorithms': ['BOUNDARY_Y_RE'], 'identity_confirmed': False, 'upright_confirmed': False, 'annotations': {}}
        status, job = self.request(f"/api/media/{media['media_id']}/process", options)
        self.assertEqual(status, 202, job)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            status, job = self.request('/api/jobs/' + job['job_id'])
            if job['state'] in ('COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED'):
                return job
            time.sleep(.025)
        self.fail('Actual processing failed to reach terminal state within 30s')

    def test_empty_start_and_no_fake_model_metrics(self):
        status, overview = self.request('/api/overview')
        self.assertEqual(status, 200)
        self.assertTrue(all(value == 0 for value in overview['counts'].values()))
        status, registry = self.request('/api/models')
        self.assertEqual(status, 200)
        self.assertEqual(registry['models'], [])
        self.assertTrue(all('evaluation' not in a for a in registry['algorithms']))
        self.assertTrue(all(a['clinical_status'] == 'AWAITING_REFERENCE_DATA' for a in registry['algorithms']))

    def test_reference_zero_missingness_unverified_and_invalid_inputs(self):
        eid = self.experiment()
        reference = {'eye': 'OD', 'method': 'Synthetic reference validation fixture', 'measured_at': '2026-10-09T00:00:00Z', 'sphere_d': 0., 'cylinder_d': None, 'axis_deg': None, 'cycloplegic': None, 'examiner_id': 'SYNTHETIC_NOT_EXAMINER', 'notes': 'Not clinical evidence'}
        status, saved = self.request(f'/api/experiments/{eid}/references', reference)
        self.assertEqual(status, 201, saved)
        self.assertEqual(saved['sphere_d'], 0.)
        self.assertIsNone(saved['cylinder_d']); self.assertIsNone(saved['axis_deg'])
        self.assertEqual(saved['verification_status'], 'CALLER_SUPPLIED_UNVERIFIED')
        self.assertEqual(saved['units']['sphere_d'], 'diopter')
        for key, value in [('sphere_d', True), ('sphere_d', float('nan')), ('axis_deg', 181), ('measured_at', '2026-10-09'), ('method', '')]:
            with self.subTest(key=key, value=value):
                bad = dict(reference); bad[key] = value
                self.assertEqual(self.request(f'/api/experiments/{eid}/references', bad)[0], 400)
        self.assertEqual(len(self.request(f'/api/experiments/{eid}')[1]['references']), 1)

    def test_append_review_and_annotations_and_no_automatic_blinding(self):
        _, media, _ = self.image(); mid = media['media_id']
        payload = {'frame_index': 0, 'eyes': {'OD': None, 'OS': None}, 'comment': 'first'}
        first = self.request(f'/api/media/{mid}/annotations', payload)
        payload['comment'] = 'second'
        second = self.request(f'/api/media/{mid}/annotations', payload)
        self.assertEqual(first[0], 201); self.assertEqual(second[0], 201)
        self.assertNotEqual(first[1]['annotation_id'], second[1]['annotation_id'])
        payload['frame_index'] = 1
        self.assertEqual(self.request(f'/api/media/{mid}/annotations', payload)[0], 400)
        review = {'reviewer_id': 'SYNTHETIC_REVIEWER', 'frame_index': 0, 'eye': 'BOTH', 'label': '', 'comment': '', 'blinded': False}
        self.assertEqual(self.request(f'/api/media/{mid}/reviews', review)[0], 400)
        review['label'] = 'UNCERTAIN'; review['blinded'] = True
        status, saved = self.request(f'/api/media/{mid}/reviews', review)
        self.assertEqual(status, 201, saved)
        self.assertEqual(saved['blinding_status'], 'CALLER_ASSERTION')
        self.assertEqual(len(self.request(f'/api/media/{mid}')[1]['annotations']), 2)

    def test_duplicate_preservation_range_export_and_source_tamper(self):
        eid, media, raw = self.image(); _, duplicate, _ = self.image(eid)
        self.assertNotEqual(media['media_id'], duplicate['media_id'])
        self.assertIn(media['media_id'], duplicate['duplicate_of'])
        status, part = self.request(f"/api/media/{media['media_id']}/original", headers={'Range': 'bytes=0-7'})
        self.assertEqual(status, 206); self.assertEqual(part, raw[:8])
        status, archive = self.request(f'/api/experiments/{eid}/export')
        self.assertEqual(status, 200)
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            self.assertEqual(z.read(f"media/{media['media_id']}/original/synthetic.png"), raw)
        self.server.store.original(media['media_id']).write_bytes(b'changed synthetic bytes')
        self.assertEqual(self.request(f"/api/media/{media['media_id']}/original")[0], 400)
        self.assertEqual(self.request(f'/api/experiments/{eid}/export')[0], 400)

    def test_malformed_algorithms_rejected_no_persisted_job(self):
        _, media, _ = self.image()
        options = {'sample_every': 1, 'algorithms': [{}], 'identity_confirmed': False, 'upright_confirmed': False, 'annotations': {}}
        status, result = self.request(f"/api/media/{media['media_id']}/process", options)
        self.assertEqual(status, 400, result)
        self.assertEqual(self.request('/api/jobs')[1], [])

    def test_uniform_image_abstains_and_missing_timing_not_zero(self):
        _, media, raw = self.image()
        job = self.process(media)
        self.assertEqual(job['state'], 'COMPLETED', job)
        frame = job['result']['frames'][0]
        self.assertIsNone(frame['timestamp_ns'])
        self.assertEqual(frame['detection']['identity_status'], 'UNRESOLVED')
        self.assertEqual(frame['detection']['candidates'], [])
        for eye in ('OD', 'OS'):
            self.assertEqual(frame['eyes'][eye]['status'], 'INCONCLUSIVE')
            self.assertIsNone(frame['eyes'][eye]['prediction'])
            self.assertIsNone(frame['eyes'][eye]['uncertainty'])
        self.assertEqual(job['result']['service_provenance']['source_sha256'], hashlib.sha256(raw).hexdigest())

    def test_encoded_video_pts_duplicates_four_streams_and_sampling(self):
        eid = self.experiment('MULTI_VIEW')
        fixture = self.root/'fixture'; fixture.mkdir()
        for i in range(4):
            Image.new('RGB', (80, 64), (60 if i < 2 else 90,) * 3).save(fixture/f'{i}.png')
        video = fixture/'verifier.mkv'
        subprocess.run(['ffmpeg', '-v', 'error', '-framerate', '5', '-i', str(fixture/'%d.png'), '-c:v', 'ffv1', str(video)], check=True, timeout=20)
        raw = video.read_bytes()
        for direction in ('RIGHT', 'LEFT'):
            status, media = self.request(f'/api/experiments/{eid}/media/synthetic_{direction}.mkv', raw=raw, headers={'X-Media-Direction': direction, 'X-Mirrored': 'unknown'})
            self.assertEqual(status, 201, media)
            job = self.process(media, {'sample_every': 2, 'algorithms': ['BOUNDARY_Y', 'BOUNDARY_RE', 'BOUNDARY_Y_RE', 'ADAPTED_OLD'], 'identity_confirmed': False, 'upright_confirmed': False, 'annotations': {}})
            self.assertEqual(job['state'], 'COMPLETED', job)
            frames = job['result']['frames']
            self.assertEqual([f['timestamp_ns'] for f in frames], ['0', '200000000', '400000000', '600000000'])
            self.assertEqual(frames[0]['sha256'], frames[1]['sha256'])
            self.assertEqual(frames[0]['timestamp_source'], 'STREAM_PTS')
            self.assertEqual(set(frames[0]['eyes']), {'OD', 'OS'})
            self.assertIsNone(frames[1]['eyes'])
            self.assertEqual(frames[1]['skip_reason'], 'EXPLICIT_SAMPLE_EVERY')
            self.assertEqual(self.request(f"/api/media/{media['media_id']}/original")[1], raw)

    def test_processed_artifact_tamper_rejected(self):
        eid, media, _ = self.image()
        job = self.process(media)
        self.assertEqual(job['state'], 'COMPLETED', job)
        filename = job['result']['frames'][0]['source_file']
        artifact = self.server.store.jobs_dir / job['job_id'] / filename
        hashes = job['result']['service_provenance']['artifact_sha256']
        self.assertEqual(hashes[filename], hashlib.sha256(artifact.read_bytes()).hexdigest())
        artifact.write_bytes(b'tampered extracted frame')
        self.assertEqual(self.request(f"/api/jobs/{job['job_id']}/artifacts/{filename}")[0], 400)
        self.assertEqual(self.request(f'/api/experiments/{eid}/export')[0], 400)

    def test_physics_and_model_http_perform_actual_computation(self):
        status, vectors = self.request('/api/physics/power-vectors', {'sphere_d': -1., 'cylinder_d': -2., 'axis_deg': 45.})
        self.assertEqual(status, 200, vectors); self.assertAlmostEqual(vectors['M'], -2.); self.assertAlmostEqual(vectors['J45'], 1.)
        status, trained = self.request('/api/models/train', synthetic_records())
        self.assertEqual(status, 201, trained)
        status, prediction = self.request(f"/api/models/{trained['model_id']}/predict", {'features': [{'image_feature': 4.}]})
        self.assertEqual(status, 200, prediction); self.assertAlmostEqual(prediction['predictions'][0]['value'], 11.)
        self.assertIsNone(prediction['predictions'][0]['clinical_prediction'])


class IndependentStage2Detection(unittest.TestCase):
    def test_duplicate_haar_eye_observations_cannot_become_two_anatomical_eyes(self):
        from ocurisk_lab import detection
        from unittest.mock import patch
        rgb = np.full((100, 100, 3), 180, dtype=np.uint8)
        yy, xx = np.mgrid[:100, :100]
        rgb[(xx-30)**2 + (yy-25)**2 < 5**2] = 15
        class Detector:
            def __init__(self, file): self.face = 'frontalface' in file
            def detectMultiScale(self, *args, **kwargs):
                return np.array([[0, 0, 100, 100]]) if self.face else np.array([[15, 10, 30, 30], [15, 10, 30, 30]])
        with patch.object(detection.cv2, 'CascadeClassifier', Detector):
            found = detection.detect(rgb, mirrored=False, upright_confirmed=True, identity_confirmed=True)
        self.assertEqual(len(found['candidates']), 2)
        self.assertEqual(found['identity_status'], 'UNRESOLVED')
        self.assertIsNone(found['eyes']['OD'])
        self.assertIsNone(found['eyes']['OS'])


class IndependentStage2JobRecovery(unittest.TestCase):
    """Exercise cancellation/restart persistence with an explicit test analyzer."""
    def test_cancellation_retains_observed_checkpoint_and_source(self):
        from ocurisk_lab.research_store import ResearchStore
        from ocurisk_lab.jobs import JobManager
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            store = ResearchStore(root)
            raw = b'SYNTHETIC scheduler fixture; not an optical acquisition'
            source = root / 'synthetic.bin'; source.write_bytes(raw)
            store.put('media', {'media_id': 'synthetic_media', 'sha256': hashlib.sha256(raw).hexdigest()}, 'synthetic_experiment')
            store.original = lambda identifier: source
            store.process_options = lambda identifier, payload: {'annotations': {}}
            entered = threading.Event(); release = threading.Event()
            def analyzer(path, output, *, media, options, progress, cancelled):
                partial = {'status': 'RUNNING', 'frames': [{'frame_index': 0, 'fixture_origin': 'SYNTHETIC_SCHEDULER_TEST'}], 'artifact_files': []}
                (output / 'result.partial.json').write_text(json.dumps(partial))
                progress({'done': 1, 'total': 2})
                entered.set()
                if not release.wait(5): raise RuntimeError('test release deadline')
                self.assertTrue(cancelled())
                partial['status'] = 'CANCELLED'
                return partial
            manager = JobManager(store, analyzer)
            try:
                submitted = manager.submit('synthetic_media', {})
                self.assertTrue(entered.wait(5))
                manager.cancel(submitted['job_id']); release.set()
                manager.shutdown()
                job = store.get('job', submitted['job_id'])
                self.assertEqual(job['state'], 'CANCELLED')
                self.assertEqual(job['progress'], {'done': 1, 'total': 2})
                self.assertEqual(len(job['result']['frames']), 1)
                self.assertEqual(source.read_bytes(), raw)
                self.assertEqual(ResearchStore(root).get('job', submitted['job_id'])['state'], 'CANCELLED')
            finally:
                release.set(); manager.shutdown()

    def test_restart_recovers_actual_partial_file_without_claiming_completion(self):
        from ocurisk_lab.research_store import ResearchStore
        from ocurisk_lab.jobs import JobManager
        with tempfile.TemporaryDirectory() as directory:
            store = ResearchStore(directory)
            jid = 'synthetic_interrupted'
            store.put('job', {'job_id': jid, 'media_id': 'synthetic_media', 'state': 'RUNNING', 'progress': {'done': 1, 'total': 4}, 'result': None, 'options': {}, 'created_at': 'synthetic', 'updated_at': 'synthetic', 'error': None, 'cancel_requested': False}, 'synthetic_media')
            out = store.jobs_dir / jid; out.mkdir()
            partial = {'status': 'RUNNING', 'frames': [{'frame_index': 0, 'fixture_origin': 'SYNTHETIC_SCHEDULER_TEST'}], 'artifact_files': []}
            (out / 'result.partial.json').write_text(json.dumps(partial))
            manager = JobManager(ResearchStore(directory))
            try:
                recovered = store.get('job', jid)
                self.assertEqual(recovered['state'], 'INTERRUPTED')
                self.assertEqual(recovered['result']['frames'], partial['frames'])
                self.assertEqual(recovered['progress'], {'done': 1, 'total': 4})
                self.assertIn('restarted', recovered['error'])
            finally:
                manager.shutdown()


if __name__ == '__main__':
    unittest.main()

