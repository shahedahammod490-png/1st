// Independent state-machine test. Mock recorder/track events, NOT browser or hardware verification.
const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const src=fs.readFileSync('ocurisk_lab/web/live-capture.js','utf8').replace(/^import[^\n]+\n/,'');
 const {CaptureSession}=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
 const calls=[],finals=[],states=[];let finish;
 const track={readyState:'live',stop(){this.readyState='ended';}};
 const stream={getTracks:()=>[track],getVideoTracks:()=>[track]};
 class AsyncRecorder{static isTypeSupported(x){return x==='video/webm';}constructor(){this.state='inactive';this.mimeType='video/webm';}start(){this.state='recording';}stop(){this.state='inactive';finish=()=>{this.ondataavailable({data:new Blob(['trailer'])});this.onstop();};}}
 const session=new CaptureSession({devices:{getUserMedia:async c=>{calls.push(c);return stream;}},Recorder:AsyncRecorder,onState:s=>states.push(s),onFinal:(bytes,error)=>finals.push({bytes,error})});
 await session.preview('');assert.deepEqual(calls[0],{audio:false,video:true});assert.deepEqual(session.requestedConstraints,calls[0]);
 session.record();session.recorder.ondataavailable({data:new Blob(['first'])});session.recorder.onerror({error:new Error('actual encoder failure')});
 assert.equal(session.state,'FINALIZING');assert.equal(finals.length,0);assert.throws(()=>session.record());finish();
 assert.equal(await finals[0].bytes.text(),'firsttrailer');assert.equal(finals[0].error,'actual encoder failure');
 session.record();session.recorder.ondataavailable({data:new Blob(['second'])});session.dispose();finish();
 assert.equal(await finals[1].bytes.text(),'secondtrailer');assert.match(finals[1].error,/route left/);assert.equal(track.readyState,'ended');assert.equal(session.stream,null);
 assert.ok(states.includes('FINALIZING'));console.log('PASS independent asynchronous recorder finalization, partial error bytes, default requested constraints, route disposal');
})().catch(e=>{console.error(e);process.exit(1);});
