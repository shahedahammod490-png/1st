"""Synthetic candidate fixtures do not establish pupil detection accuracy."""
import unittest
import cv2
import numpy as np
from ocurisk_lab.detection import detect,provenance
class DetectionTests(unittest.TestCase):
 def test_blank_empty(self):
  for value in (0,90,255):
   result=detect(np.full((128,256,3),value,dtype='uint8'),mirrored=False,upright_confirmed=True,identity_confirmed=True)
   self.assertEqual(result['candidates'],[]); self.assertEqual(result['eyes'],{'OD':None,'OS':None}); self.assertIsNone(result['blink'])
 def test_dark_blobs_never_anatomy(self):
  rgb=np.full((128,256,3),180,dtype='uint8'); cv2.circle(rgb,(70,64),12,(10,10,10),-1); cv2.circle(rgb,(185,64),12,(10,10,10),-1)
  result=detect(rgb,mirrored=False,upright_confirmed=True,identity_confirmed=True)
  self.assertEqual(len(result['candidates']),2); self.assertEqual(result['eyes'],{'OD':None,'OS':None})
  self.assertTrue(all(c['source']=='AUTOMATIC_CANDIDATE' for c in result['candidates']))
  self.assertEqual(detect(np.full_like(rgb,180),previous=result['candidates'])['candidates'],[])
 def test_actual_xml_hashes(self):
  self.assertTrue(all(len(a['sha256'])==64 for a in provenance()['haar_assets'].values()))
