"""Actual HTTP source/revision/job/restart/export workflows (synthetic inputs)."""
import hashlib
import io
import json
import tempfile
import threading
import time
import unittest
import urllib.request
import urllib.error
import zipfile
from PIL import Image
from ocurisk_lab.server import create_server
from ocurisk_lab.research_store import ResearchStore
from ocurisk_lab.jobs import JobManager

class Workflow(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.server = create_server('127.0.0.1', 0, self.tmp.name)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f'http://127.0.0.1:{self.server.server_address[1]}'
    def tearDown(self):
        self.server.shutdown()
        self.server.jobs.shutdown()
        self.server.server_close()
        self.tmp.cleanup()
    def request(self, path, payload=None, raw=None, headers=None):
        data = raw if raw is not None else json.dumps(payload).encode() if payload is not None else None
        h = {'Content-Type': 'application/octet-stream' if raw is not None else 'application/json'}
        h.update(headers or {})
        with urllib.request.urlopen(urllib.request.Request(self.base + path, data=data, headers=h), timeout=15) as response:
            body = response.read()
            return json.loads(body) if response.headers.get_content_type() == 'application/json' else body
    def test_source_revisions_job_and_export(self):
        experiment = self.request('/api/experiments', {'title':'Synthetic fixture','participant_id':'synthetic-p','session_id':'s1','mode':'STATIC','data_origin':'SYNTHETIC','approval_reference':None,'notes':''})
        eid = experiment['experiment_id']
        buffer = io.BytesIO(); Image.new('RGB',(64,48),(30,30,30)).save(buffer, format='PNG'); raw = buffer.getvalue()
        media = self.request(f'/api/experiments/{eid}/media/fixture.png', raw=raw)
        mid = media['media_id']
        self.assertEqual(media['sha256'],hashlib.sha256(raw).hexdigest())
        self.assertEqual(self.request(f'/api/media/{mid}/original'),raw)
        self.assertEqual(self.request(f'/api/media/{mid}/original',headers={'Range':'bytes=2-9'}),raw[2:10])
        self.request(f'/api/media/{mid}/annotations', {'frame_index':0,'eyes':{'OD':None,'OS':None},'comment':'first'})
        circle = {'cx_px':20,'cy_px':20,'radius_px':8,'source':'MANUAL_ANNOTATION'}
        self.request(f'/api/media/{mid}/annotations', {'frame_index':0,'eyes':{'OD':circle,'OS':None},'comment':'corrected'})
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request(f'/api/media/{mid}/annotations', {'frame_index':1,'eyes':{'OD':None,'OS':None},'comment':''})
        self.assertEqual(caught.exception.code,400)
        job = self.request(f'/api/media/{mid}/process', {'sample_every':1,'algorithms':['BOUNDARY_Y_RE'],'identity_confirmed':True,'upright_confirmed':True,'annotations':{}})
        for _ in range(100):
            job = self.request('/api/jobs/'+job['job_id'])
            if job['state'] in ('COMPLETED','FAILED','CANCELLED'): break
            time.sleep(.03)
        self.assertEqual(job['state'],'COMPLETED',job)
        self.assertEqual(job['options']['annotations']['0']['OD'],circle)
        self.assertIsNone(job['result']['frames'][0]['eyes']['OS']['prediction'])
        self.request(f'/api/media/{mid}/reviews',{'reviewer_id':'r1','frame_index':0,'eye':'BOTH','label':'UNCERTAIN','comment':'synthetic','blinded':False})
        reference = self.request(f'/api/experiments/{eid}/references',{'eye':'OD','method':'synthetic engineering reference','measured_at':'2026-10-09T12:00:00+00:00','sphere_d':0,'cylinder_d':None,'axis_deg':None,'cycloplegic':None,'examiner_id':'fixture','notes':''})
        self.assertEqual(reference['sphere_d'],0); self.assertIsNone(reference['cylinder_d'])
        sidecar = b'{"origin":"SYNTHETIC","timestamp_ns":null}'
        self.request(f'/api/media/{mid}/sidecars/metadata.json',raw=sidecar)
        exported=self.request(f'/api/experiments/{eid}/export')
        with zipfile.ZipFile(io.BytesIO(exported)) as archive:
            self.assertEqual(archive.read(f'media/{mid}/original/fixture.png'),raw)
            self.assertEqual(archive.read(f'media/{mid}/sidecars/metadata.json'),sidecar)
        restarted = ResearchStore(self.tmp.name)
        self.assertEqual(restarted.original(mid).read_bytes(),raw)
        self.assertEqual(len(restarted.media(mid)['annotations']),2)
        restarted.original(mid).write_bytes(b'tampered')
        with self.assertRaises(ValueError): restarted.export(eid)
    def test_interrupted_recovery(self):
        record={'job_id':'interrupted','media_id':'none','state':'RUNNING','progress':{'done':2,'total':8},'options':{},'result':{'frames':[{'frame_index':0}]},'error':None,'created_at':'fixture','updated_at':'fixture','cancel_requested':False}
        self.server.store.put('job',record,'none')
        manager=JobManager(self.server.store)
        try:
            recovered=self.server.store.get('job','interrupted')
            self.assertEqual(recovered['state'],'INTERRUPTED')
            self.assertEqual(recovered['result'],record['result'])
        finally: manager.shutdown()
    def test_binary_security(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request('/api/experiments',{'title':'bad'},headers={'Origin':'https://evil.example'})
        self.assertEqual(caught.exception.code,400)
        with self.assertRaises(urllib.error.HTTPError):
            self.request('/api/overview',headers={'Host':'evil.example'})

class JobSafety(unittest.TestCase):
    def test_invalid_progress_and_partial_failure_are_retained(self):
        from pathlib import Path
        with tempfile.TemporaryDirectory() as root:
            store = ResearchStore(root)
            source = Path(root) / 'fixture.png'
            source.write_bytes(b'synthetic-source')
            store.put('media', {'media_id':'media','sha256':hashlib.sha256(source.read_bytes()).hexdigest()}, 'experiment')
            store.original = lambda identifier: source
            store.process_options = lambda identifier, payload: {'annotations':{}}
            def analyzer(path, output, **kw):
                partial = {'status':'RUNNING','frames':[{'frame_index':0,'observed':True}], 'artifact_files':[]}
                (output/'result.partial.json').write_text(json.dumps(partial))
                kw['progress']({'done':1,'total':2,'stage':'analyze'})
                kw['progress']({'done':True,'total':2,'stage':'analyze'})
            manager = JobManager(store, analyzer)
            try:
                job = manager.submit('media',{})
                for _ in range(100):
                    job=store.get('job',job['job_id'])
                    if job['state']=='FAILED':break
                    time.sleep(.01)
                self.assertEqual(job['state'],'FAILED')
                self.assertEqual(job['progress']['done'],1)
                self.assertEqual(job['result']['frames'][0]['frame_index'],0)
                self.assertIn('progress',job['error'])
            finally:manager.shutdown()
