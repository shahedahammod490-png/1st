import copy
import tempfile
import unittest
import numpy as np
from ocurisk_lab.models import ModelLab,ALGORITHMS,bayesian_objective,legacy_physics,power_vectors
from ocurisk_lab import cnn

def fixture(a='RIDGE'):
    return {'algorithm':a,'dataset':{'target_name':'engineering target','target_unit':'arbitrary','event_definition':'synthetic Bernoulli event','records':[{'participant_id':f'p{i}','split':'train' if i<12 else 'test','features':{'x':float(i),'z':float(i%3)},'target':float(i)*2+1,'data_origin':'SYNTHETIC','target_origin':'SYNTHETIC'} for i in range(16)]},'config':{'cv_folds':3,'bootstrap_samples':20}}

class ModelsTest(unittest.TestCase):
    def test_regressors_and_frozen_reload(self):
        for a in ALGORITHMS[:-1]:
            with self.subTest(a=a),tempfile.TemporaryDirectory() as root:
                p=fixture(a); lab=ModelLab(root); r=lab.train(p); p['dataset']['records'][0]['target']=999
                self.assertEqual(r['payload']['dataset']['records'][0]['target'],1)
                self.assertEqual(r['scaler']['mean'][0],5.5)
                self.assertEqual(len(r['cross_validation']['folds']),3)
                pred=ModelLab(root).predict(r['model_id'],[{'x':12.,'z':0.}]); self.assertTrue(np.isfinite(pred['predictions'][0]['value']))
                self.assertEqual(r['evaluation']['test']['n'],4)
    def test_leakage_and_numbers(self):
        for change in ('participant','duplicate','nan','bool','origin','reference'):
            p=fixture()
            if change=='participant':p['dataset']['records'][-1]['participant_id']='p0'
            if change=='duplicate':p['dataset']['records'][-1].update(features={'x':0.,'z':0.},target=1.)
            if change=='nan':p['dataset']['records'][0]['features']['x']=float('nan')
            if change=='bool':p['dataset']['records'][0]['target']=True
            if change in ('origin','reference'):p['dataset']['records'][0]['data_origin']='REAL_APPROVED'
            with tempfile.TemporaryDirectory() as root,self.assertRaises(ValueError):ModelLab(root).train(p)
    def test_bayesian_analytic_balanced(self):
        # All zero feature, balanced outcomes: MAP intercept=0, Hessian n/4+prior precision.
        p=fixture('BAYESIAN_LOGIT'); p['config']={'prior_sd':2.,'intercept_prior_mean':0.,'intercept_prior_sd':2.,'posterior_samples':10000}
        for i,r in enumerate(p['dataset']['records']):r.update(features={'x':0.},target=float(i%2),split='train')
        with tempfile.TemporaryDirectory() as root:
            r=ModelLab(root).train(p); self.assertAlmostEqual(r['estimator']['map'][0],0,places=8); self.assertAlmostEqual(r['estimator']['hessian'][0][0],4.25,places=8)
            prediction=ModelLab(root).predict(r['model_id'],[{'x':0.}])['predictions'][0]
            self.assertLess(abs(prediction['posterior_predictive_probability']-.5),.01); self.assertIsNone(prediction['clinical_risk'])
    def test_gradient_finite_difference(self):
        t=np.array([.2,-.7]);z=np.array([[1,2],[1,-1],[1,.4]]);y=np.array([1,0,1]);m=np.zeros(2);prec=np.array([.25,.5]);f,g,h=bayesian_objective(t,z,y,m,prec)
        eps=1e-5
        numerical=np.array([(bayesian_objective(t+np.eye(2)[i]*eps,z,y,m,prec)[0]-bayesian_objective(t-np.eye(2)[i]*eps,z,y,m,prec)[0])/(2*eps) for i in range(2)])
        np.testing.assert_allclose(g,numerical,atol=1e-9);self.assertGreater(np.linalg.eigvalsh(h).min(),0)
    def test_physics(self):
        p={'crescent_ratio':.3,'pupil_diameter_mm':6,'reflex_ratio':.85,'working_distance_cm':100,'flash_eccentricity_mm':12,'optical_constant_k':6,'orientation':'TOP'}
        r=legacy_physics(p);self.assertAlmostEqual(r['raw_legacy_numeric_output'],-2.5);self.assertIsNone(r['clinical_prediction']);self.assertAlmostEqual(r['derivative_unclipped_at_effective_inputs']['crescent_ratio'],-100/12)
        self.assertEqual(power_vectors({'sphere_d':-2,'cylinder_d':-1,'axis_deg':0})['J0'],.5)
    def test_bench_reference(self):
        p=fixture()
        for i,r in enumerate(p['dataset']['records']):
            r.update(data_origin='NON_HUMAN_TEST',target_origin='INDEPENDENT_BENCH_REFERENCE',reference={'source_id':f'bench{i}','method':'model-eye bench','operator_id':'operator','measured_at':'2026-10-09T00:00:00+00:00','apparatus_id':'apparatus','calibration_reference':'calibration'})
        with tempfile.TemporaryDirectory() as root:
            r=ModelLab(root).train(p);self.assertEqual(r['status'],'TRAINED_BENCH_RESEARCH_ONLY')
            p['dataset']['records'][0]['reference'].pop('calibration_reference')
            with self.assertRaises(ValueError):ModelLab(root).train(p)
    def test_explicit_unit_event_and_extreme_numeric(self):
        with tempfile.TemporaryDirectory() as root:
            for field in ('target_unit', 'event_definition'):
                p=fixture('BAYESIAN_LOGIT');p['dataset'].pop(field)
                with self.assertRaises(ValueError):ModelLab(root).train(p)
            p=fixture();p['dataset']['records'][0]['features']['x']=1e308
            with np.errstate(over='ignore',invalid='ignore'),self.assertRaises(ValueError):ModelLab(root).train(p)
            p=fixture('BAYESIAN_LOGIT');p['dataset']['records'][1]['participant_id']='p0'
            with self.assertRaises(ValueError):ModelLab(root).train(p)
    def test_legacy_clamps_and_vector_rotation(self):
        p={'crescent_ratio':1.,'pupil_diameter_mm':1.,'reflex_ratio':2.,'working_distance_cm':200.,'flash_eccentricity_mm':0.,'optical_constant_k':20.,'orientation':'BOTTOM'}
        r=legacy_physics(p);self.assertEqual(r['requested']['crescent_ratio'],1.);self.assertEqual(r['effective']['crescent_ratio'],.8);self.assertEqual(r['clamped_legacy_numeric_output'],8.)
        v=power_vectors({'sphere_d':-2.,'cylinder_d':-1.,'axis_deg':45.});self.assertAlmostEqual(v['J0'],0.);self.assertAlmostEqual(v['J45'],.5)
    def test_malformed(self):
        with tempfile.TemporaryDirectory() as root:
            for p in ({},None,{'algorithm':'RIDGE','dataset':{}}, {'algorithm':'RIDGE','dataset':{'target_name':'x','target_unit':'D','records':[{},{}]}}):
                with self.assertRaises(ValueError):ModelLab(root).train(p)
    def test_registry_corrupt_artifact_and_source_freeze(self):
        from pathlib import Path
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as root:
            lab=ModelLab(root);r=lab.train(fixture())
            (Path(root)/'models'/('a'*32+'.json')).write_text('{')
            registry=lab.registry();self.assertEqual(len(registry['models']),1);self.assertEqual(len(registry['artifact_failures']),1)
            self.assertEqual(next(a for a in registry['algorithms'] if a['algorithm']=='RIDGE')['status'],'TRAINED_VERSIONS_AVAILABLE')
            with patch('ocurisk_lab.models.LOADED_SOURCE_HASH','changed'),self.assertRaises(ValueError):lab.train(fixture())
    def test_image_only_schema(self):
        from ocurisk_lab.models import validate
        p=fixture();p['config']={}
        for r in p['dataset']['records']:r['features']={}
        self.assertEqual(validate(p,allow_empty_features=True)[1],[])
        with self.assertRaises(ValueError):validate(p)
    def test_cnn_gate(self):
        if cnn.availability()[0]['status']=='UNAVAILABLE':
            with self.assertRaisesRegex(RuntimeError,'UNAVAILABLE'):cnn.train('.',{},[])
        else:
            from PIL import Image
            import io
            raw=[]
            p=fixture('CNN');p['config']={'epochs':1}
            for i in range(16):
                b=io.BytesIO();Image.new('RGB',(8,8),(i*10,20,30)).save(b,format='PNG');raw.append(b.getvalue())
            with tempfile.TemporaryDirectory() as root:
                r=cnn.train(root,p,raw);self.assertEqual(len(cnn.predict(r,raw[:1],[p['dataset']['records'][0]['features']])['values']),1)

if __name__=='__main__':unittest.main()
