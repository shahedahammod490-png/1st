'use strict';
// Optional browser evidence test. Requires Python runtime dependencies and Playwright.
// All generated source pixels and capture records are explicitly synthetic.
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const {spawn, spawnSync} = require('node:child_process');
const {once} = require('node:events');
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const playwright = require(process.env.PLAYWRIGHT_MODULE_PATH || 'playwright');

(async () => {
  const root = path.resolve(__dirname, '..');
  const output = path.resolve(process.env.BROWSER_SMOKE_OUTPUT || path.join(root, 'evidence/browser-smoke'));
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'ocurisk-synthetic-browser-'));
  const python = process.env.PYTHON_EXECUTABLE || 'python';
  let server, browser;
  let serverOutput = '';
  const report = {scope: 'SYNTHETIC NONHUMAN ENGINEERING BROWSER TEST ONLY', passed: false, execution_host: 'Linux test host; no Windows or device verification'};
  await fs.mkdir(output, {recursive: true});
  try {
    const image = path.join(temporary, 'explicitly_synthetic_source.png');
    const fixture = spawnSync(python, ['-c',
      "from PIL import Image; import sys; im=Image.new('RGB',(160,100)); im.putdata([(30+x//2,40+y//3,25+(x+y)//5) for y in range(100) for x in range(160)]); im.save(sys.argv[1])", image], {cwd: root, encoding: 'utf8'});
    assert.equal(fixture.status, 0, fixture.stderr);
    server = spawn(python, ['-m', 'ocurisk_lab.server', '--host', '127.0.0.1', '--port', '0', '--data-dir', path.join(temporary, 'data')], {cwd: root, stdio: ['ignore', 'pipe', 'pipe']});
    const url = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Local service startup timed out')), 15000);
      server.stdout.on('data', chunk => {serverOutput += chunk; const match = serverOutput.match(/http:\/\/127\.0\.0\.1:\d+/); if (match) {clearTimeout(timer);resolve(match[0]);}});
      server.stderr.on('data', chunk => {serverOutput += chunk;});
      server.on('exit', code => {clearTimeout(timer);reject(new Error(`Service exited during startup (${code})`));});
    });
    browser = await playwright.chromium.launch({headless: true, ...(process.env.CHROMIUM_EXECUTABLE ? {executablePath: process.env.CHROMIUM_EXECUTABLE} : {})});
    report.browser_version = browser.version();
    const page = await browser.newPage({viewport: {width: 1280, height: 900}});
    const pageErrors = [];
    page.on('pageerror', error => pageErrors.push(error.message));
    await page.goto(url, {waitUntil: 'networkidle'});
    await page.getByText('No captures imported.', {exact: true}).waitFor();
    await page.getByText('No completed runs.', {exact: true}).waitFor();
    assert.equal(await page.locator('#origin').inputValue(), 'NON_HUMAN_TEST');
    report.empty_database_verified = true;
    await page.locator('#image').setInputFiles(image);
    await page.waitForFunction(() => document.getElementById('canvas').width === 160);
    await page.locator('#capture-id').fill('synthetic_browser_smoke');
    await page.locator('#participant').fill('synthetic_nonhuman_participant');
    await page.locator('#session').fill('synthetic_browser_session');
    await page.locator('#device').fill('synthetic_pixel_generator');
    await page.locator('#origin').selectOption('SYNTHETIC');
    await page.locator('#canvas').scrollIntoViewIfNeeded();
    const bounds = await page.locator('#canvas').boundingBox();
    async function circle(eye, x, y, radius) {
      await page.locator('#eye').selectOption(eye);
      await page.mouse.move(bounds.x + bounds.width * x / 160, bounds.y + bounds.height * y / 100);
      await page.mouse.down();
      await page.mouse.move(bounds.x + bounds.width * (x + radius) / 160, bounds.y + bounds.height * y / 100, {steps: 5});
      await page.mouse.up();
    }
    await circle('OD', 45, 50, 15);
    await circle('OS', 115, 50, 15);
    assert.match(await page.locator('#annotations').textContent(), /MANUAL_ANNOTATION/);
    await page.locator('#import-button').click();
    await page.getByText('Process imported frames', {exact: true}).waitFor();
    const captures = await (await page.request.get(`${url}/api/captures`)).json();
    assert.equal(captures.length, 1);
    const manifest = captures[0];
    assert.equal(manifest.data_origin, 'SYNTHETIC');
    assert.equal(manifest.frames[0].eyes.OD.source, 'MANUAL_ANNOTATION');
    assert.equal(manifest.frames[0].eyes.OS.source, 'MANUAL_ANNOTATION');
    assert.ok(manifest.frames[0].eyes.OD.cx_px < manifest.frames[0].eyes.OS.cx_px);
    assert.equal(manifest.distance_m, null);
    assert.equal(manifest.frames[0].timestamp_ns, null);
    assert.equal(manifest.illumination.physical_verified, false);
    report.actual_imported_annotations = manifest.frames[0].eyes;
    await page.getByText('Process imported frames', {exact: true}).click();
    await page.getByText('Immutable run persisted. Clinical outputs remain null.', {exact: true}).waitFor();
    const runs = await (await page.request.get(`${url}/api/runs`)).json();
    assert.equal(runs.length, 1);
    const run = runs[0];
    assert.equal(run.prediction, null);
    assert.equal(run.uncertainty, null);
    assert.ok(run.artifact_files.length > 0);
    assert.ok(run.frames[0].analysis.eyes.OD.artifacts.pupil_mask);
    assert.ok(run.frames[0].analysis.eyes.OS.artifacts.pupil_mask);
    assert.ok(run.frames[0].analysis.feature_definitions);
    assert.ok(run.source_hashes['ocurisk_lab/optical.py']);
    const source = page.locator('#inspection .source img');
    await source.waitFor();
    await page.waitForFunction(() => {const im=document.querySelector('#inspection .source img');return im && im.complete && im.naturalWidth===160;});
    const images = page.locator('#inspection .artifact img');
    assert.equal(await images.count(), run.artifact_files.length);
    for (let i = 0; i < await images.count(); i++) {
      await images.nth(i).scrollIntoViewIfNeeded();
      await images.nth(i).evaluate(img => img.decode());
      assert.ok(await images.nth(i).evaluate(img => img.naturalWidth > 0 && img.naturalHeight > 0));
    }
    assert.equal(pageErrors.length, 0, pageErrors.join('\n'));
    await page.screenshot({path: path.join(output, 'dashboard-synthetic-run.png'), fullPage: true});
    const [download] = await Promise.all([page.waitForEvent('download'), page.getByText('Export actual result JSON', {exact: true}).click()]);
    await download.saveAs(path.join(output, 'exported-synthetic-run.json'));
    const exported = JSON.parse(await fs.readFile(path.join(output, 'exported-synthetic-run.json'), 'utf8'));
    assert.deepEqual(exported, run);
    report.passed = true;
    report.browser_interaction_verified_on = 'Linux test host only';
    report.capture_id = run.capture_id;
    report.run_id = run.run_id;
    report.runtime_versions = run.runtime_versions;
    report.artifact_images_rendered = await images.count();
    report.source_sha256 = createHash('sha256').update(await fs.readFile(image)).digest('hex');
    report.source_hashes = run.source_hashes;
    report.eye_statuses = Object.fromEntries(Object.entries(run.frames[0].analysis.eyes).map(([eye, record]) => [eye, record.status]));
    report.export_download_matches_persisted_run = true;
    report.page_errors = pageErrors;
  } catch (error) {
    report.error = String(error.stack || error);
    process.exitCode = 1;
  } finally {
    await browser?.close();
    if (server && server.exitCode === null) {const stopped = once(server, 'exit');server.kill('SIGTERM');await stopped;}
    await fs.rm(temporary, {recursive: true, force: true});
    await fs.writeFile(path.join(output, 'browser-smoke-report.json'), JSON.stringify(report, null, 2) + '\n');
    await fs.writeFile(path.join(output, 'service-log.txt'), serverOutput);
    console.log(JSON.stringify(report, null, 2));
  }
})();
