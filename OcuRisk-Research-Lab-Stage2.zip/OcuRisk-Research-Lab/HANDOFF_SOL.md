> Current priority: integrate existing Windows DroidCam browser capture and automatic quality analyzer in this Lab; contracts/DROIDCAM_QUALITY.md is the shared extension. Android APK is optional, not prerequisite. Read PROJECT_STATUS.md before historical tasks below.

# Detailed implementation handoff — lead scientific architect → GPT-6.1 Sol

This handoff remains usable in a separate Work task. Sol is the primary application engineer; lead owns research, architecture, experiment design, acceptance and review. Direct Sol delegation was available and used for the service, optical and Android modules in LAB-0001. Independent verifier is a different agent, not Opus; no particular verifier model identity is claimed. Original integration is prohibited until user explicitly authorizes it after validation.

## Start and continuation

1. Read PROJECT_STATUS, REPOSITORY_AUDIT and both detailed audit reports; do not rely on prior EYE registries as current evidence.
2. Read all supplied directives and three PDFs, then ARCHITECTURE, this handoff, contracts/INTERFACES and STAGE_ACCEPTANCE.
3. Run existing Lab tests, checksum protection check and retained counterexamples. Read TEST_REPORT before claiming regression or success.
4. Read independent verification findings. Critical/high unresolved findings block the affected module; do not approve your own scientific claim.
5. Implement highest eligible priority below; keep UI capability registry and status truthful. Preserve old runs/configs and raw bytes. Update decisions/tests/status before stopping.

## Protected boundaries

Never write to original EYE source, configuration, dependencies, Git history, SQLite, browser data or uploaded ZIP/PDFs. All development occurs in OcuRisk-Research-Lab. No original merge/PR/migration/deployment is authorized. Archived legacy copies can be used only as explicit uncalibrated comparators; preserve exact source hashes, complete formulas and default configuration. Do not silently replace an old algorithm with a different one under BASELINE_OLD.

Code ownership: Sol service owns schema/store/server/dashboard/evaluation; Sol optical owns optical/replay/tests; Sol Android owns android/windows transport/tests. Lead owns scientific documents/contracts/status/protection/integration review. Separate worktrees are preferable for later isolated repositories; current filesystem uses disjoint ownership, root-controlled integration and no concurrent commits.

## P0 — Foundation, already delegated

| Module | Required inputs/outputs and behavior | Tests/acceptance |
|---|---|---|
| schema | Deep CaptureManifest validation; stable ASCII IDs; enum mode/origin; both eye keys; finite geometry; ns decimal strings; missing measured values null; real origin requires approval reference | NaN/Infinity/bool numeric rejection, duplicate JSON keys, timestamps zero preserved, frame indices unique, monotonic known timestamps, safe basename/path |
| store | Raw image bytes+manifest → checksum-verified immutable capture; source names exactly match declared frames; SQLite atomic writes; rollback/duplicate flagging | Tampered hashes, extension/format spoof, unreadable/transparent/oversized image reject; failed import leaves no capture; raw replay mutation detected |
| server | Loopback HTTP APIs; actual persisted capture/run/artefact/export data; bounded JSON uploads; original paths unreachable | HTTP roundtrip; unknown IDs404; input4xx; safe whitelist media; cross-origin/DNS-rebinding rejection; no public bind; no cloud calls |
| dashboard | Empty startup; upload image, anatomical OD/OS manual circles, documented mode/origin; inspect raw, normalized, masks/maps/quality/units/definitions/config/provenance; export actual result | UI load, upload→annotate→process→inspect→export; true error shown; no fake model metrics; no auto approval claim; source+code hash visible |
| run provenance | Run ID/time + raw SHA256 + manifest/config/hash + algorithm/version + exact code source hashes + Python/NumPy/Pillow/platform versions | Immutable run, identical inputs/config give identical numeric result/artifact hashes; mutation creates new version, no stale output |
| evaluation | Descriptive signed error metrics and coverage; explicit participant-split/exact-hash audit | Independent known expected values, undefined denominator null, insufficient SD null; repeats/eyes not independent N; limitations visible |

`GET /api/images/{capture_id}/{filename}` is permitted for manifest-whitelisted raw media. Detailed API shapes are in INTERFACES. Initial importer is a still/frame collection importer; selecting VIDEO_RIGHT metadata does not prove continuous video acquisition or timing completeness.

## P1 — CMF acquisition proof, hardware-first

CameraX first; only add Camera2 request control where actual requirements/device tests justify it. Enumerate IDs/capabilities; do not assume first rear camera is main or that every logical camera uses one fixed physical lens. Export available physical IDs, sensor orientation/active array/size/intrinsics/focal lengths if supplied, hardware level, formats/sizes/FPS ranges, flash flag, AE/AF/AWB modes/locks, exposure/ISO/focus ranges, stabilization, request/result keys, timestamp source, sensors. Missing metadata remains null, not advertised spec.

Default light OFF. Separate still flash and continuous torch. Log requested values separately from observed TotalCaptureResult and external LED observation. Torch future-completion/CameraInfo state alone is not a photometric safety measurement. Use nonhuman calibration targets during engineering. Stop/background/error must turn light off. No eye illumination instructions until qualified configuration-specific safety/research approval.

JPEG export: finalized media+sidecar+hash manifest. Native ImageProxy timestamp and result sensor timestamp must actually match or association is UNKNOWN. Callback index/time is not exposure identity. Android timestamps are decimal strings. REALTIME/UNKNOWN timestamp source affects IMU synchronization. `KEEP_ONLY_LATEST` drops preview analysis; it cannot establish complete saved-video coverage. Test Preview+ImageCapture and Preview+VideoCapture separately before extra bindings. Actual bound dimensions and lens identity are recorded. Source-only/unbuilt code must never be called a verified phone app or provided as a nonexistent APK.

Windows/USB first uses ADB install/run-as export/pull with explicit serial, then local immutable import. Read-only diagnostics record actual build/model/SDK/camera dump. Do not wipe/reset/install other apps. `adb reverse` is optional next, not a prerequisite; use authenticated one-session import if enabled. USB debugging does not expose the LED/camera to PC by itself.

Required handoff output: Android build logs/versioned APK checksum if build exists; host script tests; real device capability JSON; nonhuman image/metadata paired samples; transfer hash verification; failures including unavailable controls. H0–H7 in HARDWARE_FEASIBILITY is the physical gate sequence. The native still exporter now supplies the Lab manifest and separate native sidecars. Preserve and associate those sidecars in the backend after real sample verification; current image imports do not retain every native capability/result attachment. Never manufacture pupil annotations, clinical references or timestamps.

## P2 — Image features and replay

First candidate uses manually annotated pupil circles. This establishes processing code, not automated segmentation. Coordinate convention: x right/y down in decoded stored image, normalized pupil x/y ∈[−1,+1], clockwise positive image angle from +x. Preserve native orientation/mirror provenance; never silently normalize away the source-camera meridian. Overlapping OD/OS annotations must be flagged as identity conflict. Clipped/out-of-field annotations remain INCONCLUSIVE; retained maps are invalid diagnostic artifacts.

Required maps follow directive definitions on explicitly declared normalized code values R,G,B:

\[
RD = R / ((G+B)/2 + \epsilon),\quad RE=R-(G+B)/2,\quad Y=.5R+.25G+.25B.
\]

Declare epsilon/encoding; these are gamma-encoded camera feature maps, not linear radiance or clinical variables. Any BT.709/different representation gets a distinct name/config/change record. Preserve raw RGB and numeric values; map PNG encodings/limits must be documented so visualization scaling is never confused with feature values.

Glint candidate: connected compact bright regions, clipping and coverage independently reported. Large bright field must not become one accepted glint/reflex. Candidate crescent: adaptive threshold on specified map, pupil/valid mask minus candidate glints, boundary-connected components, area/boundary contact/centroid/orientation/radial position. Uniform/black/white inputs must not acquire a nonzero **new** crescent candidate. A boundary-connected patch may still be glare or eyelid: UI says candidate, segmentation validation is independent.

Fit `I=a+bx*x+by*y` by least squares on valid pupil pixels; report intercept, gx,gy,magnitude,atan2 angle, residual/available coverage and exact intensity/normalized-radius units. Polar bins16×72 retain angle origin/missing cells/transform and numeric arrays where feasible. Initial qualitative masks/PNG are not enough to quantify future clinical performance; persist lossless arrays or versioned feature tables for comparisons.

Retain adapted old per-eye brightness contrast separately from exact pooled legacy detector. Name ADAPTED_OLD, expose its artificial .08 minimum and threshold definitions; do not call it measured crescent height. Implement a faithful full original replay harness later using exact archived source/config and separate historical fallback status, without importing its false predictions into default results.

Replay fixtures: same saved real frames when available plus explicitly synthetic unit fixtures; hash raw inputs/config/implementation/artifacts; output structured feature diffs and mask changes. Reject overwriting an existing run/output. Unit cases: uniform, saturation, dark, small/large glint, disconnected bright region, boundary patch, analytic planes, rotated/mirrored coordinate cases, clipped/missing/overlapping circles, independent asymmetric eyes. Clinical names/diopters remain null.

## P3 — Automatic pupil/iris alternatives and video

Compare manual annotation baseline, legacy Otsu/radial candidate, connected-component dark-region pupil with ellipse fit, and supervised segmentation only after annotated images exist. Do not set a population iris diameter as per-person physical scale. Test dark iris/eyelid/eyelash/roll/motion/exposure/no pupil; retain fits/masks/failures. Use blinded annotators and report inter-annotator disagreement. Dice/IoU plus boundary error/false detection/gradable rate, with subject-level uncertainty; a mathematically clean mask can still be the wrong structure.

Decode **all recorded** video frames with source PTS/time base; log corruption/dropped/duplicate frames instead of fabricating fps. Both eyes every frame, including missing states. Store OD_RIGHT/OS_RIGHT/OD_LEFT/OS_LEFT throughout. No automatic direction→eye assignment. Compare best view, both-view fusion, primary/complementary per eye on held-out subjects. Live coaching can subsample only with explicit difference from complete offline replay.

Phone/head pose measurements have coordinate frame/method/calibration/status. IMU alone gives orientation, not translation/distance; human annotated angles are not equivalent to measured pose. Fixation target/head pose needed to disambiguate geometry and gaze. Head turn is a separate hypothesis.

## P4 — Model infrastructure after acquisition/reference gate

No fitted model, diopters, performance, calibrated confidence or winning pipeline exists at handoff. Registers show true blockers. Start with constant train-mean baseline, archived numeric legacy comparator, Ridge/ElasticNet. Use Random Forest/Gradient Boosting next; small MLP/CNN only if data volume and evaluation justify them. Device-specific physics requires a traceable derivation with coherent SI units, feature definition, camera/source aperture geometry, valid range and calibration. There is no verified universal K6 replacement available from the source audit.

Pipeline transformers fit only training data; participant-grouped nested validation tunes hyperparameters, preprocessing, threshold and acquisition choices. Freeze final subject test cohort/version. Mask references, filenames, prescription/context, folders, dates and IDs from optical inputs. Both eyes/repeated frames stay together. Check exact and near duplicates across all sets; assess device/domain leakage. Save every candidate/config/failure, not only the best. CNN embeddings/Grad-CAM/SHAP are descriptive, not causal proof.

Power vectors M/J0/J45 are appropriate mathematical targets when reference sphero-cylinder data exist, but not enough to make astigmatism identifiable from a single scalar. Residual hybrid `SE_final=SE_physics+deltaSE` requires a genuinely defined physics prediction and train-only residual fitting. Hold-out improvement must beat simpler baselines with paired subject-cluster intervals.

Output contract: prediction, target/unit, calibrated uncertainty/method/scope, quality/abstention, model/calibration/dataset/source versions. Until calibration/reference gates pass: prediction:null, uncertainty:null, state AWAITING_REFERENCE_DATA/INCONCLUSIVE. No arbitrary confidence percentages. External devices/OOD conditions can abstain DEVICE_UNCALIBRATED.

## P5 — Bayesian/risk research

See research/BAYESIAN_RESEARCH.md. Legacy additive score is a heuristic, not a Bayesian posterior. Current screening, future onset/progression and referral outcomes are distinct targets. Define event, time horizon, units, population and independent outcome adjudication before fitting. Context belongs in risk, never covert optical correction. Test correlated predictors/double counting/missingness. Compare logistic baseline and explicit Bayesian logistic/hierarchical alternatives, checking prior sensitivity, posterior predictive behaviour and calibration. Five-year prediction/intervention benefit requires appropriate longitudinal outcomes; do not extrapolate a cross-sectional score.

## Scientific and engineering review separation

The engineer reports objective, files, tests, exact results, input origin, code/config hashes, unresolved issues and integration needs. The lead evaluates whether those results answer the experiment. Independent verifier tests separately and assigns severity/status/dispute records. Unit-test success establishes only the tested code behavior. Real optical/clinical acceptance requires independent measurements and preregistered scope/tolerances. All unresolved critical findings block scientific acceptance; user still selects integration.

## Current implementation priority

Finish independent verification of foundation → build native probe on target Windows machine → actual nonhuman CMF diagnostics/captures/transfer → measure geometry/timing → complete video and automatic segmentation replay → approved pilot/reference dataset → model fitting → risk → frozen held-out comparison → independent scientific review → integration recommendation only. Independent source research/derivation, experiment design and statistical criteria continue while engineering/hardware work progresses.


## Stage2 continuation update — 2026-10-09

Stage2 is implemented incrementally on lab-stage2-recovery. Read current RESUME_HERE, TASK_BOARD, PROJECT_STATUS, contracts/STAGE2 and owner reports before interpreting older roadmap rows. Models/video are now integrated; UI/backend/native completion and exact independent verdict are tracked in current status. Preserve all worktrees, including uncommitted files, in checkpoints. Root stays scientific architect; Sol remains primary engineer. Do not restart already implemented modules or claim old test logs cover changed source.
