# DroidCam browser interface implementation

Current application Capture Studio now requests camera permission only from an explicit button, lists actual OS video inputs with permission-dependent labels, opens the selected input using an exact deviceId constraint, and exposes actual track settings/constraints/capabilities. A missing secure context/mediaDevices or MediaRecorder is an unavailable state. No fake feed is shipped.

Actual MediaRecorder timeslice blobs are combined only after finalization. Source bytes are retained through existing media import; capture-quality.json is appended before automatic processing. Snapshots use actual preview source pixels. Failed saves leave a download link; partial recorder/disconnect/route-leave recordings are retained with partial/error metadata and skip automatic analysis. Route leave stops tracks and attempts download of finalized partial bytes. Recording memory stops at the 256 MiB boundary; a final recorder chunk may cross that bound, in which case server save is refused and the bytes remain downloadable. Camera selection changes require stopping an active recording.

Both live sources and uploaded files accept user-declared USB/WIFI/UNKNOWN, paired/target IDs, stationary target assertion, source-pixel chart ROI and optional declared app/client/filter/focus/exposure/white-balance settings. Preview dragging selects an ROI using source resolution. OD/OS identity remains unconfirmed by default; existing bilateral analysis is queued without invented anatomy. rVFC observations are bounded compositor callbacks, explicitly not sensor time or reliable live source PTS; zero/duplicate mediaTime remains preserved. Recorder codec/bitrate concerns the saved stream, not original DroidCam transport.

Capture Studio includes actual completed-job comparison, eligibility/warnings, per-recording descriptors, source-PTS brightness and sharpness proxy graphs and actual JSON downloads. Optical Workspace shows measured acquisition quality and detailed source-PTS gap events through the raw summary. No universal transport winner or clinical metric is produced.

## Verification

- `node tests/browser/live-capture.cjs`: PASS explicit selected device constraints, combined finalized bytes, permission rejection, disconnect partial retention, byte-bound stop, track cleanup and source-pixel ROI validation. Mocks are explicit test fixtures.
- `node tests/browser/ui-data.cjs`: PASS existing manual provenance and CSV parser cases; loader updated to strip all ES module imports.
- ES module syntax checks: PASS app, live-capture, quality-workspace and optical-workspace.
- `node tests/browser/droidcam-ui.cjs`: attempted actual Playwright interaction using an explicitly synthetic browser camera fixture. BLOCKED before launch: no installed Chromium headless executable. No screenshots, browser interaction acceptance, physical DroidCam or Windows execution claimed. A bounded 60-second Playwright Chromium install attempt failed: download yielded an invalid/truncated ZIP (end-of-central-directory signature absent). Actual install and second launch logs are retained in research/droidcam-browser-install.log and research/droidcam-browser-execution.log. Root integration may rerun this script if a compatible browser becomes available.

Physical acceptance requires the user's Windows/Linux OS virtual webcam, real DroidCam selection and matching actual USB/WiFi inert-target acquisitions. Software tests do not verify camera feasibility, sensor frame timing, transport or optical accuracy. UI source ownership is web files and browser tests only; no backend files or Git commits were made.

Final UI refinements: completed-job checkboxes show experiment/source/direction/declared connection/date; manual IDs are advanced fallback. Per-frame diagnostic display is limited to the first 20 flagged frames, with complete actual data in JSON. Camera request generation guards stop tracks from pending or overlapping superseded requests. Recording saves freeze experiment/direction/mirroring/quality at start, disable those fields, and stop normally at a conservative 120-second engineering resource bound; reaching it finalizes a complete source and permits automatic processing. Actual recorder/track errors remain partial. No scientific acquisition duration is claimed.

UI authored sources and tests are frozen pending root integration/independent review; no Git commits.

Final resource correction: 120-second automatic normal stop avoids the ordinary 30-FPS/10,000-frame backend mismatch caused by the former 600-second guard. Higher source frame rates remain subject to actual backend frame limits; the duration is an engineering bound, not an acquisition study requirement.
