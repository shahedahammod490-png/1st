# Optical research after the engineering handoff

Lead scientific architect, 2026-10-08. Ongoing targeted primary-source review. No CMF measurement, derivation-calibrated coefficient or optical performance is established. E01–E10 are in EVIDENCE_REVIEW.

## Additional primary evidence

E11: Roorda, Campbell and Bobier, *Slope-based eccentric photorefraction: theoretical analysis of different light source configurations and effects of ocular aberrations*, JOSA A14:2547–2556 (1997), DOI https://doi.org/10.1364/JOSAA.14.002547; publisher https://opg.optica.org/josaa/abstract.cfm?uri=josaa-14-10-2547 and PubMed https://pubmed.ncbi.nlm.nih.gov/9316272/. Abstract and accessible publisher summary table inspected; full equations/derivation are paywalled. Theory describes dependence on source extent/eccentricity, pupil size and aberration/source azimuth. Opposite-source averaging addresses an aberration effect in its specified design. It does not prove whole-phone lateral video reproduces the same source geometry. Its tabulated 1 m working ranges are instrument/model examples, not our usable range. No numeric table value is used as a CMF acceptance bound.

E15: Wesemann, Norcia and Allen, *Theory of eccentric photorefraction (photoretinoscopy): astigmatic eyes*, JOSA A8:2038–2047 (1991); primary publisher lead https://opg.optica.org/josaa/abstract.cfm?uri=josaa-8-12-2038. Author PDF https://www.wwesemann.de/wp-content/uploads/2018/01/40_1991-Wesemann-Photorefraction-JOSA.pdf timed out and usable full derivation remains unavailable. Search snippets contain an equation with sign-dependent conventions; it is **not accepted or implemented**. Next source-access task: independently inspect the full derivation, definitions/signs, aperture geometry, astigmatic meridians and valid domain before writing any replacement formula.

## Geometry specification, not diopter prediction

Let C be the selected camera optical center, L the effective source center and n a unit eye-to-camera observation direction in one declared common coordinate frame. The projected baseline is

\[
b_\perp=(I-nn^T)(L-C).
\]

This vector is a geometry descriptor, not a photorefraction law. Record units, coordinate frame, measurement method/uncertainty and physical lens selection. A rigid phone roll changes baseline direction; digital image roll does not change physical illumination. Translation, yaw/pitch and head/gaze changes alter observation direction and projected geometry differently. Do not assign an arbitrary angle-to-diopter multiplier. An extended white LED has spatial/spectral output, so its effective optical source may differ from a measured housing center; that approximation must be tested.

The original expression K*c*d/(e*p) is not accepted merely by dimensional plausibility. Definitions must establish whether c is length or fraction, p is physical diameter or pixel quantity, e is baseline/eccentricity, d is object distance, camera aperture/focus correction and K carries which units. Converting px to mm by a universal iris diameter hides an unmeasured assumption. No full traceable derivation for the shipped K6 was verified. A single contrast number cannot uniquely recover sphere/cylinder/axis.

## Measurement distinctions

Implemented RD/RE/Y are gamma/code-value features with stated definitions. A spatial image gradient can change because of exposure/AWB/tone mapping, pupil clipping/diameter, corneal glare, source azimuth, accommodation/gaze, aberrations, camera focus or defocus. A bright boundary component is not automatically a retinal crescent. The feature-normalization coordinate radius is not physical pupil radius. Green/red spectral response and JPEG processing are not controlled radiometry. Retain raw bytes, camera metadata, masks and failure states rather than declaring stronger gradient better.

E02/E03/E11 collectively motivate calibration and bounded-domain identifiability checks. This is an inference from related instruments/theory, not measured CMF behavior. Characterize response across known model-eye defocus/meridians/pupil conditions with independent apparatus calibration, repeats, source modes and exposure controls. Look for dead zone, sign ambiguity, saturation, slope reversal and participant/device variability. Relative trial-lens calibration is different from absolute refraction, and model-eye success cannot establish human screening performance.

## Next safe scientific work

1. Retrieve and audit full historical geometric equations; produce a symbol/unit/sign/domain table and reproducible limiting-case calculations reviewed independently. Do not invent missing equations.
2. Prepare a nonhuman apparatus/protocol with measured selected lens/source geometry and known optical reference, independently checked defocus sign and units. Apparatus construction/physical measurements require an operator.
3. Plan blinded pupil/glint/crescent annotation, including dark iris, eyelid/glare/saturation and absent-reflex negatives; test real laterality labels, not image-side assumptions.
4. Build acquisition comparisons that separate physical roll, lateral translation/yaw and head turn with fixation/gaze controls. Save both eyes in both directions and all failures.
5. Only after safety/permission/reference gates, determine which calibrated features/model domain supports a defensible endpoint. If no geometry yields reproducible useful signal, stop that method and report failure; software polish cannot rescue absent optical information.
