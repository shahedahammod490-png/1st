# DroidCam acquisition evidence and scientific measurement specification

Research-only author: droidcam_science, 2026-10-10 Asia/Dhaka (retrieval 2026-10-09 UTC). Read contracts/DROIDCAM_QUALITY.md, OPTICAL_RESEARCH.md and EVIDENCE_REVIEW.md. No application changes, original-project changes, camera measurements or human experiments. User reports that CMF Phone 2 Pro already connects through both USB and Wi-Fi; that is user evidence, not a laboratory verification by this agent. DroidCam is primary. A new Android APK is optional only after an essential unmet capability is demonstrated.

## Evidence inspected and what it establishes

Primary links below were opened in this research turn. API specification existence does not guarantee an implementation on this phone, driver or browser. Candidate/draft specifications remain identified as such.

| ID | Primary source and inspection | Supported fact and boundary |
|---|---|---|
| DC1 | [Official Windows client](https://droidcam.app/windows/), current page v7.2 | Windows 10/11 client exposes “DroidCam Video” as a regular webcam. It is the OS video input for browser capture. Does not verify user's installed version. |
| DC2 | [Official FAQ](https://droidcam.app/help/), complete retrieved page | Classic/current clients differ. Current webcam supports up to 1080p; OBS plugin path can support 4K. Client supports transforms/color filters; phone supports video quality and Android custom bitrate. Pro remote controls include exposure/focus/zoom. Available CMF controls and absolute exposure/white-balance locks are unverified. Vendor's general USB stability suggestion is not our USB/Wi-Fi result. |
| API1 | [W3C Media Capture and Streams](https://www.w3.org/TR/mediacapture-streams/), candidate recommendation draft; getSettings/constraints passages | getSettings reports current target settings, which can differ from measured performance. Requested resolution/FPS are not measured sensor resolution/FPS. Exact selected device constraint can fail. |
| API2 | [W3C MediaStream Recording](https://www.w3.org/TR/mediastream-recording/), bitrate/data/error passages | Bitrate is an encoder hint. Individual timeslice blobs need not be playable; completed combined data must be. MIME support does not assure sufficient recording resources. Muted tracks can produce black video. |
| API3 | [WICG video-frame callback proposal](https://wicg.github.io/video-rvfc/), metadata/timing passages; community proposal, not W3C standard | presentedFrames counts compositor submissions; callback omission can reflect browser load. mediaTime is presentation time and may be zero for live streams. Optional captureTime is best effort; virtual-driver timing is not established CMF sensor timing. |
| API4 | [W3C Image Capture](https://www.w3.org/TR/image-capture/), settings/capabilities/3A passages | Defines exposure, white balance and focus capabilities, with device-dependent support. Recognition of a constraint is not support on selected track. This Lab should retain observed capabilities only, never claim a remote control succeeded solely because API exists. |
| TOOL1 | [FFprobe documentation](https://ffmpeg.org/ffprobe.html), show_frames/show_streams/count_frames | Can inspect the saved stream's dimensions, frames, timestamps and metadata. Packet count differs from decoded frame count. Missing/inapplicable fields can be omitted. |
| TOOL2 | [OpenCV Laplacian tutorial](https://docs.opencv.org/4.x/d5/db5/tutorial_laplace_operator.html), redirected current docs 4.13; deployed version separately pinned | Laplacian measures spatial derivatives. Variance used as a sharpness score is an engineering proxy, not an absolute optical focus measurement. |
| OPT1 | [Roorda et al. 1997 publisher](https://opg.optica.org/josaa/abstract.cfm?uri=josaa-14-10-2547), abstract/table accessible; full equations inaccessible | Predicted photorefractive slope depends on source geometry, pupil size and aberration/source azimuth. Paper's source averaging design does not establish head-turn equivalence. No published numeric operating range is transferred to CMF. |

The delivered chain is phone sensor/processing → DroidCam encoding/link → Windows client/virtual camera → browser track → browser recorder → stored file → FFmpeg RGB. It can contain scaling, color conversion and a further encoding stage. Thus saved codec/bitrate describe the stored stream, not the first DroidCam transport encoding. This is an inference from the documented components, not a trace of the user's installed pipeline. Save installed app/client/browser versions and known filter/crop/mirror/zoom settings as user-declared metadata. Unknown remains unknown.

## Automatically measurable quantities and limitations

| Program quantity | Scope and meaning | Must not claim |
|---|---|---|
| Decoded width/height and frame count | Actual stored decoded frames; retain source-coordinate dimensions | Native sensor resolution or number of frames originally exposed |
| PTS intervals; (N−1)/(last−first), median/std/CV; nonmonotonic/duplicate times | Stored presentation timeline. Null rate if insufficient strictly advancing timestamps. Median gaps flag irregular delivery/encoding | Sensor clock, exact camera frame loss or transport latency |
| Browser callback observations | Browser performance clock, mediaTime and compositor count. Preserve clock identity. Zero/constant mediaTime is unusable for temporal-rate inference | Every callback corresponds to a unique CMF exposure |
| Long-interval flags / nominal missing-interval estimate | Explicit configured ratio to baseline positive interval; estimate with assumptions | Exact dropped frames. A deliberately variable-rate file is not necessarily defective |
| Luma/RGB means and clipped fractions | Decoded code values with explicit weights/thresholds; per channel clipping useful | Radiance, lux, true sensor clipping, ISO or exposure duration |
| Laplacian variance/edge strength | Scene/ROI/resolution-dependent sharpness proxy | Universal in-focus cutoff; higher score always better (noise/sharpening can raise it) |
| Brightness and RGB/chromaticity drift | Repeatability on fixed chart ROI with stationary assertion; full scene is content-confounded | Auto-exposure/white-balance cause proven, or color accuracy. Dark denominator makes chromaticity unavailable |
| Frame differences and sharpness during motion | Interframe change proxy plus blur evidence | Measured head angle/speed, rolling-shutter distortion, or causal motion blur without a controlled reference |
| 8-pixel grid boundary discontinuity excess | Block-grid artifact proxy; preserve grid/config/ROI | All compression artifacts or a codec-quality score; modern codecs use other grids; real scene lines can trigger it |
| FFprobe codec/bitrate | Stored-stream metadata; absent fields null. Any size/duration estimate explicitly labelled and scoped | Original link bitrate, lossless acquisition, or higher bitrate necessarily better |
| Exact duplicate decoded pixels | Count equality observed after decoding | Proof of repeated sensor frames: a truly stationary/noiseless fixture also repeats |

Gamma/code-value luma should be called luma, not physical luminance. BT.709 weighting is a declared feature definition; absent stream color metadata does not justify claiming BT.709 physical colorimetry. Clipped bright pixels can be real glare or intended white chart regions. Low values do not diagnose a normal eye or absent disease. Global metrics are separate from eye/pupil-region metrics.

## Confounds relevant to candidate retinal features

These are scientific design risks/inferences, not measured CMF effects. AE/tone mapping can alter intensity slopes and threshold masks during a sweep. AWB/color correction can alter red-excess features. Defocus, denoising, resizing, chroma subsampling and compression can displace small crescent boundaries or erase weak detail. Corneal glare may be bright without being retinal reflex. Focus breathing, digital zoom and crop alter apparent pupil size; pixel diameter is not physical pupil diameter. A mirrored preview must not silently change OD/OS anatomy labels.

Physical illumination baseline/azimuth, source extent/spectrum, working distance, camera selection, gaze, pupil size and model-eye reference remain essential independent optical quantities. Digital rotation does not rotate the physical emitter baseline. STATIC, paired VIDEO RIGHT/LEFT and HEAD-TURN identify acquisition procedures; they do not establish diopters. Both eyes require their own retained candidate/failure evidence in each video. Successful transmission plus a sharp chart proves acquisition behavior only, not retinal-red-reflex availability, safety or clinical performance.

## Nonhuman matched USB/Wi-Fi procedure

1. Mount the same phone/lens and a matte stationary target with gray/color patches and fine edge detail. Record target identity, working distance, physical orientation, lighting identity, app/client versions, settings and filters; no illuminated human eyes. A printout permits repeatability, not certified color accuracy.
2. Choose a fixed source-pixel chart ROI containing the same patches, matched resolution, browser/recorder configuration and DroidCam quality settings. Disable optional transformations/beautification/color filters if present; otherwise record them. Keep lighting, framing and focus unchanged. Note whether controls are observed, user-declared, or unknown. Do not assume exposure compensation means manual shutter lock.
3. After the user has switched DroidCam transport, label USB or WIFI USER_DECLARED. Use a common pair/target ID. Record matched durations after a consistent settling period; retain all startup samples and mark any analysis-window choice. Provisional protocol: at least three independent clips per connection in alternating order, then more if variability prevents a stable comparison. This repeat count is a research-design choice, not a clinical threshold.
4. Automatically analyze every decoded frame. Report per-clip time series, missing-time diagnostics, saturation, sharpness, brightness/RGB variability, duplicate pixels and artifact proxy. Compare per-recording summaries; do not treat thousands of temporally correlated frames as thousands of independent experiments. Show actual pairwise differences and repeated-clip spread; no universal winner.
5. Reject an eligible matched comparison if target, ROI, resolution, codec or stationary assertion differ, but still show individual measurements and mismatch reasons. Same metadata does not prove same lighting/geometry, so residual confounds remain. An optional separate motion trial uses the same repeatable nonhuman moving edge/turntable stimulus in each mode; it must not be pooled with stationary-chart stability trials.

## Compression and timing validation beyond simple proxies

Controlled offline experiment: retain an identical lossless frame sequence with known timestamps, encode it at several settings, decode/register the outputs, then measure pixel error/edge displacement and candidate-feature changes against the retained reference. This isolates that encoding stage, not the phone-to-PC link. A printed chart alone cannot provide a pixel-identical original sensor reference or prove link compression error. Comparing independent phone and PC recordings is confounded unless optics, time correspondence and processing are independently controlled.

A photographed counter/display can expose temporal skips qualitatively but screen refresh/persistence, rolling shutter and unsynchronized clocks must be accounted for. Exact exposure-frame loss or photon-to-display latency requires independent synchronized events/instrumentation. Do not add exact loss/latency fields on the strength of file PTS alone.

## Thresholds, uncertainty and stage acceptance

No universal clinical minimum FPS, pixel resolution, pupil diameter in pixels, sharpness, illumination duration or allowable color drift is established here. Existing 250/5 clipping and 1.5× interval gap settings are transparent configurable engineering diagnostics only; preserve thresholds/config in each result. Establish method-specific bounds later from known optical references and repeatability, then freeze them before independent evaluation.

Software acceptance: analytical RGB/constant/ramp fixtures; controlled fixed-scene blur ordering; clipping boundaries; invalid/black ROIs; dropped/missing/nonmonotonic timestamp fixtures; VFR; source metadata unavailable; stationary assertions/confounding; matched/mismatched comparison; actual encoded fixture decode/count/PTS; persistent/exported identical provenance. Simulated fixtures must be marked SYNTHETIC. Browser test success demonstrates browser functionality, not CMF hardware.

Physical acceptance requires the user to select the real DroidCam input, record and save nonhuman clips over USB and Wi-Fi, confirm correct source/geometry/orientation, and return actual diagnostic exports. Optical acceptance requires a calibrated nonhuman optical reference and independently reviewed definitions/signs/units. Human illumination remains blocked pending qualified configuration-specific optical safety and applicable ethics/consent; known E09/E10 sources do not certify CMF. A custom native acquisition path is justified only by a demonstrated essential limitation, such as unverifiable exposure control or insufficient useful detail, and does not itself solve optical identifiability or safety.

## Actual outcome

Research specification/evidence completed. No USB/Wi-Fi comparison result, compression effect magnitude, retinal-reflex acquisition or refractive accuracy was measured by this task. Root/Sol implementation and test evidence must be recorded separately.
