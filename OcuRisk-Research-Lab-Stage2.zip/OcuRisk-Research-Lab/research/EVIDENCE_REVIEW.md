# Optical, acquisition and scientific evidence review

Review date: 2026-10-08. Owner: evidence_hardware subagent, read-only research role before this documentation handoff. All three supplied PDF texts and the Master Research and Engineering Directive were read, including gaps from truncated extraction output. The original project was not modified. No hardware or clinical tests were performed by this workstream.

## Interpretation rules

Published numbers below are **LITERATURE BENCHMARKS**, never OcuRisk results. Evidence about one instrument or population does not validate our CMF Phone 2 Pro configuration. Source inspection depth is explicit: abstracts and figure captions do not establish full methodology. A literature-supported principle is distinct from a validated implementation of that principle.

## Findings requiring action

1. The named Howland & Howland 1974 reference in v3 section 21 is bibliographically incorrect. The publisher identifies *Photorefraction: A technique for study of refractive state at a distance* as JOSA 64(2):240–249, DOI 10.1364/JOSA.64.000240, not the listed Optica Acta citation. The inspected paper abstract describes a special segmented cylindrical-lens camera attachment and star patterns. It does not establish the shipped smartphone formula `K*c*d/(e*p)`.
2. The shipped equation therefore remains **UNVERIFIED / UNCALIBRATED BASELINE**, pending a traceable derivation, definitions of all quantities, unit consistency, sign convention, camera-distance focus correction and reference calibration. Do not replace it with another formula merely taken from a patent or abstract.
3. Smartphones, CNN screening, multimeridian acquisition and mobile video/ML photorefraction have prior art. A generic smartphone + red reflex + AI novelty claim is unsupported.
4. Real rigid phone roll can rotate the physical LED-camera baseline meridian while often preserving its separation magnitude. It is different from digital image rotation, lateral translation, yaw/pitch, or head/gaze rotation. Geometry must be measured rather than summarized as an arbitrary angle-to-diopter rule.
5. Segmentation, refractive estimation and screening classification require separate validation. A visible crescent is not sufficient evidence of accurate refraction; an absent crescent does not prove emmetropia.

## Primary scientific registry

### E01 — Smartphone CNN classification

- Title: *Deep Learning–Based Prediction of Refractive Error Using Photorefraction Images Captured by a Smartphone: Model Development and Validation Study*.
- Authors/year: Chun, Kim, Shin, Han, Oh, Chung, Park and Lim; 2020.
- DOI: https://doi.org/10.2196/16225
- Inspected source: https://medinform.jmir.org/2020/5/e16225/ — publisher methods, results and discussion.
- Population/hardware: 164 Korean children, 305 images; LG LGM-X800K; flash, static frontal capture at 1 m in a dark room.
- Reference/method: subsequent cycloplegic retinoscopy; ResNet-18, seven spherical-error bins; image-based five-fold evaluation.
- Result: 81.6% overall seven-bin accuracy, **literature benchmark**.
- Limitations: small single-center dataset; range classes rather than specific diopters. Participant-grouped splitting is not explicitly established in the described image-fold procedure. Device/population transfer is unestablished.
- Claim/status: prior smartphone CNN screening exists, **LITERATURE_SUPPORTED**. CMF torch-video performance and OcuRisk regression accuracy remain **UNVERIFIED**.

### E02 — Calibration variation and video photorefraction

- Title: *Empirical variability in the calibration of slope-based eccentric photorefraction*.
- Authors/year: Bharadwaj, Sravani, Little, Narasaiah, Wong, Woodburn and Candy; 2013.
- DOI: https://doi.org/10.1364/JOSAA.30.000923
- Inspected source: https://pmc.ncbi.nlm.nih.gov/articles/PMC3967915/ — abstract, introduction, methods and principal results; later retrieval attempts encountered a challenge page.
- Population/hardware: adult cohorts recruited in India and North America; MCS PowerRefractor and custom 850 nm IR systems; 25/30 fps, 100/75 cm.
- Reference/method: repeated trial-lens relative calibrations; absolute calibration distinguished from measuring changes.
- Result: approximately ±40% combined calibration variability around the mean; group-average calibration can distort individual estimates.
- Limitations: IR-array instrument findings do not supply visible-white-LED smartphone coefficients. Relative calibration is not an absolute clinical reference.
- Claim/status: individual/device calibration and repeatability require investigation, **LITERATURE_SUPPORTED**; a universal CMF constant remains **UNVERIFIED**.

### E03 — Nonmonotonic gradients and model limitations

- Title: *Two-dimensional simulation of eccentric photorefraction images for ametropes: factors influencing the measurement*.
- Authors/year: Wu, Thibos and Candy; 2018.
- DOI: https://doi.org/10.1111/opo.12563
- Inspected source: https://pubmed.ncbi.nlm.nih.gov/29736941/ — abstract and detailed figure captions. Full-text PMC access was not consistently available.
- Population/hardware: Zemax double-pass simulation; −15 to +15 D, pupils 3–7 mm, aberrations and spectacle vertex distances; empirical PowerRef 3/COAS comparisons described in figures.
- Reference/method: ray tracing and wavefront-instrument comparison.
- Result: intensity gradients saturated then decreased outside a limited range; a feature value can map to different defocus states. Spectacle magnification/aberrations introduced errors.
- Limitations: simulation and IR instrument results are not CMF measurements; full methodological verification remains incomplete.
- Claim/status: unrestricted monotonic feature-to-refraction assumptions are unsafe, **LITERATURE_SUPPORTED**; our applicable range remains **UNVERIFIED**.

### E04 — Correct historical citation; different optical method

- Title: *Photorefraction: A technique for study of refractive state at a distance*.
- Authors/year: Howard C. Howland and Bradford Howland; 1974.
- DOI: https://doi.org/10.1364/JOSA.64.000240
- Inspected source: https://opg.optica.org/josa/abstract.cfm?uri=josa-64-2-240 — abstract, bibliographic record and accessible tables; complete derivation unavailable.
- Hardware/method: segmented cylindrical-lens attachment to a 35-mm camera, central fiber-optic illumination and star patterns at 1–2 m.
- Outcome: historic simultaneous both-eye photorefraction precedent.
- Limitations/applicability: not a native smartphone crescent pipeline; does not verify our equation. Correcting the citation is **LITERATURE_SUPPORTED**; any claimed derivation of the current equation remains **UNVERIFIED**.

### E05 — Eccentric photorefraction optical analysis

- Title: *Eccentric photorefraction: optical analysis and empirical measures*.
- Authors/year: W. R. Bobier and O. J. Braddick; 1985.
- Citation: Am J Optom Physiol Opt 62(9):614–620; PMID 4050963.
- Inspected source: https://pubmed.ncbi.nlm.nih.gov/4050963/ — abstract and bibliographic record only; complete derivation unavailable.
- Hardware/method: optical analysis, model-eye measurements, infant application discussion; one meridian.
- Outcome/limitation: abstract reports empirical model-eye support but is insufficient to approve a particular equation implementation.
- Status/action: exact citation verified; **NEEDS_SOURCE_ACCESS** for derivation; no equation acceptance from abstract alone.

### E06 — Four-meridian smartphone conference study

- Title: *Using a smartphone camera in detecting refractive error among schoolchildren: a simple model to address cost-related barriers for refractive error detection*.
- Authors/year: Do, Chan, Kwok, Lai, Lee, Ngai and Leong; ARVO/IOVS 2022;63:2819.
- Inspected source: https://research.polyu.edu.hk/en/publications/using-a-smartphone-camera-in-detecting-refractive-error-among-sch/ — complete author-institution conference abstract; publisher access blocked.
- Population/hardware: 141 Chinese children, 7–14 years; smartphone flash; four phone meridians/orientations. Exact phone/exposure absent from abstract.
- Reference/method: noncycloplegic/cycloplegic autorefraction comparisons; crescent width/pupil dimensions.
- Result: reported MAE 0.65 D dry and 0.84 D wet, **literature benchmarks**.
- Limitations/applicability: conference-level detail; dry-vs-wet comparison must not be read as interchangeable references. Establishes multimeridian prior art, not lateral video efficacy.

### E07 — Recent CNN regression study, abstract-only

- Title: *Refractive error detection in smartphone images via convolutional neural network*.
- Authors/year: Cheung, Yang, Zhai, Fu, Ngai, Leong, Chan, Du, Wei and Do; IJMI 2026;205:106083.
- DOI: https://doi.org/10.1016/j.ijmedinf.2025.106083
- Inspected source: https://ira.lib.polyu.edu.hk/handle/10397/117750 — author-institution abstract and record. Full text embargoed until 2027-01-31 there; publisher fetch unavailable.
- Population/method: 93 participants, ages 7–23; MobileNetV2, EfficientNetB0 and ResNet18.
- Result: abstract reports MAE approximately 0.616 and binary accuracy approximately 85.3%, **literature benchmarks**.
- Unknowns: detailed hardware/acquisition/reference/split grouping not verified.
- Status/action: prior architecture families supported; detailed benchmark **NEEDS_SOURCE_ACCESS**. Do not repeat the abstract's “first” claim without reconciling earlier E01 smartphone CNN classification.

### E08 — Off-axis measurement evidence, animal scope

- Title: *Applicability of infrared photorefraction for measurement of accommodation in awake-behaving normal and strabismic monkeys*.
- Authors/year: Bossong, Swann, Glasser and Das; 2009.
- DOI: https://doi.org/10.1167/iovs.08-2686
- Inspected source: https://pubmed.ncbi.nlm.nih.gov/19029024/ — abstract and figures; PMC full text unavailable.
- Population/hardware: three monkeys; custom IR photorefractor, trial lenses, off-axis/misalignment tests.
- Result: subject calibration differed; off-axis observation affected measurements.
- Limitations/applicability: no direct human CMF gaze acceptance threshold. Separating gaze from emitter geometry is supported; head-turn screening efficacy remains **HYPOTHESIS**.

### E09 — Device-specific illumination safety bench evidence

- Title: *Investigating the light emitting diode (LED) flashlight characteristics of a sample of smartphones for its safety in indirect retinal photography*.
- Authors/year: Solyman, Hamdy, Abdelkawi and Hassan; 2022.
- DOI: https://doi.org/10.11604/pamj.2022.43.15.32963
- Inspected source: https://www.panafrican-med-journal.com/content/article/43/15/full/ — full methods/results/limitations.
- Hardware/method: nonhuman laboratory; nine phone versions, +20 D condensing lens, spectrometer/luxmeter; no CMF Phone 2 Pro.
- Result: tested configurations fell within cited limits; repeated/prolonged illumination concerns discussed.
- Limitations/applicability: authors explicitly restrict transfer to untested phones. Does not certify our direct torch-video protocol. CMF safety remains **UNVERIFIED** pending qualified configuration-specific assessment.

### E10 — Current light-hazard standard scope

- Title/year: *ISO 15004-2:2024 — Ophthalmic instruments — Fundamental requirements and test methods — Part 2: Light hazard protection*, December 2024 edition.
- Inspected source: https://www.iso.org/standard/79919.html — official scope/version record; complete paid standard not read.
- Scope: ophthalmic/emerging instruments directing optical radiation into/at the eye.
- Limitations/action: relevant qualified-review framework, not a completed CMF calculation. No numeric safe distance/duration is claimed from a landing page.

## Screened contradictory evidence and unsafe generalization

| Proposed interpretation | Evidence against overgeneralization | Required response |
| --- | --- | --- |
| A single universal feature multiplier yields accurate diopters | E02 calibration varies; E03 gradients can saturate/reverse | Device/participant investigation, independent reference, bounded operating domain |
| No crescent means zero refractive error | Photorefractive dead-zone prior art; signal-quality failure | Keep missing/inconclusive separate from legitimate zero |
| More brightness or a larger gradient is always better | E03 nonlinear response; clipping destroys spatial information | Separate quality and signal strength; retain maps and rejection reasons |
| Phone roll is only image rotation | Physical source-camera baseline rotates in world coordinates | Model physical motion and digital transforms separately |
| Phone translation/head turn directly predicts diopters | E08 off-axis response; accommodation/aberration confounding | Treat as hypotheses, record fixation and geometry, matched comparisons |
| Published classification accuracy proves our continuous refraction | E01 bins, different instrument/population | Independent quantitative evaluation and appropriate reference |
| Published phone safety certifies CMF torch videos | E09 excludes CMF and uses a condensing-lens arrangement | Qualified review of exact source, mode, duration, repetition and geometry |
| Generic smartphone/CNN/multiview system is first or unique | E01/E06/E07 and patent matrix | No novelty claim before scoped prior-art review |

## Sources discovered but not accepted as inspected-method evidence

- 2026 STARS preprint, DOI 10.21203/rs.3.rs-8873852/v1: retrieval failed; no performance adopted.
- *Comparative Feature-Guided Regression Network with a Model-Eye Pretrained Model for Online Refractive Error Screening*: https://www.mdpi.com/1999-5903/17/4/160 — publisher rate/access errors; methods not inspected; no benchmark adopted.
- Chan, Edwards and Brown 1996 *Calibration and validity of an eccentric photorefractor*, PMID 8977883: source access inconsistent; needs full calibration derivation.
- *Utilizing minicomputer technology for low-cost photorefraction: a feasibility study*, DOI 10.1364/BOE.400720: discovery and initial page opening succeeded, but usable full methods were not retrieved reliably. No quantitative benchmark adopted here.

## Actual research outcome and next task

No optical, camera, clinical, dataset or model result was measured by this workstream. API capability evidence is recorded in HARDWARE_FEASIBILITY.md. Prior art is in PRIOR_ART_MATRIX.md. Next safe work: isolated software, metadata integrity tests and nonhuman capture diagnostics. Human optical measurements remain gated by qualified safety review, applicable ethics/consent and reference access.
