# Stage2 scientific review — 2026-10-09

Lead scientific architect. This is an experiment specification and review, not a report of measured eye performance. The restored Stage1 audit remains valid as its recorded source checkpoint; current Stage2 independent final execution is recorded in STAGE2_TEST_REPORT.md.

## User workflow in simple language

The separate Lab lets the operator load an original recording, inspect its frames, compare image-processing methods, correct eye markings, save an expert's observations, and later compare prediction models against independently measured reference values. All recordings can remain on the user's PC. Sharing every video with an AI assistant is not required.

An image algorithm finds or measures patterns. A prediction model learns a relationship between those measurements and a specified reference target. A Bayesian model uses an explicit statistical model and prior to represent conditional uncertainty. None of these names proves accuracy. There is currently no winning pipeline, clinical cohort or verified CMF optical result.

## Distinct acceptance questions

| Question | Evidence to accept it |
|---|---|
| Does acquisition software preserve media? | Successful build, real device capability/recording logs, original and transferred hashes |
| Does video processing preserve frames? | Actual encoded-file decode, source PTS comparison, duplicates and failures retained |
| Are detected regions actually pupils? | Independent representative annotations, boundary errors and false detections, including negatives |
| Is a bright region a retinal reflex? | Independent specialist review of eligible source evidence, not a software threshold alone |
| Is that reflex refractively informative? | Controlled geometry and reproducible response against independent optical/clinical references |
| Does a model outperform alternatives? | Matching target/units/test participants, locked development choices, coverage and paired errors |
| Can the complete pipeline screen people? | Approved scope-specific external evaluation, failure accounting, calibrated decisions and independent review |

Software test images and synthetic targets answer engineering questions only. A drawn dark circle is not a model eye; a mathematical fit to generated targets is not clinical accuracy. No missing observations become zero, normal refraction, a guessed pupil radius or a reassuring risk percentage.

## Optical study design

The original equation remains UNCALIBRATED until its quantities, units, sign convention, aperture/focus assumptions and calibration are traceable. A measured physical camera/source baseline is not sufficient by itself to establish a photorefraction equation. RGB code values are not calibrated radiance, and a pixel radius is not physical millimetres.

First characterize a real nonhuman optical apparatus with independently measured defocus, pupil aperture, selected camera/source, distance and their uncertainty. Test fixed-condition repeatability before a bounded, randomized/blocked defocus sweep. Retain dark, saturated and failed acquisitions. Inspect monotonicity, sign ambiguity, saturation, pupil dependence and session drift. Choose range/repeats from apparatus and precision requirements, not borrowed smartphone claims.

Static, lateral phone motion, physical phone roll and head/model rotation are separate experimental factors. Digital rotation is a coordinate transformation control. RIGHT/LEFT acquisition metadata do not measure head angle or fix anatomical identity. Unknown orientation stays unknown. Adjacent video frames are not independent experimental repetitions.

Representative pupil/reflex annotation must include glare, eyelids, spectacles, dark/light backgrounds, occlusion and absent signal. Store source coordinates and reviewer disagreement. Expert-confirmed visible reflex and independent refractive reference are distinct records; one cannot substitute for the other.

## Model design and comparison

Train-only preprocessing and participant-grouped splits keep both eyes and repeated frames together. Exact duplicate and forbidden-column checks help but do not prove absence of covert target/reference or device leakage. Save the full immutable training payload, references, config, code/runtime hashes and split membership, not just a dataset hash.

Use the same declared target, units, reference version and held-out participants for fair model comparisons. A low error from a different cohort does not identify the best model. Fixed-configuration grouped CV is not nested hyperparameter selection. Final selection needs predeclared development procedures and a locked independent test.

Report acquisition attempts, failures and abstention alongside accepted-record errors. Complete-record prediction coverage is not end-to-end screening coverage. Clustered confidence intervals are descriptive when cohorts are small; they do not establish a sufficient sample size. Paired model-difference analysis is a separate acceptance requirement.

The initial Bayesian candidate is Bernoulli-logistic with explicit proper priors and a checked Laplace approximation, one observation per participant. Its probability intervals represent approximate parameter uncertainty conditional on the model. They are not measurement error, domain-shift protection or validated disease risk. Hierarchical repeated-eye models and longitudinal progression require different data and further implementation.

Nonhuman bench learning is eligible only with declared independent bench reference provenance, apparatus/calibration identifiers and target units; it must stay separately labelled from human clinical training. The implemented bench-origin schema enforces declared provenance fields; it cannot independently verify that a caller truly performed the stated measurement.

## Acquisition-source research update

Official Android [VideoRecordEvent.Finalize](https://developer.android.com/reference/androidx/camera/video/VideoRecordEvent.Finalize) documentation was inspected on2026-10-09. Error finalization may still leave a partial video. Implementation must retain its explicit error and existing bytes; receipt of a file alone is not recording success. [CameraX architecture](https://developer.android.com/media/camera/camerax/video-capture) distinguishes recording events and final output/error reporting. These are API behavior references, not a successful CMF experiment.

Official [CaptureResult](https://developer.android.com/reference/android/hardware/camera2/CaptureResult) timestamp documentation distinguishes camera timestamp sources. Unknown-source sensor timestamps cannot be assumed synchronized with other subsystems. Encoded-media PTS must not be labelled sensor exposure time without a measured association. Preserve each clock and any missing association explicitly.

## Human dependencies and unresolved work

Actual CMF/Windows operation, measured optics/illumination and clinical references require human equipment access. Illuminated human-eye studies require qualified safety/research review and applicable permissions. No safe exposure duration, clinical threshold, population prevalence, optical constant or target accuracy is invented. The software can proceed independently; scientific acceptance cannot bypass these gates.

Blinding is an experiment property, not a checkbox guarantee. A caller's declaration does not prove the reviewer never saw algorithms. If raw-first review and reveal logging are not enforced, disclose that limitation. Specialist identity/qualifications and approval text likewise remain assertions unless independently verified.
