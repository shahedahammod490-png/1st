# Independent verification — iteration 001

Verifier identity: delegated independent verifier, not the builder and not claimed to be Claude Opus. Date: 2026-10-08. Read the supplied complete master, verifier and technical specification extracted texts and the shared interfaces. Scope: adversarial inspection of the separate Lab's first software foundation; the complete scientific pipeline is not implemented and cannot be accepted.

## 1. Executive verdict

**Software foundation: APPROVE for the tested nonhuman image-import/replay foundation. Scientific pipeline: BLOCK.** Final independent run: 26 tests passed in 3.250 s on Linux; exact output saved in `latest_tests.txt`. Approval does not include Android, Windows runtime, native video, automatic pupil segmentation, trained models or clinical screening. Synthetic engineering tests cannot establish camera feasibility, retinal-reflex specificity, refractive accuracy, calibrated risk, or illumination safety. Never interpret this software verdict as permission for participant acquisition.

## 2. Verified

Independent tests exercise the real public service, store and optical APIs, not a substitute implementation. Verified: absent-eye null preservation; OD output unchanged by OS annotation mutation; byte-identical deterministic artifacts; black-image genuine gradient/candidate zeros; absent distance/pose remain null; source hash mismatch and tampering reject; unsafe paths, extension spoofing and duplicate images reject; zero timestamp retained; reversed/duplicate known timestamps reject; missing approval rejects REAL_APPROVED import; cross-site writes and non-loopback Host reject; public binds reject; strict JSON rejects duplicate keys/NaN; HTTP import/process/export roundtrip uses actual measurements with null prediction and uncertainty.

Original preservation check passed against protected ZIP SHA256 `e91550e3bc88e6bb2a3728a0f911a0f10f64b4dcbb90fbb9d94435a1483953c7` and every inventoried extracted authored file. Command: `python tools/check_original.py --zip <provided-original-zip> --source <audit_inputs>`. This checks recorded original artifacts, not every unrecorded filesystem path.

## 3. Critical issues

Scientific acceptance blockers: target-device behavior, optical geometry, physical illumination and its research safety review, controlled fixation/distance, independently referenced participant measurements, and held-out validation are absent. These are known blocked gates, not failures hidden by synthetic tests.

## 4. High-risk issues

| ID | Severity | Finding | Status / evidence |
|---|---|---|---|
| V-001 | HIGH | A clipped circle initially returned ordinary FEATURES_COMPUTED status and partial-pupil candidate/gradient values. | FIX VERIFIED: independent partial-circle test now requires INCONCLUSIVE; implementation additionally declares INVALID_EDGE_CLIPPED_MANUAL_ANNOTATION and diagnostic-only reason. Fully outside circle remains inconclusive. |
| V-002 | HIGH | Runs initially omitted implementation source hashes, preventing exact source provenance despite image hashes and version/config. | FIX VERIFIED: `test_run_retains_actual_implementation_hashes` confirms actual optical/schema/store/server SHA256. Separate stale-loaded-module issue V-006 remains. |
| V-003 | MEDIUM | RD/RE/Y initially had different equations from master §25 under the same names. | FIX VERIFIED by source inspection: named definitions now follow master; alternative definitions require named/versioned experiments. No refractive validity follows from an equation match. |
| V-004 | MEDIUM | Alpha-bearing PNG import and processing initially used different opacity criteria, permitting accepted unusable captures. | FIX VERIFIED: all alpha-bearing images reject at import, including fully opaque RGBA; independent transparent/opaque-alpha tests pass. |
| V-005 | MEDIUM | Dashboard initially displays legacy .08 floor without its feature-definition caveat. | FIX VERIFIED by static UI inspection: exposes `feature_definitions`, source hashes and execution fingerprint. Nonzero legacy floor is an archived comparator artifact, not detected crescent area. Browser visual QA is separate. |
| V-006 | HIGH | Initial source freshness check compared function bytecode but missed changed module-level algorithm/config constants, allowing new source hash to describe cached old module. | FIX VERIFIED: exact source SHA at optical import is compared to current bytes before/after runs; `test_constant_only_source_change_rejects_cached_algorithm` now rejects the simulated source edit. Real concurrent optical edits during an intermediate suite also correctly blocked processing; a fresh-process final suite passed. |

## 5. Optical physics

There is no refractive calculation in the accepted Lab feature extractor. RGB-derived maps use decoded image code values and unvalidated heuristic thresholds, not calibrated radiometric quantities. Manual circles are not detected pupil boundaries or physical pupil diameters. Gradient is a spatial image feature in annotated-radius coordinates; it has no established diopter interpretation. Bright boundary-connected components are candidate shapes, not verified retinal crescents.

## 6. Acquisition geometry

Distance and phone/head pose remain null if unmeasured. Camera-to-LED vector, camera optical axis, selected physical camera and direction conventions require actual measurements. Roll, lateral motion, yaw and head turn are distinct conditions; software feature calculations do not prove any produces useful optical eccentricity.

## 7. Two-video / OD-OS

The manifest preserves direction independently of anatomical OD/OS. Actual HTTP processing of a VIDEO_RIGHT-labeled image emits both OD and OS independently. Native video capture and real four-stream temporal validation remain unimplemented/unverified. Static fixture tests do not establish tracking across frames or anatomical labeling accuracy.

## 8. Image processing

Normalized image, pupil annotation mask, bright/glint candidate masks, candidate crescent mask, gradient and polar artifacts are inspectable deterministic outputs. The pupil is manually supplied. Glint restriction is heuristic size/chroma/brightness, not a validated corneal classifier. Polar orientation uses image x-right/y-down, retains explicit angular/radial centers and missing entries. Rotation/mirroring metadata is not silently applied. Synthetic black and overexposed fixtures cannot create real optical evidence.

## 9. Camera / hardware

Android CameraX/Camera2 source statically inspected: explicit rear-ID selection, advertised controls/probe, request/result separation, exact sensor-timestamp metadata matching or explicit missingness, native JPEG export, null geometry/physical illumination, flash-OFF nonhuman still and bounded best-effort torch OFF request. No APK build or target phone test performed by this verifier. The timed OFF request is not certified exposure duration. Camera/API metadata is not physical LED verification. No eye-illumination experiment authorized by this report.

## 10. Dataset

Tests create only synthetic inert pixel arrays in temporary directories with SYNTHETIC origin. No participant dataset, reference coverage, refractive distribution or gradable rate established. REAL_APPROVED requires an approval reference string; that assertion is not independent authentication of an ethics approval.

## 11. Data leakage

Exact duplicate image hashes reject across imports. Descriptive partition audit addresses participant leakage and exact hashes, with near-duplicates, metadata/reference leakage and reference quality explicitly unassessed. No model training occurred, so no trained model can claim leakage clearance.

## 12. Statistics

Basic descriptive metrics exist; no OcuRisk clinical measurements, confidence intervals, subgroup results, Bland–Altman conclusion, ROC-AUC or sample-size adequacy established. Clustered eyes/repeats require participant-aware analysis. Undefined denominators and no-data results must remain null. Correlation alone cannot establish agreement.

## 13. Machine learning

No trained optical, CNN, multiview, hybrid or risk model accepted. Status endpoint correctly declares advanced models NOT_IMPLEMENTED and clinical prediction AWAITING_REFERENCE_DATA. Architectures and candidate lists are plans, not implemented comparative performance.

## 14. Uncertainty

Prediction and uncertainty stay null in actual persisted/exported outputs. Heuristic quality quantities are not calibrated uncertainty. No conformal interval, calibrated probability or Bayesian posterior established.

## 15. Failure modes

Independent tests include missing eye, zero/black image, whole-field overexposure, partial/outside circle, nonfinite annotations, image tampering, transparent/opaque-alpha images, invalid format/path, duplicate hash, bad timestamp, wrong approval provenance, cached-source edits and cross-origin/Host attacks. Conflicting overlapping anatomical annotations are inconclusive; independent same-region OD/OS test passes. Human dark irises, eyelids, eyelashes, gaze/pose changes, glints and real optical failures remain untested. Real anatomical labeling accuracy and actual tracking identity remain unverified.

## 16. Novelty / prior art

No novelty claim is independently accepted by this software audit. Existing photorefraction precedent does not demonstrate commodity-device performance, and differences in proposed pipeline do not establish novelty. A complete independently inspected primary-source/patent review remains required for consequential novelty claims.

## 17. Clinical language

Lab processing outputs do not emit disease labels or diopters. The original source retained as legacy reference contains clinical/risk terminology and unverified calculations; archiving does not accept those claims. Research dashboard must state candidate feature scope and known limitations.

## 18. Unsupported claims

UNVERIFIED: CMF Phone 2 Pro acquisition works; torch reproduces dedicated photorefraction; physical LED state; per-eye tracking on actual directional video; pupil/glint/crescent detection is accurate; gradients predict refraction; any model is superior; refractive accuracy or referral sensitivity/specificity; calibrated current risk; five-year progression; clinical safety; device generalization; novelty. They must not be promoted by unit-test success.

## 19. Required experiments

First obtain an Android build and nonhuman device/export evidence, followed by physically measured selected camera/LED geometry and controlled acquisition. Before any participant illumination, obtain appropriate research/optical safety approval, consent and a clinically defined independent reference protocol. Then compare control/phone-motion/head-turn, all four eye/direction streams, distances and repeats with documented failures; develop subject-level datasets and frozen held-out evaluation before selecting a winning full pipeline.

## 20. Required code changes

All six recorded first-foundation findings have tested fixes or static documentation/UI verification. Keep video/model/dataset capabilities truthful. Consequential future algorithms require independent regression/replay tests and explicit versioned change records. This audit does not imply no remaining defects.

## 21. Remaining unknowns

Target-device stream/control behavior, camera/LED baseline, optical signal visibility/repeatability, real pupil/glint segmentation accuracy, calibration/reference relationship, actual directional complementarity, participant availability, reference quality, adequate sample size and valid calibrated prediction remain unknown.

## 22. Release status

Software foundation APPROVE within the tested scope above; scientific pipeline BLOCK. No original-project integration approved. All 26 independent synthetic engineering tests passed. The status is not a clinical, Android or Windows acceptance report. Required scientific experiments and hardware gates remain open.
