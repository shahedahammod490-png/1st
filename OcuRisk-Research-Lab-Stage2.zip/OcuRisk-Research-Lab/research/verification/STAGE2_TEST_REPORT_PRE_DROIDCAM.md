# Stage2 execution report — 2026-10-09 UTC

Application source: `05d915c`. Evidence-only Git HEAD during independent verification: `b308e6d73904fa8c859438ae913947860013c6a1`. Subsequent checkpoint/documentation commits do not imply an application retest.

| Check | Actual result | Evidence |
|---|---|---|
| Final integrated Python suite | 112 PASS, 17.893 seconds | research/verification/STAGE2_integrated_tests.txt |
| Independent final Python execution | 112 PASS, 18.128 seconds | research/verification/STAGE2_final_tests.txt |
| Integrated host/USB helpers | 9 PASS, 0.777 seconds | research/verification/STAGE2_integrated_host_tests.txt |
| Independent host/helper execution | 9 PASS, 0.744 seconds | research/verification/STAGE2_host_tests.txt |
| CSV/manual provenance helper + JS syntax | PASS as executed by UI/integration owners | research/STAGE2_UI.md; research/STAGE2_SERVICE.md |
| Python compileall | PASS as executed by integration owner | research/STAGE2_SERVICE.md |
| Original protection | PASS: original ZIP + 57 inventoried authored files unchanged | research/verification/STAGE2_source_snapshot.json; original_inventory.json |
| Empty Python function-body scan | No empty bodies found in verifier's scanned source | research/verification/STAGE2_source_snapshot.json |
| Browser interaction/appearance | BLOCKED before page navigation, socket EPERM; no screenshots | research/ui-browser-execution.log |
| Android native build | BLOCKED by unresolved AGP/SDK artifacts; no APK | android/README.md and retained Android evidence |
| Windows/physical CMF/optical/clinical performance | NOT TESTED | No device/participant/reference dataset supplied |
| Optional CNN/hybrid execution | UNAVAILABLE/UNTESTED without PyTorch | research/STAGE2_MODELS.md |

The two 112-test runs exercise the same suite; they are not 224 distinct tests. Likewise the 9-test helper suite is counted once. Independent regression tests are included in the 112. All host helper tests ran on Linux with synthetic/simulated USB fixtures; actual encoded video and loopback HTTP were exercised, but no phone was connected.

Runtime: Python3.12.14, NumPy2.2.6, OpenCV4.12.0, Pillow12.3.0, SciPy1.17.0, scikit-learn1.8.0. Use pinned requirements and the project virtual environment. FFmpeg/ffprobe6.1.1 were available on the test host.

## Consequential correction

Independent review exposed repeated same-eye detections being assigned both anatomical eyes. `05d915c` rejects overlapping/duplicate candidate pairs before anatomical assignment; the adversarial regression passes. Candidate maps can remain image-side when anatomy is unknown. This does not establish real-world detector accuracy.

## Evidence limits and review attribution

Earlier intermediate failures are retained in STAGE2_intermediate_tests.txt; they are not the final result. STAGE2_source_snapshot.json retains independent final source/evidence hashes and scope. The original independent verifier completed tests and snapshot, then reached its usage limit before writing a final narrative. A separately assigned release reviewer examines those artifacts and current source in STAGE2_INDEPENDENT_REVIEW.md; no missing sign-off is fabricated.

Engineering fixtures test actual computations and failure behavior. They are not measured eye data, photorefraction calibration, risk calibration, illumination certification or evidence of a winning pipeline. Application/UI/native source existence and host test success do not replace the remaining acceptance gates in STAGE_ACCEPTANCE.md.
