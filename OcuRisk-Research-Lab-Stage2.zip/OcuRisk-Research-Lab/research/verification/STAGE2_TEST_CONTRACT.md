# Independent Stage 2 verification contract

2026-10-09. Scope: restored Stage 1 → additive Stage 2 recovery. Tests and verdict are owned by an independent verifier, not the application engineers. The initial current baseline is 63 Python tests and six Windows-helper synthetic tests passing; the original ZIP and inventoried authored files pass the protection check. Historical Stage 2 messages are not executable evidence.

## Adversarial acceptance matrix

| Area | Independently required checks | Interpretation |
|---|---|---|
| Raw media | Original bytes/hash survive import, processing, append-only revisions, export; tampering detected; invalid encoding rejected; duplicate flagged; safe path/range handling | Persistence and transfer engineering only |
| Frames/time | A genuinely encoded short synthetic video is decoded, all frames indexed (including duplicates), PTS/timebase retained, zero preserved; sampling explicit and missing observations null | Container media time is not exposure/sensor time |
| Detection | Uniform dark/white frames produce no fabricated anatomical pupil; global blobs cannot independently establish anatomy; unknown mirror/upright/identity abstains; source coordinates and manual/automatic provenance explicit | Synthetic geometric tests do not establish real pupil segmentation accuracy |
| Four streams | Both OD and OS present for RIGHT and LEFT media; acquisition direction never determines eye identity; no stale positions on loss | Correct data structure is not real tracking validation |
| Optics | Same source/ROI given to genuinely different comparisons; new candidate absent in uniform frames; adapted old artificial floor exposed; no diopter/confidence fallback | Maps are image features, never software-confirmed retinal reflex |
| Dataset/review | Nonexistent frame indices rejected; partial reference nulls retained; invalid date/method/nonfinite/bool measurements rejected; revisions append; review label deliberate; blinding caller assertion identified | Expert visibility labels do not validate refraction |
| Jobs/HTTP | Actual binary HTTP upload, async progress completion/failure/cancellation, persisted state and source/config/annotation snapshots, range download and export, reload/restart behavior | No empty success routes or placeholder metrics |
| Regression | Five estimators actually fit supplied data; train-only preprocessing; participant/exact-feature/reference leakage rejection; immutable full training payload; target/features finite; true baseline/held-out errors independently calculated | Synthetic fit error is not OcuRisk clinical performance |
| Bayesian | Explicit proper priors and named Bernoulli event; independently derived balanced intercept posterior mode/Hessian case; predictive probability in bounds; interval meaning/inference stated; duplicate participants rejected | Mathematical inference does not establish calibrated disease probability |
| Physics | All explicit parameters required; original formula/clamps/rounding and units shown; missing parameter rejected; legacy output quarantined from clinical prediction; power-vector expected values | Uncalibrated K is not a literature-validated device constant |
| Optional CNN | Actual dependency checks, executable architecture/train/infer if available, no pretrained or metric claims without execution | Missing runtime means UNAVAILABLE, not tested |
| UI/native | Every visible control functional or explicit prerequisite; real browser interactions/screenshots required for browser claim; actual native build log required for APK claim | Syntax/XML parse does not establish browser/native/device success |
| Original | Final ZIP and inventoried authored-source hashes unchanged | No integration authorization implied |

## Finding protocol

Record ID, severity, concrete reproduction, observed versus expected behavior, affected units/provenance, scientific consequence, owner response and actual retest. Critical and high defects block affected acceptance until fixed. Do not rewrite an application module in the verifier role. Test engineer fixes independently at a known source snapshot.

## Verdict boundaries

Software acceptance may be scoped to tested local nonhuman/synthetic workflows. Complete optical/scientific acceptance stays BLOCK: actual CMF acquisition/illumination/geometry, real anatomy/segmentation, independently referenced study data, held-out complete-pipeline performance and calibrated uncertainty are not established. No model winner, optical safety conclusion or original-project integration is authorized by these software tests.
