# Stage 2 independent release review

Review completed 2026-10-09 UTC by the release-review agent, independent of application implementation. Application freeze: `05d915ceda71d12931fa37d161d6c548e634fb37`; evidence-only HEAD reviewed: `b308e6d73904fa8c859438ae913947860013c6a1`. Root documentation edits were in progress and are outside the tested application snapshot.

## Scoped verdict

**ACCEPT for packaging the tested synthetic/local research software milestone. NOT ACCEPTED as a fully verified browser/Android/Windows/CMF system or as a validated optical, refractive-prediction, screening-risk or clinical pipeline.** No original-product integration is authorized. No model winner is established.

The earlier independent verifier produced final execution logs and a source snapshot before its narrative was interrupted. This review completes the narrative by independently inspecting those retained artifacts and relevant source; it does not represent the earlier verifier as having written or approved this document. I did not implement the application or alter its tests.

## Evidence inspected and checks performed

| Evidence | Actual result | Scope |
|---|---|---|
| `STAGE2_final_tests.txt` | 112 tests PASS in 18.128 s | Retained independent Python execution; synthetic software/math and encoded-media fixtures |
| `STAGE2_host_tests.txt` | 9 tests PASS in 0.744 s | Retained Windows-helper execution on Linux with simulated device/subprocess and synthetic byte fixtures; not Windows/USB hardware execution |
| `STAGE2_source_snapshot.json` | All 43 listed source hashes and both listed evidence hashes match current bytes | Recomputed in this review; not a complete repository/native-source manifest |
| `STAGE2_integrated_tests.txt` and service report | Separate integrator reports 112 PASS in 17.893 s | Corroborating implementation-owner evidence, not substituted for independent execution |
| `STAGE2_UI.md` and `ui-browser-execution.log` | Node helper/syntax checks reported PASS; Chromium failed before page navigation with socket EPERM | No interaction, screenshot or visual acceptance |
| `android-evidence/build-recovery-final.txt` | Gradle failed resolving Android Gradle Plugin 8.9.2 before compilation | No build, lint, APK or device acceptance |
| Protected original verification | Re-executed using system `python3`; PASS, no mismatches | ZIP and all inventoried authored-source files unchanged |

Protected ZIP SHA256: `e91550e3bc88e6bb2a3728a0f911a0f10f64b4dcbb90fbb9d94435a1483953c7`.

Original check command: `python3 tools/check_original.py --zip '../upload/EYE(2).zip' --source ../audit_inputs`. Output was `passed: true`, `failures: []`.

The recorded tested runtime is Python 3.12.14, NumPy 2.2.6, OpenCV 4.12.0, SciPy 1.17.0, scikit-learn 1.8.0 and Pillow 12.3.0. The restored environment no longer contains `.venv/bin/python`; an attempted invocation returned “No such file or directory.” I used system Python only for standard-library hash/original checks, did not silently rerun scientific tests under a different runtime, and did not repeat the complete already-recorded suite. Recreate the pinned environment before subsequent execution. Snapshot coverage includes application Python/JS, tests and Windows helpers; Android Java and Gradle files are outside its 43-file list, and native execution remains blocked.

## Consequential finding and disposition

**S2-IDENTITY-01 — HIGH, fixed in the inspected freeze.** Duplicate Haar eye boxes could describe one observed dark component twice and produce separate OD/OS assignments when context flags were supplied. This could corrupt anatomical labels and downstream paired-eye comparisons.

The independent regression `IndependentStage2Detection.test_duplicate_haar_eye_observations_cannot_become_two_anatomical_eyes` supplies two identical eye boxes for one synthetic dark component. It requires both observations to remain available, identity to stay `UNRESOLVED`, and OD/OS to be null. The retained final independent log records this regression PASS. Source inspection of `05d915c` confirms that intersecting eye boxes or overlapping equivalent-radius circles prevent anatomical assignment. The matching source hash ties the inspected fix to the tested snapshot. This closes the specific duplicate-observation defect; it does not establish anatomical correctness on real images. Conservative rejection can also discard legitimate overlapping candidate boxes, which requires real-data evaluation.

## Scientific and functional boundaries

The independently authored tests exercise actual five-estimator fitting and separately calculated errors; train-only scaling and grouped training CV; participant/exact-feature/reference leakage checks; frozen model artifacts and tamper rejection; explicit priors and an analytically checkable balanced Bayesian MAP/Hessian case; original legacy-formula arithmetic and supplied-prescription power vectors; actual local HTTP/media processing, source integrity, job recovery and export. These provide useful implementation evidence. Synthetic reference rows explicitly labelled as such are test fixtures, not patient records or measured accuracy.

- Detection outputs remain candidate image geometry. Haar evidence, a dark component, caller-supplied identity flags, or crescent/gradient maps do not demonstrate a retinal reflex, refractive error or safe illumination.
- Bayesian inference is Bernoulli-logit with a Gaussian Laplace approximation and explicit priors. Its fitted-probability intervals are not validated clinical uncertainty or outcome intervals; no MCMC convergence or disease-risk calibration is established.
- Legacy physics remains an uncalibrated comparator with unresolved optical-constant units. Power vectors are a mathematical transform of supplied values, not image-derived refraction.
- Exact duplicate/leakage checks do not exclude all semantic or near-duplicate leakage. Reference/approval/blinding records remain caller assertions requiring external verification.
- CNN/HYBRID has source and an explicit absent-dependency gate, but PyTorch training/inference was not executed here. Do not count it as a tested trained model.
- Empty-Python-function scan in the retained snapshot found none. This limited static check is not proof that every possible function, control, input or platform works. Unavailable quantities must remain null/unavailable, not fabricated values.

## Blocking acceptance gates and next verification

1. Recreate the pinned host runtime and exercise the retained browser interaction test on a host allowing Chromium sockets, with an isolated nonhuman test database. Inspect actual layouts and every visible control; retain screenshots and logs.
2. Resolve the Android build dependencies, compile/lint and install a real APK. Then test camera capabilities, recording lifecycle, timestamps/sidecars, immutable bytes and USB import on the actual CMF Phone 2 Pro and Windows PC. Linux fixtures cannot close this gate.
3. Establish nonhuman optical geometry/illumination and independently measured bench references, then test repeatability, failures, acquisition modes and complete pipelines. Human eye illumination/participant work requires the appropriate qualified safety/research approvals and consent before collection.
4. Obtain appropriately independent clinical reference measurements and a prespecified participant-separated evaluation protocol before comparing clinical performance, uncertainty/calibration or declaring a winning pipeline.
5. Execute optional neural-model training/reload/inference and leakage tests in a compatible PyTorch environment before accepting that component.

No unresolved critical/high software defect was identified within this limited final review after S2-IDENTITY-01 was fixed. That statement is not an exhaustive security, optical-safety or platform audit. The open gates above block broader scientific/system acceptance.

## Change and integration record

This review created only `research/verification/STAGE2_INDEPENDENT_REVIEW.md`. No application, test, original-project or Git history changes were made. Root should retain the existing test logs and snapshot unchanged, include this scoped verdict in the release/checkpoint, and ensure release notes distinguish the completed software milestone from the blocked platform and scientific gates.
