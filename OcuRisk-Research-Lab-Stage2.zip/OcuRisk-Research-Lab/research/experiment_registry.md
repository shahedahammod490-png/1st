# Experiment registry

Authoritative experiments and actual results: ../EXPERIMENT_REGISTRY.md. This pointer prevents conflicting duplicate registries. Use immutable experiment/run IDs and append evidence after execution; a planned row is not a result.
