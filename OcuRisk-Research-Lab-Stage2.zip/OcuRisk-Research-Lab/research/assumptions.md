# Assumptions

Authoritative engineering/scientific decisions: ../DECISIONS.md. Unmeasured physical quantities stay unknown. No universal iris scale, source baseline, optical coefficient, reference outcome or clinical threshold is accepted. Detailed optical/Bayesian assumptions and tests are in OPTICAL_RESEARCH.md and BAYESIAN_RESEARCH.md.
