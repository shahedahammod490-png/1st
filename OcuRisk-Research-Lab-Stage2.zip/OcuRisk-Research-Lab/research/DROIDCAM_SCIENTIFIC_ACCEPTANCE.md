# DroidCam scientific acceptance and measurement plan

2026-10-10 Dhaka. Lead research architect. This replaces APK-first acquisition priority for current work. User reports the CMF Phone2Pro already works through DroidCam USB and Wi-Fi; that report is distinct from our physical verification. Native APK is optional only when an essential optical/control requirement cannot be met through the tested DroidCam route.

## What the program can measure

| Quantity | Measurement and scope | What it cannot establish |
|---|---|---|
| Resolution/frame count | Dimensions and actual decoded saved frames | Native sensor resolution or full captured-frame count upstream |
| Effective FPS | (decoded frames−1)/(last valid PTS−first valid PTS) with explicit availability and clock | Sensor exposure cadence; requested FPS is not actualFPS |
| Timing variation/gaps | Saved-PTS intervals, distribution, nonmonotonic/duplicate timestamps; gaps above declared median-relative threshold | Exact number/reason of camera/network/encoder drops |
| Sharpness | Grayscale Laplacian variance/edge contrast on declared decoded pixel region | True optical focus or retinal gradability; noise/scene/resolution alter score |
| Clipping | Fraction of near-maximum/minimum code values with channel/luma definition and threshold | Exposure time, ISO or radiometric saturation threshold of native sensor |
| Brightness stability | Distribution/time series of weighted RGB code-value means on declared region | Cause: AE, illumination, movement, tone mapping and lens change are confounded |
| RGB/chromaticity stability | Time series/variation on stationary target/ROI, black denominator unavailable | Absolute color accuracy, raw spectral response or isolated AWB error |
| Codec/bitrate | FFprobe saved-stream metadata; file-size/duration average explicitly estimated where necessary | Original DroidCam transport encoding/bitrate before browser recording |
| Compression clues | 8-pixel boundary-discontinuity proxy relative to neighboring edges, with orientation/grid stated | Compression amount/severity without reference; real chart edges and other codec block sizes confound |
| Motion/degradation | Consecutive decoded-image difference with sharpness/clipping time series | Physical pose, movement speed, individual blur cause or gaze direction |
| Duplicate decoded frames | Exact decoded-content hashes | Which subsystem repeated the frame or whether a sensor exposure was lost |

All values use explicit units and finite JSON. Missing timing, target, ROI, first-frame temporal comparison or unavailable metadata stays null with reasons. Analyze every decoded frame, even when optical analysis is explicitly sampled. No dummy fill/interpolation for lost observations.

## Quality diagnostics and ranking

Defaults are engineering diagnostics, not validated clinical acceptance thresholds. Pixel thresholds250/5 identify near-code clipping, not safe/unsafe exposure. Median-relative gap factor1.5 flags timing irregularity, not an exact drop count. Any other bound must be explicit in recorded configuration with calibration status UNVALIDATED_ENGINEERING_PROFILE.

Frame rankings are within the same recording/configuration, with actual measurements and stated heuristic. Preserve every decoded frame, rejected/unsampled evidence and reasons. Selection can favor texture/noise or bias optical distributions; report raw and retained coverage separately, and freeze selection rules before held-out scientific comparisons. Quality ranking alone does not verify a pupil, retinal reflex or refractive information. Unknown anatomy cannot be silently assigned OD/OS; both-eye directional streams remain independently observed.

No common numeric sharpness/brightness cutoff is justified across resolution, charts, pupil size, processing or devices. Study-specific acceptance should be derived from the measured change in segmentation/refractive features relative to independent annotations/references, then locked on development data. Clinical criteria require qualified scope and precision decisions.

## USB versus Wi-Fi procedure — nonhuman only

1. Connect DroidCam using the user's already working route. Select the actual OS camera in Capture Studio and allow browser access. Retain reported device label/settings, browser/recorder MIME and actual stream dimensions; label transport USB/WIFI as USER_DECLARED when the browser cannot observe it.
2. Use the same stationary nonhuman calibration chart, camera/lens, physical position, ambient illumination, client filters, focus/exposure/WB settings, output dimensions and recorder configuration. Record target ID and pair ID for matched repeats. A full-frame chart is sufficient for first tests; an optional source-pixel ROI isolates a specific patch. State which area is analyzed; full-frame moving scenes do not become stationary chart measurements.
3. Record USB and Wi-Fi runs in interleaved/randomized order across independent sessions, maintaining comparable target and configuration. Repeat counts/duration come from the desired precision and actual apparatus, not arbitrary scientific claims. Retain connection failures and ungradable recordings.
4. The program decodes originals and reports real per-recording values/time plots, gaps, proxy artifacts, duplicate observations and metadata limitations. Compare compatible paired measurements; flag unmatched/confounded runs rather than declaring a winner.
5. Analyze repeatability and paired session differences. Frames are correlated observations, not independent experimental sample size. Descriptive per-recording variability is not a valid clinical confidence interval. More bitrate or higher sharpness is not automatically better optical information.

To estimate actual compression distortion, obtain a genuinely synchronized/common input reference and processed output, register corresponding pixels/times, and then compare pixel/feature residuals under declared transforms. Merely recording the target twice or comparing two lossy streams cannot isolate compression. Do not report PSNR/SSIM against an invented reference. Sensor time/physical end-to-end latency also needs independent clock/reference instrumentation.

## Red-reflex feasibility and illumination

Successful virtual-camera video proves a delivery route only. Retinal-return detection additionally depends on selected optical center/source geometry, pupil aperture, gaze/view direction, focus, source spectrum/extent, ambient light, camera rendering and subject/optical reference. A plain printed chart cannot demonstrate a retinal reflex. A proper independently characterized model-eye apparatus precedes any photorefraction calibration.

DroidCam controls vary by app/client/device/tier. Record actual available controls and their observed effect instead of assuming exposure/WB/focus locks or a flash-sensor association. Client crop/rotation/mirror/color effects alter geometry and RGB measurements. Browser recording may introduce another encoding stage. Preserve originals, requested settings, observed/browser-reported settings and manual declarations separately.

Illumination must remain off during initial software/ordinary chart verification. This work specifies no human-eye torch duration/distance, no safe exposure and no human collection protocol. Existing qualified optical-safety/research permissions and independent clinical reference gates remain required before illuminated participant experiments. Quality warnings do not certify illumination safety.

## Acceptance gates

| Gate | Required evidence |
|---|---|
| Calculation correctness | Analytic RGB/clipping fixtures, fixed-scene blur ordering, known/missing/duplicate/nonmonotonic/VFR timestamps, null denominators and bounds |
| Saved-media integrity | Actual encoded video decode and frame accounting; immutable source/config/quality code/sidecar hashes; export/reload/tamper tests |
| Live-control engineering | Permission/camera discovery/selected source, startstop/still/partialerror/routecleanup, actual binary autosave and autoanalysis; fixture tests explicitly labelled |
| Browser interaction | Executed interaction against actual Lab server, retained log/screenshots; environment blockers remain blockers |
| Physical DroidCam | User's real Windows/CMF USB+Wi-Fi recordings, actual labels/settings/failures and saved-byte evidence; fixture camera is not this gate |
| Connection comparison | Matching/explicitlyconfounded protocol metadata, real differences and no unmeasured winner |
| Optical usefulness | Real annotated target/model-eye evidence, measured geometry/reference and retained failures; no synthetic substitution |
| Clinical selection | Appropriate permissions, independently measured reference, locked grouped evaluation and separate consequential-claim review |

## Primary documentation basis

Official DroidCam Windows and Help pages inspected2026-10-09UTC: https://droidcam.app/windows/ and https://droidcam.app/help/. W3C Media Capture and Streams https://www.w3.org/TR/mediacapture-streams/ and MediaStream Recording https://www.w3.org/TR/mediastream-recording/ distinguish settings/streams/recording from verified source transport and sensor exposure. FFprobe https://ffmpeg.org/ffprobe.html supplies saved-media stream/frame metadata. Evidence-specific details and access limits are in DROIDCAM_EVIDENCE.md. These documents establish API/protocol facts, not CMF optical performance.
