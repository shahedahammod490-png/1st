# Original OcuRisk risk, optics mathematics, backend and reporting audit

Audit date: 2026-10-08. Auditor: specialized read-only risk/backend subagent. Original root: `/workspace/scratch/cb3bbd583b13/audit_inputs/EYE`. File/line references below are relative to that root. New audit artifacts only; original source remains unchanged. No external AI requests or participant operations occurred.

## Scope and evidence

Read complete `src/utils/opticsEngine.ts` (1303 lines), `database.ts` (188), `server.ts` (438), `src/App.tsx` (316), `src/components/Step2Questionnaire.tsx` (530), `Step5FusionProcessing.tsx` (330), `Step6ResultsReport.tsx` (869), `src/types.ts` (229), both test files (172 and 77), manual-input utility, all research registries and complete `docs/PROJECT_DOCUMENTATION.md` (879 lines). Selected Step4/eyeTracker/Step3 call sites were traced; the dedicated acquisition/CV auditor owns their complete review. Documentation was read in overlapping sections, including a follow-up for the tool-truncated middle of the complete-document read.

Evidence status: source inspection, arithmetic counterexamples, and current source test count. Historical registry claims are not new verification. Dependencies were absent from this extracted directory when checked; no installation/build/test run of the original was performed by this auditor. Parent may append independent isolated-copy build/test evidence elsewhere.

## Outcome

The repository contains reusable application/persistence infrastructure and real numerical/image-processing primitives. Its current optical calibration, risk probabilities, uncertainty, astigmatism, CRADLE frame evidence and progression predictions are unsupported or incorrectly calculated. No clinical accuracy, sensitivity/specificity, agreement or usable phone acquisition has been demonstrated by this audit.

## Findings

| ID | Severity | Finding, evidence and consequence |
|---|---|---|
| RB01 | Critical scientific | `opticsEngine.ts:474–535` computes an arbitrary additive age/genetic/behavior/refraction index. No fitted likelihood, outcome definition or Bayesian conditioning. `537–570` converts the index to a display Beta shape. Keep as quarantined legacy heuristic comparator only; never calibrated probability/posterior. |
| RB02 | Critical scientific | `opticsEngine.ts:693–698` constructs CRADLE evidence from a combined scalar flag: four/one consecutive frames, fixed flash proximity 0.85, confidence 95/12. They are not observed counts/geometry. `Step6ResultsReport.tsx:232,530` calls it multi-frame. Actual per-frame detector result is not an argument to fusion. Never reuse as measurements. |
| RB03 | Critical scientific | `opticsEngine.ts:104–108` synthesizes luminance slope from crescent/reflex scalars, then horizontal/vertical slopes from multipliers 0.12/0.08. `1054–1069` adds default obliqueSlope=0.05 and outputs cylinder/axis. No independent meridian measurements exist. Image-based cylinder/axis must be unavailable until identifiable/calibrated. |
| RB04 | High scientific | `opticsEngine.ts:68–98` uses `sign*K*c*workingDistanceCm/(flashEccentricityMm*pupilDiameterMm)`, with K=6, distance=100 cm, eccentricity=12 mm. K dimensional derivation unspecified and mixed cm/mm require explicit units. CPR is width/diameter at `59`, parameter is height/radius at `60`, type agrees with height/radius (`types.ts:41`). Symmetric becomes exact zero at `92`. No detected crescent is not evidence of emmetropia; dead zone/saturation/geometry must be modelled. |
| RB05 | High integrity | `Step4PhotorefractionScan.tsx:422–434` reads per-eye optical properties absent from `eyeTracker.ts:56–57`. Both eyes use identical combined fallbacks; `436–446` therefore returns delta=0/LOW. User distance/eccentricity/K is not passed to per-eye functions, which default independently. Independent ROIs must produce independent features. |
| RB06 | High numerical | `opticsEngine.ts:553–570` omits Beta normalizer, rounds unnormalized values to 0.01 before scaling, labels peak-scaled heights probability. At risk 50 alpha=beta=9, every one of 21 posterior points rounds to zero. At risk 98 alpha 17.6/beta 1 yields Beta mean 94.62%, not 98%. Use valid density/quantile math only for a specified model. |
| RB07 | High numerical | BCEA `opticsEngine.ts:448–449`: k=-2log(1-p), then area=2pi*k*sigmaX*sigmaY*sqrt(1-rho²). Geometric bivariate-normal ellipse area is pi*(-2log(1-p))*...; code is 2×. rho clamp±0.99 (`447`) creates nonzero area for exact collinearity. Fewer than 5 points returns fabricated 0.25/0.32 deg² (`378–379`). Reimplement with calibrated coordinates and independent known covariance/degeneracy tests. |
| RB08 | High numerical | FFT zero-pads to 2^ceil(log2(n)) at `1252–1258`, but binHz=Fs/originalN at `1215`; actual padded-transform bins are Fs/paddedN. Returns only originalN/2 bins at `1302`. n=50 padded to 64 labels frequencies 1.28× actual. Fix binning, PSD/window scaling, durations and measured timestamps. |
| RB09 | High scientific | “Engbert–Kliegl” `opticsEngine.ts:812–856` thresholds first-difference speed magnitude by median+MAD, counts individual frames as events. No event grouping/duration/binocular agreement/irregular sampling handling. Reuse only under generic speed-outlier baseline name. Low-rate video does not establish microsaccade frequency. |
| RB10 | High scientific | Li/Foo `950–1043` are explicitly invented illustrative coefficients and correctly flagged illustrativeOnly. Five-year curve `636–688` uses arbitrary 0.85 annual scaling, age decay and 1.4/0.4 multipliers. `Step6:641–674` labels forecasts unmanaged/managed/early intervention. Remove from scientific predictions pending longitudinal targets/model artifacts. |
| RB11 | High numerical | Li toy high-myopia probability `987–995` has no lower bound. Projected SE=-2 yields −10%; projected SE=-2.5 yields −2.5% before JS integer rounding. Even illustrative probability implementation is invalid. |
| RB12 | High scientific | Separate Beta-Bernoulli helper `869–917` fixes prior 3/7 and arbitrary reliability weights/pseudocount 3.5; fractional sensor scores treated as outcome-like observations without data-generating likelihood. Interval clipped normal approximation, not exact Beta quantiles. It is not current Step 5 engine (`Step5:9,88` imports/calls calculateMultiModalRisk only). Need declared event/horizon/prior/likelihood/correlation/missingness/fit evidence. |
| RB13 | High privacy | `server.ts:59–91` defaults Gemini, and any provider other than exact `ollama` routes cloud. Named patient/profile/metrics enter prompts `206–234,331–350`. UI sends full session `Step6:116–123,161–165`. Lab defaults no external AI and pseudonymous identifiers; cannot silently inherit configuration. |
| RB14 | High safety | Validation `server.ts:293–319` only checks strings; callers `264–269,368–373` append disclaimer and return rejected text. Safe-harbor substring anywhere bypasses forbidden claims globally (`307`). Not enforcement/clinical safety verification. |
| RB15 | High integrity | Truthiness fallbacks `server.ts:348–350,280,384` overwrite valid zero SE/BCEA/delta/risk with combined values/N/A or invented −2.50/1.40/75. Use null-aware values and failure state without fabricated results. |
| RB16 | High security | No auth/authorization for CRUD/delete-all (`server.ts:130–195`). Default localhost mitigates exposure (`22`) but HOST configurable. Validation `106–120` shallow, no finite/range/date/nested checks. Plaintext named SQLite and localStorage (`database.ts:12–24,119–125`; `App.tsx:94–97,125–126`). Local prototype only; deep validation, pseudonyms, access/consent scope before participants. |
| RB17 | Moderate reproducibility | Clear History `App.tsx:306–309` removes browser history only, SQLite retains mirror. Dashboard/export ID is reconstructed from name and timestamp regenerated on render (`180–188`), unlike saved UUID/date (`113–120`, restoration `163–173`). Use stable identities/deletion semantics. |
| RB18 | Moderate provenance | Prepared patient/scans initialize while demoMode=false (`App.tsx:24–59,86–91,106`), reset restores defaults (`141–148`). Step6 camera provenance inferred from demo flag (`252–254`), not records. Start unknown; explicit default/demo/synthetic/actual origin on every record. |
| RB19 | Moderate scientific | Defocus logMAR is absD*0.18 (`opticsEngine:1132–1142`). Step2 fixed font pixels (`24–35,402`) with approximate 2 m instruction (`388`), no physical screen calibration/standard optotype/monocular or multi-symbol protocol. Not clinical reference for optical calibration. |
| RB20 | Moderate consistency | “AAPOS classification” constants `opticsEngine:23–39,100–101` not age-conditioned criteria. Anisometropia high >2 D (`199–215`) differs from high >1.25 D (`1149–1163`) and Step 6 fallback high ≥2 D (`215`). Use endpoint/source/version/age definition and centralized thresholds. |
| RB21 | Moderate validity | Most utilities permit NaN/Inf. SG window/order not validated (`236–298`), inversion continues past singular pivot (`341–342`). NPC short stream manufactures 85 mm/12.5 degrees (`769–770`), no break returns 85 mm (`797`); histories lack length/timestamp alignment. Return invalid/unavailable. |
| RB22 | Moderate explanation | Comment “Shapley/Waterfall” (`573`) precedes manually chosen impact scores (`574–628`) that do not reconstruct true point contributions. For example, genetic two parents adds 25 prior points but impact 8.5. These are not SHAP values or faithful additive explanations. Record actual score components or fitted-model explanations. |
| RB23 | Moderate uncertainty | `opticsEngine:705` manufactures uncertaintyMargin from risk alone; `116–121` heuristic confidence cannot represent accuracy; quality/data missingness never propagates to unavailable/fusion uncertainty. No calibration or confidence coverage. |

## Documentation discrepancies

The complete 879-line technical specification was read in overlapping sections; a follow-up covered the truncated middle of the initial full-document output.

- `PROJECT_DOCUMENTATION.md:525` calls chat context **de-identified**, but `server.ts:207,331` embeds the patient name. This directly contradicts that privacy claim.
- `PROJECT_DOCUMENTATION.md:540` promises graceful failure on timeout. The local provider fetch (`server.ts:64–72`) has no deadline or abort timeout; a hanging request can leave the UI waiting. Cloud SDK behavior was not tested.
- `PROJECT_DOCUMENTATION.md:79,353,546–563` claims each result has measurement/defaulted provenance. Actual records lack provenance for individual metrics, and defaults can be displayed as camera/manual results (RB18).
- `PROJECT_DOCUMENTATION.md:352` says feature-contribution waterfall; `Step6:679–699` is a list of manually assigned impacts, not a waterfall or SHAP computation.
- The specification correctly discloses no clinical trial, clinical comparison, sensitivity/specificity analysis or regulatory submission (`687–691`); manual NPC/lag (`676`); illustrative Li/Foo (`493–496`); lack of physical flash in live acquisition (`330,671`); and returning rather than blocking invalid AI output (`536`). Disclosures do not validate the outputs.
- Historical registries are not fresh verification. `research/README.md:39–45` contains old lint/test/vulnerability claims. `research/od_os_dataflow.md:30–44` says React types are absent, but current package.json includes both React type packages. Current tsconfig still lacks strict mode. The per-eye optical defect remains.
- `docs/CALIBRATION.md:17` calls K6 a published constant while the assumptions registry marks it unverified. A primary derivation is required.
- The source registry explicitly lists papers as repo-cited/unverified; the prior-art table contains no verified comparator. Citations cannot be inherited as verified scientific evidence.
- The glossary describes CRADLE as “Clinical referral algorithm leveraging red-reflex asymmetry” (`741`). Its actual source identity should be verified independently before using the name.
- The future roadmap (`702–722`) includes disease screening, fundus and biometry ambitions; these are not implemented capabilities.

## Function and module inventory

### opticsEngine.ts

| Function(s) | Lines | Actual implementation and status |
|---|---|---|
| calculatePhotorefraction | 68–137 | Legacy uncalibrated scalar SE; synthesized slope/cylinder, heuristic confidence, classification and reflex flag |
| classifyRefraction | 143–150 | Fixed SE bins, labelled as AAPOS classification |
| calculateEyePhotorefraction | 156–193 | Wrapper extracting selected metrics; intentionally omits per-eye AAPOS/reflex flags |
| calculateAnisometropia | 199–222 | Absolute inter-eye SE difference and fixed risk bins; requires independent SE |
| savitzkyGolayFilter | 236–267 | Real least-squares convolution with truncated edge weight normalization |
| computeSavitzkyGolayCoefficients | 272–298 | Vandermonde normal-equation inverse |
| transposeMatrix / multiplyMatrix / invertMatrix | 300–359 | Small matrix helpers; singular inverse handling unsafe |
| calculateBCEA / computeBCEAFromPoints | 373–457 | SG/default or Kalman smoothing and covariance ellipse; factor error and invalid-data fallback |
| calculateMultiModalRisk | 467–713 | Hand-point index, display Beta, manual feature weights, toy trajectory/models and invented CRADLE evidence |
| gaussianSmoothTimeSeries | 723–753 | Gaussian convolution with truncated boundary normalization |
| detectNPCBreak | 761–801 | Per-index PD/distance differences; manufactured 85 mm for missing/no-break evidence |
| detectEngbertKlieglMicrosaccades | 812–857 | Speed-MAD outlier frame counting |
| calculateBetaBernoulliRisk | 869–917 | Unfitted fractional pseudocount helper with normal interval; not Step 5 engine |
| calculateWeightedLinearRisk | 923–944 | Fixed 0.35/0.20/0.20/0.15/0.10 score and missing-count uncertainty heuristic |
| predictMyopiaProgressionLi2024 | 954–1004 | Explicit illustrative invented linear formula; probability may become negative |
| predict5YearHighMyopiaRiskFoo2023 | 1010–1044 | Explicit illustrative invented logit |
| calculateRotationalAstigmatism | 1054–1071 | Synthesizes J0/J45/cylinder from slopes; caller fabricates input slopes |
| j0AndJ45ToAxisDegrees | 1079–1085 | Half-atan2 axis with zero-vector guard |
| calculateThibosPowerVectors | 1091–1106 | Consistent S/C/A to M/J0/J45 transform, rounded |
| reconstitutePrescription | 1111–1125 | Consistent minus-cylinder inverse, rounded |
| defocusToLogMAR | 1132–1143 | Uncalibrated linear absolute-SE heuristic |
| calculateAmblyopiaRiskFactor | 1149–1171 | Different anisometropia risk bins |
| analyzeHighFrequencyMicroFluctuations | 1182–1242 | Detrend, Hann window, FFT binned power and toy fatigue index |
| optimizedFFT | 1248–1303 | Actual radix-2 butterfly with padding; caller uses wrong frequency grid |

### Backend and persistence

`database.ts`: resolveDatabasePath (34), initializeDatabase (39), requireDatabase (63), finiteNumberOrNull (71), saveScanSession (75), listScanSessions (129), getScanSession (146), deleteScanSession (156), clearScanSessions (161), getDatabaseStatus (166), closeDatabase (183). Single SQLite table with WAL, full JSON snapshots and upsert. Prepared statements are useful; experiment immutability, deep validation and access control are absent.

`server.ts`: getGenAI (28), generateLLMReply (54), isValidScanSession (106), validateLLMOutput (293), startServer (402), nested listen (417). Express JSON accepts up to 10 MB. Nine route definitions: health, database status, list, get, save, delete one, delete all, chat, report. Gemini or configurable local OpenAI-compatible endpoint; Vite development middleware or static dist; one port fallback.

### App, questionnaire and reporting

`App.tsx`: prepared defaults; mirrorSessionToSQLite (61); six-step state; persistence effect on reaching Step 6 (110); reset (141), demo (151), restore (163), navigation (176), reconstructed currentSession (180), browser history clear (306). Stable experiment identity and per-metric provenance are absent.

`Step2Questionnaire.tsx`: ACUITY_LINES (24); acuityRotationDegrees (37), randomAcuityDirection (45), symptom toggle (61), handleAcuityResponse (71), nested finishAcuityTest (72), updatePrescription (111). Self-reported controls, optional single-optotype visual exercise, one combined prescription converted to power vectors. Not an independent clinical reference.

`Step5FusionProcessing.tsx`: STAGES (57), synchronous calculation in useEffect (81–114), callback ref, presentation timer, fast-forward (118), chart. Stage animation does not represent actual sequential inference.

`Step6ResultsReport.tsx`: eyeValue (38), chat (97), report (157), recommendation explanation (179), per-eye fallbacks (201), anisometropia/defocus/referral heuristics (211–236), cards, trajectory, impact list, chat, modal and print. Missing per-eye data falls back to combined data and can imply LOW asymmetry. Generated report state is not written back to saved aiNotes.

`src/types.ts`: PatientProfile, EyeMetrics, PhotorefractionData, AccommodativeEyeMetrics/Data, FixationPoint, MicrosaccadeEyeMetrics/Data, FeatureContribution, BayesianDensityPoint, TrajectoryPoint, Li/Foo/Cradle/RiskScoreResult, ScanSession, ChatMessage. Numerical unit comments exist, but there is no per-measurement origin/calibration/status/version/hash/reference contract. Per-eye AAPOS/reflex fields are intentionally omitted (`opticsEngine.ts:188–191`).

`src/utils/accommodativeInputs.ts`: defaults 8 cm and 0.75 D, bounded manual input resolver. A useful boundary, but an unsupplied default must be identified as default rather than measured or self-reported.

## Reuse recommendations

1. Thibos forward/inverse mathematical transforms after independent tests and precision handling. Entered prescription vectors are not camera measurements.
2. SG, Gaussian and FFT butterfly ideas with validated domains, correct frequency grids, timestamps and independent known outputs.
3. UI/chart/wizard/modal/camera interaction patterns as engineering ideas, never scientific proof.
4. SQLite prepared statements, WAL and upsert ideas, separated from immutable raw-acquisition and experiment records.
5. Manual NPC/lag interface preserving actual unknown/default/reported/external provenance.
6. Per-eye position series as image-space tracking; angular units and diagnostic interpretation require calibration and validation.

## Test scope and counterexample evidence

Exactly **12 optics test cases** occur at `opticsEngine.test.ts:56,61,70,77,90,99,107,115,122,137,146,160`; exactly **2 SQLite cases** occur at `database.test.ts:55,62`. Total: 14 cases across two files. They assert the legacy −2.5 anchor, clamping and quarter-diopter rounding; relative BCEA spread and default 0.25; SG flat/noise behavior; injected movement/flat stream; power-vector round trip and axes; illustrative flags/no AUC/MAE; symptom/acuity point increases; toy female 15% multiplier; hyperopic toy trajectory; manual defaults and fatigue jitter; SQLite WAL/CRUD.

These tests do not cover CV/camera/components/server routes, deep validation, AI enforcement, absolute BCEA, FFT known frequencies, Beta density/CDF, eye independence, provenance, stable timestamps or cloud egress. Internal anchors are not independent measurements.

Run `python research/audits/risk_math_reproduction.py` from the Lab root. Stdout JSON reproduces the inspected formula arithmetic without importing or mutating TypeScript: all-zero Beta display at 50%, mean mismatch at 98%, doubled ellipse area, 1.28 FFT padding frequency factor, and negative Li branch values. Five arithmetic assertions passed when run during this audit. Python and JavaScript rounding differ for negative halves; the −2 projected-SE / −10% counterexample is unambiguous, and the script reports unrounded Li branch values.

No original build or test was performed by this auditor. No historical passing result is claimed as fresh execution. Recommended isolated-copy checks: lint/test/build, known-frequency FFT and covariance ellipse, missing-data abstention, asymmetric independent eyes, API zero preservation/deep validation, stable identities, no external AI and no original writes.

## Integration and acceptance

Keep the original read-only. New per-frame/per-eye records need stable IDs, timestamps, units, ROI, acquisition/pose/illumination metadata, origin and invalidity reasons. Missing OD must never copy OS/combined. Record immutable algorithm versions, config and source hashes. Calibrated prediction requires explicit calibration and reference gates. Legacy refraction/risk are quarantined unverified comparators.

No SE, cylinder, risk probability or clinical acceptance until appropriate independent references and external validation exist. An independent verifier reviews consequential scientific claims; this audit does not approve a future implementation.
