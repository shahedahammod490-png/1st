# Original OcuRisk CV and acquisition audit

Audit date: 2026-10-08. Auditor: independent read-only CV/acquisition subagent. No original source changes, hardware operations, participant testing or clinical validation were performed. Source inspection establishes implementation facts; pure helper counterexamples establish software behaviour only.

## Coverage and evidence

Read completely: `src/utils/eyeTracker.ts` (1,884 lines), `src/components/Step3AccommodativeScan.tsx` (961), `Step4PhotorefractionScan.tsx` (1,186), `QualityIndicator.tsx` (154), all three `docs/` Markdown documents and all existing `research/` Markdown documents. Also read package/TypeScript configuration and existing optics tests. All file references below refer to protected original `EYE/`, not this independent Lab.

Original `eyeTracker.ts` SHA-256: `2ca4f4b21c7ad76a5a57ec3aa8fcec669847d35e61f588b93e537868b5c378da`.

`cv_reproduction.mjs` embeds copied helper bodies, original line ranges and SHA-256, with only declaration/export adaptations and TypeScript annotation stripping. Run `node research/audits/cv_reproduction.mjs` from the Lab. Verified on Node v24.19.0, exit 0, six assertions. No browser/model execution or clinical accuracy test is represented by that result.

## Executive assessment

The browser acquisition and Canvas/MediaPipe plumbing exist, as do descriptive image-space feature computations. Their hardware execution has not been verified in this audit. The current optical pipeline pools both eyes, calls brightness contrast a crescent height, introduces normal-looking defaults after failures, and lacks controlled native LED capture. It cannot support current independent OD/OS optical, anisometropia, calibrated diopter, clinical fixation/microsaccade or leukocoria-performance claims. Preserve those algorithms only as clearly labelled legacy experimental baselines.

## Consequential findings

Critical means a scientific acceptance blocker, not an assertion of a reproduced clinical injury.

| ID | Severity | Evidence and actual implementation | Consequence / required Lab treatment |
| --- | --- | --- | --- |
| CV-01 | Critical | `eyeTracker.ts:54–76` gives eye objects only x/y/radius/brightness; `986–990` averages pupil size, `1400–1443` pools pupil pixels. `Step4:422–434` reads nonexistent per-eye crescent/orientation/pupil-mm/reflex fields. | OD/OS get identical fallback inputs, equal SE and zero anisometropia. Independent optical streams must replace shared scalars. |
| CV-02 | High | `eyeTracker:585–586,950–955` assigns iris 468/ring469–472 to leftEye; 473/ring474–477 to rightEye; `841–845` labels them OS/OD. Upstream MediaPipe labels469–472 RIGHT_IRIS and474–477 LEFT_IRIS. Fallback leftEye searches image-right (`1067–1073`). | Laterality differs across tiers. Test labelled asymmetric fixtures and retain explicit orientation/mirror transformations. CSS display mirroring cannot repair anatomical assignment. |
| CV-03 | High | `Step4:1161–1163` saves combined `currentPhotoData` on Next; per-eye captured fields added at441–449 are absent from memoized combined calculation234–254. | Navigation discards captured per-eye/anisometropia fields. |
| CV-04 | Critical | Capture snapshots latest metrics before flash state (`Step4:399–407`), shows CSS white overlay (`784–785`), and waits before saving. Reflex is multiplied1.25 during effect (`eyeTracker:721,734`). No still/LED API is invoked. | This is a calculation from pre-effect video, not controlled flash capture. Remove artificial multiplier; native capture must log requested and returned illumination state. |
| CV-05 | Critical | `eyeTracker:1395–1467` pools top/middle/bottom pupil brightness; ratio=clip(0.08+1.75*relativeContrast,0.08,0.6). | Brightness descriptor is not segmented crescent height; a nonzero ratio is guaranteed with zero contrast. Do not accept diopters inferred from this descriptor. |
| CV-06 | High | Failed pupil-boundary extraction uses irisDiameter*0.42 radius (`630–631`), brightness35 (`651,657`), confidence88 (`659`), then iris-measurement flag true (`669`). | Assumed radius presented as measurement. Failure must produce invalid/estimated provenance, never silently measured geometry. |
| CV-07 | High | Red feature uses fixed17x17 center squares, pools both eyes, scales red/other ratio0.7, clips0.4–1 (`1154–1194`). | No pupil/glint mask; surrounding pixels contaminate feature. It is neither linear optical intensity nor per-eye reflex. |
| CV-08 | High | CRADLE-style rule >0.88 or<0.35 with3 positive frames; flash scores0.9/0.6 both exceed0.55 (`241–267`). Updates even invalid/blinking frames (`739–740`), no reset. | Flash does not gate positivity; low branch unreachable after ratio clip0.4–1. No whiteness detector, independent-eye abnormality, clinical calibration or established CRADLE equivalence. |
| CV-09 | High | rAF processes frames; repeated video timestamp is previous+1ms (`537–541`), FPS counts process calls (`506–510`). | Duplicate exposures can count as distinct stability/temporal evidence. Preserve source frame identity and actual timestamps. |
| CV-10 | High | Step3 retains last41 fixation points (`313,317,321`), no timestamps, divides event count by nominal5sec (`437–449`). | Short trailing-window count divided by whole duration gives invalid frequency; pauses/irregular sampling worsen it. |
| CV-11 | High | Pupil samples every100ms (`Step3:48,405–413,541`), HFF invoked with30Hz (`470–473`). | Actual nominal10Hz history treated as30Hz: frequency axis and HFF band wrong. |
| CV-12 | High | Eye midpoint vs frame center converted with assumed60x45deg FOV (`eyeTracker:745–758`); fixation x/y divided by22 (`Step3:53,306–321`). | Face/head translation is confused with ocular gaze. Clinical deg² BCEA/microsaccades unverified. Keep image-motion units unless gaze calibration and head compensation validate angular units. |
| CV-13 | High | Target distance35→5cm is simulated (`Step3:388–401`); screen target merely grows (`694–707`); synthetic distance feeds NPC proxy (`455–461`). | On-screen growth does not change physical viewing distance/accommodation. No measured target-approach experiment exists. |
| CV-14 | High | Saved velocity4.5mm/s, latency320ms both eyes (`Step3:494–502`), fallback event frequency1.5Hz (`447–449`), fatigue50 fallback (`476–478`); UI says Measured this scan after completion (`887`). | Defaults are downstream numbers without adequate absent-measurement status. Must not be accepted as observed physiology. |
| CV-15 | High | Focal600px, iris11.7/11mm (`eyeTracker:42–44,1716–1730`); primary result distance confident true (`581`), distance clip20–120cm (`999`); HUD IPD=ipdPx*0.28 (`861`). UI says distance measured (`Step4:1082`). | Uncalibrated estimates presented as confident physical measurements; no uncertainty. Device-specific calibration required. |
| CV-16 | High | Auto loop reads enabled/capturing (`Step4:354–355`) but effect dependencies omit them (`385`); readiness omits blur and distance confidence (`85–105`). | Stale closure may ignore toggle or retain old capture state; perfect-condition claim unsupported. |
| CV-17 | High | Step3 interval pauses only on blink/obscuration (`379–382`), not detection loss/poor focus/stopped camera; completion alone enables Next (`940`). | Scan can complete with insufficient or stale data. Require minimum valid duration/count at completion and cancellation on source loss. |

## Additional engineering and measurement defects

- Video upload seeks5Hz, max30 frames, overwrites metrics and captures only final frame (`Step4:563–622`). No frame retention, quality selection, rejected-frame log or fusion.
- Seek promise has no timeout/error settlement and begins at time0 (`579–587,593,601`); cancellation cannot settle an outstanding seek. Shared cancellation flag can be reset by a newer upload while older awaited work remains pending. Use source generation IDs/AbortController.
- Video upload leaves camera inactive and uploadedImage null. `eyeDetected` false (`208`), formula takes manual/default inputs (`214–229`), preview hidden (`795–797`). Capture closures still contain `currentPhotoData`; refs alone do not repair that combined result.
- Failed newer image upload retains old metrics (`538–544`); Next checks hasTrustedMeasurement independent of a current acquisition (`206–209,1165`).
- MediaPipe VIDEO-mode instance (`eyeTracker:389`) is reused for static images with performance.now timestamp (`1294`) while live uses video.currentTime; mixed clock origins/source resets compromise reproducibility.
- Static MediaPipe sets EAR0.26, blink/occlusion false (`1310–1312`), without measured static eye-open quality.
- Static image globally resized to max1280px (`1270–1278`), potentially discarding eye details. Upload sharpness checks original full photo before resize (`Step4:505–517`): sharp background may pass despite blurred/poorly resolved pupil.
- Pupil search counts all dark pixels inside a circle (`1526–1639`), with no connected-component/eyelid mask. Dark iris, lashes and zero contrast can pass. Radius constraints/refinement are heuristics.
- Crop height omits inter-eye vertical separation (`963`): head roll can crop one eye. Integer radius rounding precedes mm conversion (`977,983,987`), making quantization significant for distant small eyes.
- EmptyResult uses normal pupil5.5mm, reflex0.75, crescent0.25 (`912–926`); failed blur read begins120/focused (`712–735`); empty blur region returns100/focused (`1857`). Missing landmarks force no blink/obscuration (`823–826`).
- Quality defaults look valid (`QualityIndicator:107–110`), Step4 fixation constant0.82 (`775`), blurVariance||80 substitutes good focus for a true zero (`776`; Step3:643).
- Step4 HUD displays manual pupil/crescent state (`860,878`) while refs receive measured values (`185–191`), so displayed HUD differs from calculation inputs.
- Remote WASM uses @latest (`eyeTracker:375,417`); no runtime/model hash/version or actual getSettings/capabilities provenance is retained.
- Separate Step3/4 EyeTracker instances load separate landmarker resources; there is no close/destroy method. Unmount stops camera but does not close model (`Step3:130–133`; `Step4:193–196`).
- Camera is getUserMedia, facingMode user and ideal1280x720 (`Step3:234–243`; `Step4:286–293`). An explicitly chosen camera may be a different feed: do not claim guaranteed physical front-camera use. No native USB transport, still/torch control, exposure/ISO/focus lock, sensor timestamps, pose or returned capture metadata exists.
- Unused HSV utility multiplies sectors by30 but compares degree thresholds20/340 (`eyeTracker:1775,1778`); actual orange40deg accepted. Unused Z-depth helper maps normalized z arbitrarily (`1869–1884`); not metric depth.

## Reproduced helper counterexamples

All fixtures are synthetic software tests. Uniform-frame tests supply iris/pupil center and radius directly; they do not show MediaPipe detects a face in a blank frame.

| Test | Actual result |
| --- | --- |
| Uniform40x40 grayscale0/50/100, supplied iris radius10px | Pupil radius7.92px, although no pupil boundary exists. |
| Uniform grayscale50 or100, supplied pupil region | Red ratio0.7; crescentRatio0.08 SYMMETRIC. |
| Uniform black, supplied pupil region | Red ratio0.4; crescentRatio0.08 SYMMETRIC. |
| Three ratio1 inputs with flashActive false | Positive on third; confidence36. |
| Empty Laplacian sampling window | variance100, focused true. |
| RGB255,170,0 (approximately40deg orange) | HSV red=true. |

## Public and internal API inventory

| Export | Role / acceptance status |
| --- | --- |
| BLINK_EAR_THRESHOLD0.12, OBSCURED_EAR_THRESHOLD0.08, BLINK_BLENDSHAPE_THRESHOLD0.55 | Unvalidated detection thresholds, despite clinical-standards comment. |
| PupilFrameResult | Combined optical scalars plus per-eye position/radius; inadequate measurement contract. |
| OneEuroFilter2D: reset/update/getPosition | Display/tracking smoother; requires timestamp and response tests. |
| KalmanFilter2D: reset/predict/update/getPosition | Retained simplified legacy filter; not default EyeTracker smoother. |
| CradleLeukocoriaDetector: processFrame | Arbitrary ratio temporal rule; not validated CRADLE implementation. |
| EyeTrackerEngine: constructor/getMediaPipeStatus/processFrame/processImage | Browser model initialization, acquisition-frame processing and still processing. No release API. |
| calculateEyeAspectRatio | Geometric EAR; zero-width input returns0.3/no blink rather than invalid. |
| estimateDistancePinholeModel | Generic focal/iris assumption; invalid iris returns60cm. |
| convertRGBToYCrCb | Descriptive color transform; different formula coefficients from inline fallback should be standardized. |
| isRedHueInHSV | Unused and degree-scale defect. |
| computeRadialPupilContrastRefinement | Contrast-centroid bounded radius adjustment, not mm calibration or true edge fitting. |
| computeLaplacianBlurVariance | Descriptive image sharpness; invalid window must not return focused. |
| extractMediaPipeZDepth | Explicitly unused arbitrary normalized-depth mapping. |

Internal functions: otsuThreshold; irisRingDiameterPx; cropImageData; findPupilBoundary; computeEyeRegionBounds; estimateCrescentFromPupilRegion. Engine internals: initMediaPipe, measureAmbientLight, emptyResult, extractOpticalMetricsFromLandmarks, detectEyesAdvancedCV, runAdaptiveDarkRegionSearch, computeRedChannelRatio, drawPupilHUD.

## Actual pipeline and reuse

Default browser video request → rAF → Canvas copy → remote-first/local-fallback MediaPipe → iris ring/heuristic dark pupil search → One Euro center smoothing → pooled reflex/brightness crescent/blur → default-filled PupilFrameResult → Step3 image-motion summaries or Step4 optical formula. When MediaPipe fails: sampled skin-color bounding box → proportioned eye zones → all-dark-pixel centroids/radii. Source/model/algorithm tiers are not fully retained in output.

Reusable engineering patterns after tests: camera enumerate/start/stop, image decode, local assets, laterality-corrected landmark ROI proposals, descriptive EAR and blur, One Euro display filtering, Otsu helper, overlay/scatter patterns. Reuse upload code concepts with cancellation and failure-state repairs.

Legacy experimental comparators only: dark pupil segmentation, iris ruler, generic pinhole distance, pooled brightness descriptor, arbitrary red ratio and temporal anomaly rule. Preserve exact formulas/configuration and label feature units, invalidity and calibration status.

Do not reuse as validated measurements: calibrated refraction/cylinder, existing OD/OS optical and anisometropia, clinical fatigue/microsaccades/gaze, LED capture claims, disease detection, fake latency/velocity or confidence-as-probability.

## Documentation versus implementation

- docs/PROJECT_DOCUMENTATION.md306–309 calls BCEA/microsaccades/fatigue camera-measured, while physical gaze calibration/timing/reference validation are absent.
- Lines325–328 describe crescent-height extraction and per-eye photorefraction; actual contrast descriptor pools eyes and per-eye inputs do not exist.
- Line396 attributes3-of-5 rule to CRADLE methodology, but no corresponding verified clinical implementation/evaluation exists.
- Lines330,671 disclose dependence on actual illumination and say live yields no crescent. This absolute statement is too broad: signal depends on actual optics/external acquisition. Proven software fact is that this app controls no LED and does not record its state. Its screen overlay does not establish controlled eccentric illumination.
- Lines405–407 advertise <=2 Canvas reads. Primary path now reads full-frame pixels (`eyeTracker:563`) and crops in memory, rather than only the small pupil read described in comments. Failed extraction/fallback can add reads. No measured latency/throughput benchmark is included.
- Lines669–695 correctly disclose uncalibrated assumptions/no clinical validation; these disclosures do not validate stronger headline claims.
- docs/CALIBRATION.md honestly calls confidence heuristic, but k=6 published attribution remains source-unverified in this CV audit. Optical/literature audit owns formula verification.
- docs/segmentation-model-integration-plan.md is an unimplemented model plan, with illustrative empty methods and future targets; no segmentation module or trained pupil/crescent model is present. Targets/timeline are not achieved results.
- Existing research/od_os_dataflow.md and change_log.md say React types absent; current package.json includes @types/react and @types/react-dom. Old clean-lint/14-test results are historical notes, not current-run evidence. tsconfig still lacks strict setting.
- Existing research notes describe per-eye fixation as legitimate: separate positions exist, but anatomical labels/angular physiology remain unverified. Existing camera_flash_geometry.md asserts default means front camera/no possible reflex; actual selected camera can differ and external illumination is not ruled out.
- Existing prior-art/source registry has no opened comparator table; no novelty or performance inference should be imported from those notes.

## Test gaps and acceptance criteria

Existing optics tests assert formula outputs and synthetic signal monotonicity; canonical Howland anchor reproduces implemented arithmetic, not optical validation. No eyeTracker/Step3/Step4/quality tests exist in original inspected repository. No hardware frame quality, unique-frame rate, laterality fixture, annotation agreement, clinical reference or test-retest dataset was supplied.

Before Lab software acceptance:

1. Immutable source-frame IDs/exposure timestamps; reject duplicate exposures and compute temporal metrics from actual timestamps.
2. Per-eye anatomical side with transformation/rotation/mirror provenance; unknown side remains UNKNOWN. Labelled asymmetric fixtures across detector tiers.
3. Independent pupil/crescent/glint/occlusion/saturation masks/features. No-signal returns zero-feature/invalid/abstention as appropriate, not fabricated normal measurements.
4. Pixel/dimensionless features remain in those units until calibrated scale and uncertainty exist.
5. Native LED capture claims require requested and returned metadata; never multiply measured reflex by UI flash state.
6. Retain each processed/rejected frame, quality decision and config/hash. Replay and image/video/live equivalent-input agreement.
7. Distinct measured/estimated/default/configuration/manual/absent provenance; no normal numeric fallbacks in observed data.
8. Completed scans require sufficient valid timestamps/data, and cancel on source loss. No stale media saving.
9. Pin/hash models/runtime/config and close resources reliably; no remote latest in reproducible experiments.

Before scientific acceptance: independent reference measurement and ethical permission gate any refractive accuracy, cylinder/axis, clinical fatigue, gaze/microsaccade or leukocoria claim. Hardware support, local software tests, synthetic segmentation tests and clinical validation are separate gates. This audit independently blocks acceptance of original scientific output claims; it does not itself verify later Lab implementation.
