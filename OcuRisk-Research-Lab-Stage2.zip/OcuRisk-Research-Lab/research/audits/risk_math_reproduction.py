#!/usr/bin/env python3
"""Arithmetic counterexamples to legacy formulas; not clinical or TS runtime evidence."""
import json
import math


def js_round_nonnegative(x):
    return math.floor(x + 0.5)


def beta_display(risk):
    mean = risk / 100
    alpha = max(1, js_round_nonnegative(mean * 18 * 10) / 10)
    beta = max(1, js_round_nonnegative((1 - mean) * 18 * 10) / 10)
    points = [js_round_nonnegative((x/100)**(alpha-1) * (1-x/100)**(beta-1) * 100) / 100 for x in range(0, 101, 5)]
    peak = max(points) or 1
    scaled = [js_round_nonnegative(v/peak * 100) for v in points]
    return {"risk_index_percent": risk, "alpha": alpha, "beta": beta, "beta_mean_percent": 100*alpha/(alpha+beta), "posterior_display_points": scaled, "all_zero": not any(scaled)}


def main():
    p = 0.9545
    code_area = 2*math.pi*(-2*math.log(1-p))
    geometric_area = math.pi*(-2*math.log(1-p))
    result = {
        "evidence_type": "independent arithmetic reproduction of inspected formulas; not original TypeScript execution, optical measurement, or clinical performance",
        "source": {"beta": "opticsEngine.ts:537-570", "bcea": "opticsEngine.ts:448-449", "fft": "opticsEngine.ts:1215,1252-1258", "li": "opticsEngine.ts:987-995"},
        "beta": [beta_display(risk) for risk in (5, 50, 98)],
        "bcea": {"p": p, "unit_covariance_code_area": code_area, "unit_covariance_geometric_area": geometric_area, "ratio": code_area/geometric_area},
        "fft": [{"input_length": n, "padded_length": 2**math.ceil(math.log2(n)), "label_to_actual_frequency_ratio": 2**math.ceil(math.log2(n))/n} for n in (50, 64, 100)],
        "li_unrounded_branch": [{"projected_se_diopters": se, "raw_percent": 20 + (2-abs(-6-se))*15} for se in (-2, -2.5, -3, -3.5, -3.99)],
    }
    assert result["beta"][1]["all_zero"]
    assert result["beta"][2]["beta_mean_percent"] != 98
    assert result["bcea"]["ratio"] == 2
    assert result["fft"][0]["label_to_actual_frequency_ratio"] == 1.28
    assert result["li_unrounded_branch"][0]["raw_percent"] == -10
    result["arithmetic_assertions_passed"] = 5
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
