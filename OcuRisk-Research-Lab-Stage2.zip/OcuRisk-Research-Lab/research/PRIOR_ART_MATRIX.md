# Prior-art matrix

Review date: 2026-10-08. Status: initial screened registry, **not exhaustive**. Relevant patent descriptions/claims were opened and inspected. These are prior-art documents, not clinical evidence or legal freedom-to-operate conclusions. Original OcuRisk was unchanged.

| Record / title | Existing concepts | Similarity and distinction | Implication |
| --- | --- | --- | --- |
| https://patents.google.com/patent/US12538040B2/en — *Camera system on mobile device for automated eccentric photorefraction*, published 2026-01-27 | Known light-camera geometry, mobile videos, ML, independent both-eye processing, multimeridian arrangements | Direct overlap with generic smartphone/video/per-eye ML; described configurations need not match CMF's native layout | No “first smartphone video photorefraction” claim |
| https://patents.google.com/patent/WO2022150448A1/en — *System and method to measure aberrations by imaging both the crescent and the halo of the crescent*, 2022 | Full 2D light distribution, crescent/halo, smartphone RGB camera, multiple orientations/cameras, geometry-aware models | Full spatial-map and halo features have precedent; patent assertions are not OcuRisk results | No automatic novelty for full-map or halo analysis |
| https://patents.google.com/patent/US20190167093A1/en — *Component, computer program, system, and kit for corrective lens determination*, 2019 | Smartphone optical attachment, different illumination directions, angular positions, position sensors, multimeridian reconstruction | Opposite views and angular positioning already described; attachment differs from native-phone-only acquisition | No generic multiview/rotation novelty claim |
| https://doi.org/10.2196/16225 — Chun et al. 2020 | Smartphone flash photorefraction and CNN classification | Static LG acquisition and class ranges, different device/population | Smartphone + red reflex + CNN already known |
| https://research.polyu.edu.hk/en/publications/using-a-smartphone-camera-in-detecting-refractive-error-among-sch/ — Do et al. ARVO 2022 | Four phone meridians with flash, crescent/pupil measurement | Conference abstract only; roll/meridian orientations differ from lateral/yaw directional-video experiment | Multiple smartphone meridians already investigated |
| https://doi.org/10.1016/j.ijmedinf.2025.106083 — Cheung et al. IJMI 2026 | Smartphone CNN regression/binary screening | Abstract inspected, full methods unavailable | Quantitative CNN investigation also prior art; no benchmark transfer |
| https://doi.org/10.1364/JOSAA.30.000923 — Bharadwaj et al. 2013 | Binocular video luminance gradients, calibration, repeatability | Dedicated IR instruments differ from white-LED smartphone | Generic dynamic binocular photorefraction not new |

## Candidate differentiation requiring evidence

- A reproducible, measured CMF Phone 2 Pro native acquisition protocol under documented optical geometry.
- Participant-held-out evaluation of static versus controlled directional-phone videos with all four per-eye streams preserved.
- Whether best-view/fusion/complementary strategies materially improve error, repeatability or gradability on the same data.
- Device-specific calibration, abstention and a transparent uncertainty/failure audit.
- Locally relevant independently referenced dataset and a reproducible collection/evaluation methodology.

All remain **UNVERIFIED** as novelty and **HYPOTHESIS** as performance advantages. The review does not establish that two opposite videos provide independent meridional information, nor that head-turn improves screening. If the hypotheses fail, preserve that result.

## Outstanding search/access work

Complete full-method and claims review of relevant contemporary papers/patent families, including model-eye regression and STARS; examine public conference/thesis precedents for the exact controlled directional motion. Search scope and retrieval failures must remain visible. Any legal freedom-to-operate question requires its own appropriate expert assessment; no legal conclusion is made here.
