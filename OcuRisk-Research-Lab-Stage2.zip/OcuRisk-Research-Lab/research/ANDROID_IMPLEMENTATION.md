# Android / Windows USB implementation record

Stage2 final recovery update: 2026-10-09. Native state **BUILD_BLOCKED**, no APK. Official Gradle8.11.1/JDK17.0.18/SDK CLI were recovered, but SDK35 manifests and Android Gradle Plugin8.9.2 resolution failed. Exact native failure: `android-evidence/build-recovery-final.txt`; toolchain archive hashes: `android-evidence/toolchain-recovery-sha256.txt`. Current host result: **9 tests passed**, `android-evidence/host-tests-final.txt`. Windows/physical CMF/LED/timing remain unverified. See `../android/README.md` for current lifecycle, video and Stage2 byte/sidecar import behavior. The later source has not compiled.

Historical Stage1 description follows; video/host counts below are updated, other physical boundaries persist.

Date: 2026-10-08. Assigned scope: `android/`, `tools/windows/`, this record. Original OcuRisk files were not modified. This record describes source and host checks; it is not a CMF Phone 2 Pro capability result, a successful Android build or an optical validation.

## Delivered behavior and evidence boundary

| Component | State | Actual evidence |
|---|---|---|
| CameraX app source | IMPLEMENTED_UNTESTED | Java/manifest/Gradle source written and reviewed; no compilation/device execution |
| Windows PowerShell workflow | IMPLEMENTED_UNTESTED | Source reviewed; `pwsh`/Windows unavailable here |
| Python byte transfer/integrity helper | TESTED_ENGINEERING_ONLY | Nine current host tests with synthetic fixtures, actual FFmpeg encoding and simulated transport pass |
| Real USB transfer / phone acquisition | IMPLEMENTED_UNTESTED | ADB/phone unavailable; no actual transfer or capture |
| Video recording source | IMPLEMENTED_UNTESTED | CameraX Recorder silent native MP4; actual callbacks, UNKNOWN encoded/sensor association; build/device blocked |
| Direct Android HTTP upload / live stream | NOT_IMPLEMENTED | Optional explicit ADB reverse command only maps a port |
| Phone/head pose, distance, LED/camera geometry | NOT_IMPLEMENTED | Missing values are null |
| Physical illumination verification / optical safety | AWAITING_REFERENCE_DATA | Separate physical observation and qualified review required |
| Human acquisition / clinical inference | NOT_IMPLEMENTED | App restricted to inert nonhuman engineering tests |

`android/app/src/main/java/org/ocurisk/lab/acquisition/MainActivity.java` implements the native UI. The camera spinner starts with a selection placeholder and never binds ID `0` or assumes a main lens. Only CameraX-exposed cameras whose Camera2 `LENS_FACING` is BACK can be selected. Other IDs and physical-camera IDs remain in the full capability export. Operator verification is needed to identify which exposed ID corresponds to the intended rear lens and whether a logical camera switches physical cameras.

The UI has stable resource IDs for `camera_id_selector`, `bind_selected_camera`, `nonhuman_ack`, `capture_nonhuman_still`, `torch_nonhuman_test`, `torch_off`, `export_capability_probe`, `exposure_ns`, `iso`, `apply_manual_sensor`, and `restore_auto`. These support future on-device instrumentation; no instrumented UI tests were run.

`CapabilityProbe.java` exports Android release, SDK/model/build fingerprint; all readable Camera2 characteristics and supported request/result keys; available AE/AF/AWB/stabilization controls; flash availability; lens/sensor metadata; exposure/ISO ranges; advertised FPS ranges; per-format resolutions with minimum-frame/stall durations; high-speed advertised sizes/FPS; logical/physical IDs and characteristics; sensor timestamp source; and motion-sensor inventory. Read failures are explicit errors with null values. Advertised rates/resolutions are not measured throughput. Geometry and poses are null. Sensor availability is not a measured orientation/motion trace. No advertised CMF phone specification is treated as runtime support.

The automatic baseline explicitly requests AE ON and flash OFF, continuous-picture AF/AWB AUTO where advertised, and stabilization OFF where advertised. The manual exposure/ISO action requires MANUAL_SENSOR and AE OFF support and validates integers against reported ranges. It uses `Camera2CameraControl.setCaptureRequestOptions`. Autofocus, manual focus, white-balance gains, stabilization variants and flash capture are not fully exposed as experiment controls yet; available controls are inventoried and actual request/result values recorded. Driver/CameraX behavior may override or reject requests; no request is presented as measured sensor behavior.

The Camera2Interop session callback attached to the Preview builder records every callback received in a session JSONL, with request and result fields: exposure ns, ISO, AF/AE/AWB modes and states/locks, lens focus distance, flash mode/state, video/optical stabilization, frame duration, capture intent, sensor timestamp, frame number and active physical camera ID (API 29+, otherwise null). Null fields stay null. A bounded 512-result association cache supports still matching; the on-disk callback log retains the callbacks actually received. This callback log is not proof that every sensor frame was received and is not video data.

Still acquisition uses `ImageCapture.takePicture(...OnImageCapturedCallback)` and accepts only native JPEG. It copies the JPEG bytes without re-encoding or applying rotation/mirroring and immediately closes the ImageProxy. It saves width/height, rotation metadata, raw ImageProxy timestamp, app-requested settings, per-camera capability snapshot, build fingerprint and software click/save uptime timestamps. It waits up to approximately two seconds for an exact ImageProxy/SENSOR_TIMESTAMP association on the same camera. A missing association yields `matched_result: null`, `MISSING_EXACT_SENSOR_TIMESTAMP_MATCH`, and null capture-manifest timestamp; it never picks the closest result or uses callback index/FPS. Known sensor timestamp and every nanosecond integer are persisted as decimal strings. Clock domains are not assumed equal; the Camera2 timestamp-source value is saved, and UNKNOWN cannot establish IMU/uptime alignment. Click/save elapsed times are engineering timestamps rather than measured shutter/transport latency.

Every capture gets immutable app-private `files/export/capture_<uuid>/capture.jpg`, `metadata.json`, `manifest.json`, and `checksums.json`. Manifest schema matches `contracts/INTERFACES.md`: CONTROL, NON_HUMAN_TEST, explicit null distance/pose/mirroring and OD/OS annotations, native image hash, and OFF requested illumination. Flash mode/state can produce OFF/TORCH/FLASH/UNKNOWN as a **software report**. `physical_verified` is always false and `evidence_id` null. Probe export uses `files/export/probe_<uuid>/capabilities.json`, a synchronized snapshot of actual `capture_results.jsonl`, and checksums. Checksums are written last and mark the export complete; folders without them are incomplete. The phone retains data; transfer never deletes it.

The app generates a persistent anonymous device UUID in private preferences and a fresh session UUID for each Activity session. Build/model information is retained separately; a phone model is not used as a supposedly unique device identifier. The app has no INTERNET permission and no server endpoint. The PC contract accepts image imports; `metadata.json`, capability exports and logs remain separate local evidence files and are not silently injected as unsupported backend image fields. A later backend schema should associate these evidence files with the capture before richer acquisition studies.

## Illumination boundary

All captures request torch OFF and ImageCapture FLASH_MODE_OFF. Capture is gated while the torch test is active and requires the inert-nonhuman-target checkbox. The separate torch button requires CameraX `hasFlashUnit()`, requests torch ON and schedules an OFF request after 1.5 seconds; the lifecycle pause/destroy path also requests OFF. Errors are shown. This is a best-effort engineering request interval, not a certified emission duration or an eye-safety limit. A positive API completion/flash state never proves LED emission. No operator-facing control allows the app to assert verified physical LED state.

Physical LED support/emission/duration requires separate nonhuman observation/evidence; keep the actual observation, observer, instrumentation, conditions and evidence ID outside API-reported state. Failed or absent observation remains unknown. No close-range/prolonged human eye illumination protocol is provided. Human retinal-reflex experiments require a separately approved protocol, consent/ethics requirements and qualified illumination-safety review; this source does not unlock human acquisition.

## Pinned toolchain and primary documentation

| Pin | Rationale / official source |
|---|---|
| Android Gradle Plugin 8.9.2 | Published patch within the documented 8.9 toolchain; [AGP 8.9 official notes](https://developer.android.com/build/releases/agp-8-9-0-release-notes) specify Gradle 8.11.1, JDK 17, SDK Build Tools 35.0.0 and maximum supported API 35 |
| Gradle 8.11.1; JDK 17; compile/target SDK 35; min SDK 23 | Explicit local debug research build; no Kotlin compiler plugin, NDK or wrapper JAR needed. Android SDK and Gradle must actually be installed before build |
| CameraX core/camera2/lifecycle/view 1.5.3 | Published stable patch, chosen explicitly rather than a claim of latest; [CameraX official release notes](https://developer.android.com/jetpack/androidx/releases/camera) document the JPEG-related ExifInterface fix in this release and compileSdk 35 requirement in 1.5 |
| AndroidX Activity 1.10.1 | Published patch with ComponentActivity/LifecycleOwner, compatible with the chosen SDK35 era; [Activity release notes](https://developer.android.com/jetpack/androidx/releases/activity). The notes say Activity1.11 is compiled with API36, so it is deliberately not substituted |
| Python 3.11+; PowerShell5.1+; installed platform-tools | Host helper uses standard library; PS wrapper uses native ADB and Python. Runtime versions must be recorded on the actual Windows machine |

Dependencies are explicit direct pins, not a lockfile for every transitive dependency. A real build must record the resolved dependency graph (`gradle :app:dependencies`) and SDK packages. No SDK/Gradle download or compilation was possible here. No binary wrapper is fabricated; use an installed Gradle 8.11.1 distribution or generate/verify a wrapper on the equipped build machine.

Additional official references inspected on 2026-10-08:

- [CameraX still-image acquisition](https://developer.android.com/media/camera/camerax/take-photo): in-memory/file capture and lifecycle binding.
- [Camera2Interop.Extender](https://developer.android.com/reference/androidx/camera/camera2/interop/Camera2Interop.Extender): session callback and request interop. Current online docs also describe newer deprecation/replacement APIs; this project deliberately uses the callback API present in pinned CameraX1.5.3, not an unverified upgrade.
- [CameraCharacteristics](https://developer.android.com/reference/android/hardware/camera2/CameraCharacteristics): capabilities are runtime metadata and can be absent.
- [CaptureResult](https://developer.android.com/reference/android/hardware/camera2/CaptureResult): sensor/3A/flash/stabilization metadata. Active physical camera ID is API29+.
- [ADB official guide](https://developer.android.com/tools/adb): USB debugging authorization, `devices`, serial targeting, `exec-out`, install and reverse forwarding. ADB debugging does not itself expose the camera/LED.

## Windows workflow (to execute on equipped host)

Install official Android SDK platform-tools/SDK/Gradle/JDK and Python. Enable USB debugging and authorize this computer on the phone; use a USB data cable. If unauthorized/offline, the scripts fail rather than selecting another device. No rooting, bootloader unlock, factory wipe or application-data deletion is included.

From the lab root:

```powershell
python --version
java -version
gradle --version
.\tools\windows\OcuRisk-Usb.ps1 -Mode Devices -Adb 'C:\Android\platform-tools\adb.exe'
.\tools\windows\OcuRisk-Usb.ps1 -Mode Diagnostic -Serial 'ACTUAL_SERIAL' -Adb 'C:\Android\platform-tools\adb.exe' -OutputDirectory '.\device-evidence'
```

Devices mode lists serial/state only; every other mode requires an explicit serial. Diagnostic mode writes UTC/host version, ADB version/device list, Android release/SDK/build fingerprint/model, `dumpsys media.camera` and `dumpsys sensorservice` to a new dated folder. Restricted/failing commands fail explicitly and any partially written diagnostics should be treated as incomplete.

Build in `android/` with the documented toolchain:

```powershell
gradle :app:assembleDebug :app:lintDebug
gradle :app:dependencies
```

Only after successful build, explicitly request installation:

```powershell
.\tools\windows\OcuRisk-Usb.ps1 -Mode Install -Serial 'ACTUAL_SERIAL' -Apk '.\android\app\build\outputs\apk\debug\app-debug.apk'
```

This uses `adb -s <serial> install -r` for the separate lab app package. It does not delete app data. Install mode does not run by default. Launch the lab app on the phone, grant camera permission, select a rear ID, bind it, export the probe, and perform acknowledged inert-target still/optional torch engineering checks. Copy each exact sealed export ID displayed by the app.

```powershell
.\tools\windows\OcuRisk-Usb.ps1 -Mode Export -Serial 'ACTUAL_SERIAL' -CaptureId 'probe_ACTUAL32HEXUUID' -OutputDirectory '.\device-evidence'
.\tools\windows\OcuRisk-Usb.ps1 -Mode Export -Serial 'ACTUAL_SERIAL' -CaptureId 'capture_ACTUAL32HEXUUID' -OutputDirectory '.\device-evidence'
python .\tools\windows\adb_export.py verify '.\device-evidence\capture_ACTUAL32HEXUUID'
python .\tools\windows\adb_export.py payload '.\device-evidence\capture_ACTUAL32HEXUUID' --output '.\capture-import.json'
```

UUID placeholders above must be replaced by the exact lowercase hexadecimal 32-character value from the app. `adb_export.py` runs `adb -s SERIAL exec-out run-as org.ocurisk.lab.acquisition cat files/export/ID/NAME` without a host shell. Debug build is required for run-as; failure does not trigger a privileged fallback. Binary stdout is handled as bytes, avoiding PowerShell text-redirection corruption. File names/IDs/serials, checksum schema, duplicate JSON keys, finite JSON values, file counts and bounded byte lengths are checked. Exact file byte lengths and SHA256 must match; local unexpected files/symlinks are rejected. Existing output folders/payload files are never overwritten. Interrupted transfer can leave an incomplete folder; rerun with a fresh destination, and do not import it until verify passes. These hashes detect accidental transfer corruption, not authenticity or clinical validity.

Payload mode creates the actual `{manifest,files:[{name,base64}]}` import object using verified capture.jpg bytes; it preserves timestamp strings and missing anatomical annotations. Import into the PC service by its existing capture API/UI, then annotate OD/OS in decoded native image coordinates. Do not assign eye identity from file side or movement direction. The capability probe is not an importable image capture.

Optional `-Mode Reverse` maps `tcp:8765` device→PC and `-Mode RemoveReverse` removes that mapping. The phone upload client is NOT_IMPLEMENTED; successful forwarding is not successful HTTP acquisition. Keep the PC server loopback bound. Do not treat a port mapping as a camera capability.

## Actual tests and remaining gates

Executed on Linux with Python 3.12.14 and OpenJDK17.0.20 present:

```text
python -m unittest discover -s tools/windows -p 'test_*.py' -v
Ran 6 tests: OK
```

Tests use explicitly synthetic host bytes; they prove real-byte hash/length verification, corruption detection, unsafe/duplicate-path rejection, invalid size/JSON rejection, large timestamp-string/base64 preservation, explicit serial/no unsafe ID, a simulated ADB byte roundtrip, and no overwrite. The synthetic JPEG-magic fixture is not camera/optical evidence. XML source files were checked for well-formedness. No Android class compilation, Android lint, APK, emulator, instrumented test, phone, actual ADB call or Windows PowerShell execution was available. Those are required gates, not inferred passes.

1. Build/lint the pinned app on the equipped Windows host, record dependency resolution and tool versions; correct actual compile/runtime failures before device claims.
2. Validate PowerShell modes/error behavior with authorized, unauthorized, offline and multiple-device connections; confirm serial targeting. Retain Windows/ADB versions and failed command output.
3. Export actual CMF diagnostics/probe and determine supported IDs, main-rear/physical-camera mapping, metadata completeness, resolutions, FPS and sensor timestamp source. Unreported information remains null/unknown.
4. On inert targets, compare default/manual requested versus actual results, verify JPEG content/hash/rotation, exact timestamp association/failure handling, physical LED state and lifecycle OFF behavior. Independently measure duration/latency/frame rate when needed; app uptime differences alone do not establish them.
5. Transfer via run-as, verify all actual hashes, generate import payload and complete PC roundtrip. Keep raw files and acquisition sidecars. Confirm interruption/retry behavior without deletion.
6. Device validation of implemented video source remains separate work: encoded video + retained frame timestamps + all-frame offline replay, actual timing/dropped-frame evidence, both anatomical eyes represented in each direction, and pose/geometry qualification. No KEEP_ONLY_LATEST path can stand in for retaining every recorded frame.
7. Physical geometry calibration, calibrated optical exposure evaluation and approved human data gates stay separate from engineering success. No actual phone capability, safe human illumination, validated photorefraction or clinical performance is claimed here.

Known implementation limits: UI/basic controls only; no manual WB/focus protocol; no scientific duration limit; no session participant manager; no pose/time-sync measurement; no raw sensor capture; JPEG may have ISP/driver processing; no sealed signature; no test of camera-session callbacks/CameraX override behavior; disk callback logging can affect throughput; session logs accumulate until operator archival/app management and are not automatically deleted; interruption can leave unsealed exports; no live network transfer. All device-dependent conclusions await measurements.
