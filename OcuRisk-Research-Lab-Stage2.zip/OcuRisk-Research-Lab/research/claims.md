# Claims

Authoritative claim/evidence mapping: ../EVIDENCE_REGISTER.md. Actual software evidence is in ../TEST_REPORT.md. Literature results never become OcuRisk measurements. Independent verdict and unresolved scientific blockers are in verification/INDEPENDENT_VERIFICATION.md.
