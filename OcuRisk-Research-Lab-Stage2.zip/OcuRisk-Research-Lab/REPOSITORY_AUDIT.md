# Original OcuRisk audit — LAB-0001

Date: 2026-10-08. Verdict: **BLOCK scientific acceptance; retain as a software prototype and legacy comparator.** No original file was changed. Complete findings and function inventories are in `research/audits/CV_ACQUISITION_AUDIT.md`, `research/audits/RISK_BACKEND_AUDIT.md`, and `evidence/source_api_inventory.json`.

## Audit basis and coverage

The team read all three PDFs: v3.0 technical specification (29 pages, retrieved from the previously uploaded exact file), V2 Master Prompt, and independent Verifier Prompt; the pasted Research Lab directive; the user parallel directive; all application TypeScript/TSX files (24 files, 9,510 lines); both test files; README, run instructions, calibration/segmentation plans; all prior research registries and project documentation. Dependency manifests, configuration and packaged model/runtime assets were inventoried. Third-party dependency source, minified WASM internals and historic Git commits were not treated as authored application source or exhaustively reverse engineered. The ZIP contains 16,954 entries, 301,083,955 uncompressed bytes, largely bundled dependency and Git content. `evidence/original_inventory.json` records hashes for authored/project assets and the complete ZIP hash. No patient database or real reference dataset appears in the authored-file inventory. This is a code/docs audit, not a phone or clinical experiment.

Separate read-only audit agents inspected CV/acquisition and optics/risk/backend. Their reports precede new implementation. Prior `research/` notes inside the ZIP are **historical assertions**, not fresh test results: they incorrectly report React types absent although the current package includes them. The current type-check actually exposes the per-eye defects.

## Current architecture

Browser React 19/Vite/TypeScript executes MediaPipe/Canvas processing and all optical/risk math. `App.tsx` holds global patient/scan state. Six step components collect self-report, video/image metrics, calculate fusion, then show report/AI. Browser localStorage retains up to 20 sessions; Express mirrors full mutable scan JSON to SQLite via better-sqlite3. Express optionally forwards named patient context to Gemini (default provider) or local Ollama. Local bundled MediaPipe assets are available, but online `@latest` resources are tried first. There is no native Android capture component, ADB camera interface, immutable raw-capture registry, subject split or calibrated model artifact.

## Module and reuse inventory

| Existing feature / files | Inputs → actual outputs | Dependencies | Validation and defects | Lab disposition |
|---|---|---|---|---|
| `main.tsx`, `App.tsx`, `types.ts` | React state → routed scan, stored session | React | Default realistic values with demo false; types force numeric outputs where unavailable is needed; saved/restored/export identity differs | Reuse architectural lessons, rebuild missingness/provenance contracts |
| Welcome, Header, Wizard, disclaimer, History | User actions → navigation/history | React/Lucide | Presentation exists; disclaimer does not validate metrics; clearing browser history leaves SQLite | UI ideas only, explicit research state |
| Step 2 questionnaire | Named profile, habits, symptoms, prescription, acuity exercise → PatientProfile | React, power-vector utilities | Tumbling-E pixel sizing/distance uncalibrated; old prescription not independent current reference | Separate contextual risk variables from optical model; no clinical-reference inference |
| Step 3 acquisition | Webcam frames/manual NPC/lag → fixation/pupil histories, BCEA/events/fatigue | MediaPipe/Canvas/math | Positions are genuine image data but laterality/degree scale unverified; 41-point window, 10 Hz samples analysed at 30 Hz; default latency/velocity/fatigue | Image-space tracking primitives only after independent tests; clinical labels blocked |
| Step 4 acquisition | Live/image/sampled video → scalar optical estimate | Browser getUserMedia/Canvas | No LED control/metadata; CSS flash; pooled eye features; invalid per-eye reads; Next overwrites richer capture; video last frame only | Replace capture with native device-truth layer and frame-preserving replay |
| `eyeTracker.ts` landmarks | MediaPipe 478 landmarks → eye centers/rings/blink | Bundled model/WASM or CDN | Ring laterality inconsistent with upstream; fallback tier differs; unpinned online runtime | Reuse ROI concept/local assets only after side-labelled fixture and pin/hash |
| Dark pupil/Otsu/YCbCr | RGB/iris estimates → dark centroid/radius | Canvas | Uniform images can produce radius; eyelash/iris ambiguity; assumed radius can be labelled measured | Legacy detector candidate only; annotation baseline first |
| Red/crescent sampling | Fixed squares / pooled upper/lower brightness → red ratio, bounded contrast | Canvas | No spatial crescent segmentation/glint mask; minimum ratio .08 even uniform; red feature clipped .4–1 | Preserve exact TS and separately labelled adapted contrast comparator |
| Blur/EAR/One Euro | Pixel derivatives/landmarks → variance/EAR/smoothed positions | Pure TS | Descriptive metrics useful; valid-looking blur defaults; thresholds/FOV uncalibrated | Port narrowly scoped descriptive utilities with domain tests |
| Distance/iris ruler | Pixel geometry + fixed iris/focal constants → mm/cm | Pinhole approximation | Focal600px, iris11.7/11.0mm, IPD×.28; clipped distance marked confident | Unknown physical scale until independent measurement; no universal constants |
| `calculatePhotorefraction` | Scalar contrast + defaults100cm/12mm/K6 → rounded/clamped SE | opticsEngine | Mixed units/untraceable K, inconsistent ratio definition, fixed top/bottom sign, symmetric→0 | Quarantined `MODEL_0_PHYSICS_BASELINE`, uncalibrated; no default Lab diopter |
| Cylinder/axis | Manufactured scalar “slopes” → rotational astigmatism | opticsEngine | No independent meridian measurements; cannot support cylinder estimate | Preserve source only, unavailable in research outputs |
| CRADLE-style flag | Combined ratio/threshold history → abnormal flag | tracker/opticsEngine | Arbitrary proximity; no real whiteness mask; no reset; risk fusion invents frame counts/confidence | Do not claim CRADLE equivalence; descriptive anomalies require new validated target |
| BCEA/FFT/events/NPC | Position/pupil histories → heuristic scalar summaries | Pure math | BCEA area×2; padded FFT bins wrong; counted frames not events; simulated target distance | Reimplement mathematically; physical/clinical interpretation separately validated |
| Thibos conversion | Supplied S,C,axis ↔ M,J0,J45 | Pure math | Useful transform; tests only internal roundtrip, rounding/domain concerns | Reusable after independent expected cases; conversion does not validate image estimate |
| `calculateMultiModalRisk`, Step 5 | Hand-assigned points + shifts → risk index/Beta picture | Pure math | No defined/fitted likelihood or calibrated event; animation is not scientific processing | Legacy heuristic score only, separate from Bayesian risk research |
| Beta helper/curve | Score/pseudocounts → density/interval picture | Pure math | Display density quantized to all zero at midrisk; index differs from Beta mean; separate helper not active workflow | No probability claim; explicit prior/likelihood/outcome prerequisite |
| Li/Foo/trajectory, Step 6 | Toy coefficients/scalars → forecasts | Pure math/Recharts | Illustrative labels exist; negative probability possible; main intervention/progression plot unsupported | No longitudinal forecasts; archives only |
| Express API/SQLite | Full named session JSON → CRUD, LLM prompt | Express/better-sqlite3/Google SDK | Prepared queries/WAL useful; shallow validation, no auth, plaintext, zero truthiness bugs, rejected LLM text still returned | New local pseudonymous import DB; no cloud AI inherited |
| sampleData/terminology | BCEA→random scatter; medical terms→plain labels | Pure TS | Scatter is generated despite no demo comment; “Overall Prescription” wording for SE | No generated clinical data; annotate all test origins |
| Two test files | Fixtures → 12 optics + 2 SQLite tests | Vitest | Internal consistency; no hardware, clinical references, CV/UI/server or side-labelled tests | Historical tests not acceptance evidence for optical accuracy |
| Segmentation plan | Proposed U-Net/DeepLab + target metrics | Not implemented | No trained segmentation model or module in ZIP | NOT_IMPLEMENTED, not copied as an achieved feature |

Detailed audit tables include exact function/file lines, inputs, missingness, follow-up experiments and severity. `source_api_inventory.json` records every module export/declaration and hash. Original scientific calculations are preserved verbatim under `legacy/`; archival files are not the running Lab pipeline.

## Most consequential findings

1. **Per-eye optical independence is absent.** Top-level scalars are pooled; the per-eye objects contain only x/y/radius/brightness. OD/OS calculations read properties that are absent and fall back to the same combined values. Anisometropia computed from these cannot establish an inter-eye difference. Laterality also differs between MediaPipe and fallback tiers.
2. **Capture is not a verified LED photograph.** The default camera preference is `user`, though explicitly selected devices can differ. There is no torch/still-flash API. CSS overlay plus ×1.25 intensity multiplier is unrelated to observed LED state. A live reflex from some externally illuminated setup remains possible; the audit does not prove all such images lack reflex.
3. **Brightness contrast is not measured crescent height.** Uniform supplied pupil regions return a minimum .08 feature. No full pupil/glint/crescent mask or source meridian is measured.
4. **K6 and the shipped optical formula lack a verified derivation.** Reference metadata is inconsistent; mixed cm/mm and ratio width/diameter vs height/radius need resolution. Published photorefraction precedent cannot validate this numeric mapping.
5. **The production risk score is heuristic.** A Beta visualization is not Bayesian evidence updating. Future progression, cylinder and fabricated temporal “CRADLE” details exceed the data supplied.
6. **Missing values can become plausible results.** Zero truthiness, default .25 BCEA/1.5 Hz/5.5 mm/reflex .75, synthetic latency/velocity, stale uploads and anonymous-looking report fallback numbers undermine provenance.
7. **Timing and physical units are not established.** Render-loop FPS, manufactured monotonic frame timestamps, nominal sampling, head motion and assumed FOV cannot establish calibrated gaze/temporal metrics.
8. **Resilience is not equivalent measurement quality.** CV fallback can keep UI running while reducing/replacing information. Invalid data must abstain, not be quietly substituted.

## Reproducible execution and counterexamples

Original source was copied to `audit_run/EYE` for execution only; protected extracted inputs and original ZIP were untouched. Node24.19.0 / Python3.12.14 host.

| Command/check | Actual result | Scope |
|---|---|---|
| Original `node node_modules/typescript/bin/tsc --noEmit` | Exit2, **18 errors** | Current package types expose missing initial frame fields, absent per-eye optical fields and report typing defects |
| Original Vitest runner | Exit1 before tests | Missing Linux Rollup optional binary in Windows-packaged dependencies; not a scientific test failure or pass |
| Original Vite build | Exit1 before build | Same platform dependency failure; original app browser operation not newly verified |
| Copied CV bodies | Uniform supplied iris produces 7.92px pupil; gray .7 red ratio/.08 crescent; empty blur100 focused; no-flash ratio1 becomes temporal positive | Synthetic software counterexamples, not complete MediaPipe/camera test |
| Arithmetic reproduction | Beta midrisk all zero; 98% index→94.62% Beta mean; BCEA×2; padded FFT label×1.28; toy Li probability−10% | Python arithmetic of implementation expressions, not TypeScript clinical runtime |

Exact logs/scripts retained in `evidence/` and `research/audits/`. No prior registry “14/14 passed” result is presented as execution in this session. Full original test/build recovery requires fresh host-correct dependencies in an isolated copy; no original fixes are authorized or made.

## Documentation mapping and uncertainty

v3 pp14–18 describe independent OD/OS, crescent geometry and Bayesian fusion that the actual implementation does not establish. pp23–24 explicitly disclose no clinical validation and generic constants; that honest limitation is retained. v3 pp6–7/12 describe a Load Demo path; current Step1/sampleData do not provide that documented showcase dataset, although App still starts with realistic defaults. PDF reference list has been revised relative to repository Markdown, so both were read separately. A published-constant claim in calibration notes is not primary-source evidence. V2 requirements for every frame/four streams/masks/ground-truth splits/uncertainty are future capabilities, not implemented original features.

Reuse is therefore conditional and narrow. Scientific release and integration remain blocked until physical acquisition, segmentation and independently referenced participant-held-out evaluation pass. The complete best pipeline is **not yet known**.
