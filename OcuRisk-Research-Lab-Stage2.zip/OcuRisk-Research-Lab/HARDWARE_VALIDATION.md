# Hardware validation record

Target: CMF Phone 2 Pro connected by USB to the user's Windows PC. Current execution host: Linux, not that PC. No phone is accessible here. Actual Android/build, camera IDs, selected physical lens, exposure/ISO/AF/AWB behavior, LED state/output, lens-to-LED geometry, frame rates, clock source and transfer behavior are **UNKNOWN**.

| Component | Actual evidence | Status |
|---|---|---|
| Android CameraX/Camera2 probe and JPEG capture | Java source and XML inspection | IMPLEMENTED_UNTESTED; no SDK build or APK |
| Windows PowerShell ADB orchestration | Source inspection | IMPLEMENTED_UNTESTED; PowerShell/ADB absent here |
| Binary-safe Python export/checksum helper | Six synthetic byte-transfer tests on Linux | TESTED_ENGINEERING_ONLY |
| Real CMF acquisition, controls, timestamps | None | AWAITING_HARDWARE |
| Native video, pose, direct USB API upload | No implementation | NOT_IMPLEMENTED |
| Physical LED verification/optical safety | No CMF measurements or qualified approval | UNVERIFIED / HUMAN_REVIEW_REQUIRED |

Use research/HARDWARE_FEASIBILITY.md for H0–H7 gates and official API evidence. Use research/ANDROID_IMPLEMENTATION.md and android/README.md for equipped-host build commands and tools/windows/OcuRisk-Usb.ps1 for diagnostics. The script defaults to Devices; Diagnostic is read-only, Install requires an actual built APK and explicit serial. No nonexistent APK is included.

First human action: on the connected Windows PC, obtain Devices and Diagnostic output using the documented commands, with explicit serial if multiple devices appear. Inspect before sharing and remove personal identifiers; retain build/capability information and a pseudonymous device ID. Do not point illumination at an eye. The diagnostic step alone does not exercise our native camera component. Next build the separate package, then acquire an inert target with illumination OFF and verify export hashes.

Physical measurements awaiting the operator include selected optical-center-to-LED vector, working distance with method/uncertainty, actual source state and timing. IMU orientation is not translation or distance. Requested torch state, CameraInfo and capture-result flags do not certify physical illumination or safe retinal exposure. The best-effort timed torch shutoff is an engineering mechanism, not a safety limit.

Before participant illumination: configuration-specific qualified safety assessment and applicable research permission/consent, controlled fixation protocol and independent reference access. No human eye-illumination experiment has been performed or authorized by these software tests.
