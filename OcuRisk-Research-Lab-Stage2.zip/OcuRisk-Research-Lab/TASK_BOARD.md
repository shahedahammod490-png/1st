# Authoritative DroidCam task board

Application source commit `c618576`; prior source `aba5c5f` preserved. Original OcuRisk protected. No background execution is promised.

| Task | Actual state | Next action |
|---|---|---|
| Selected live feed/record/snapshot/save/upload | Implemented; lifecycle/mock tests pass | Actual Windows browser permission and DroidCam test |
| Automatic everyframe quality/timing/proxies | Implemented; analytic/encoded tests pass | Inspect real chart data and study-specific calibration |
| Dataset/jobs/sidecars/quality export/comparison | Integrated; actual local HTTP and tamper/regression tests pass | Export actual matched USB/WiFi recordings |
| Candidate maps/tracking/ranking | Existing pipeline plus everyframe quality and ranking; synthetic tests | Representative real pupil/reflex annotations, not chart-only inference |
| Scientific research/contract | Primary sources and limitations recorded | Geometry/reference design, repeatability/uncertainty review continues |
| Independent verification |135 Python+9 host+3 Node suites pass;51 source hashes stable | Browser/hardware gates separately remain open |
| Browser visual/interaction | BLOCKED here by failed Chromium install/missingbinary | Execute retained script on permitted host and inspect layouts |
| Physical USB/WiFi comparison | User says connection works; Lab hardware workflow unverified here | Follow DROIDCAM_WINDOWS_SETUP nonhuman checklist |
| Clinical/optical bestpipeline | No validatedresult/dataset or winner | Qualified safety/research/reference and locked evaluation gates |
| Checkpoint/recovery | Current source/docs/tests/history packaged | Read RESUME_HERE on continuation, preserve any newer work |

Closed findings: requested-camera metadata mismatch, capture-context race, duplicate-source comparison, incomplete-recording eligibility, historical export rejection and contradictory archive quality. Evidence in independent report. Initial failures and the concurrent-edit-invalidated run are preserved, not relabelled as success.

Next human action is local Windows setup and ordinary nonhuman chart testing with existing DroidCam; nativeAPK is optional. No illuminated human-eye request is made. Source-quality metrics cannot establish retinal-reflex specificity or clinical accuracy.
