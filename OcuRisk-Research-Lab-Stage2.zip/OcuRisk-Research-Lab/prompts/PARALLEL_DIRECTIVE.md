# OCURISK RESEARCH LAB — PARALLEL SUBAGENT EXECUTION DIRECTIVE

This directive supplements the OcuRisk Research Lab Master Directive and Engineering Directive.

The development environment supports subagent delegation. Use this capability actively when independent tasks can progress safely in parallel.

## 1. Orchestration

GPT-6 Astra acts as lead research architect and scientific orchestrator.

GPT-6.1 Sol acts as implementation and integration engineer.

Subagents may be assigned specialized tasks involving optical physics, Android acquisition, computer vision, machine learning, Bayesian modeling, statistical evaluation, backend development, UI development and testing.

Do not assume subagents have a specific model identity or capability unless the execution environment confirms it.

## 2. Parallel development

After a short initial repository audit and agreement on shared interfaces, execute independent research and engineering tasks simultaneously.

For example:

- Android acquisition development.
- Optical-literature investigation.
- Existing CV algorithm audit.
- Risk-model mathematics audit.
- Dataset architecture.
- Research dashboard implementation.
- Automated test infrastructure.

Do not unnecessarily serialize independent tasks.

However, respect scientific and engineering dependencies.

Do not claim refractive-prediction accuracy without appropriate independent reference measurements.

Do not conduct human eye-illumination experiments without required safety and research approvals.

## 3. Source-code isolation

Assign explicit ownership for each task and affected module.

Where supported, use separate Git branches or isolated worktrees for subagent changes.

Avoid concurrent edits to the same files.

Define shared interfaces before parallel implementation.

Use controlled merges, integration tests and regression tests.

Never allow subagents to modify the protected original OcuRisk project.

## 4. Subagent task contracts

Each subagent must receive:

- Specific objective.
- Relevant repository files.
- Scientific constraints.
- Expected deliverables.
- Acceptance criteria.
- Allowed files and directories.
- Dependencies.
- Testing requirements.
- Explicit prohibited actions.

Each subagent must report:

- What was completed.
- Files modified.
- Tests performed.
- Actual results.
- Evidence supporting conclusions.
- Unresolved issues.
- Integration requirements.

## 5. Integration

Sol coordinates engineering integration.

Astra reviews scientific assumptions and acceptance criteria.

Do not merge conflicting algorithm implementations without reviewing their assumptions, units, interfaces and test evidence.

Run automated tests after each integration.

Preserve previous working builds and reproducible experiment configurations.

## 6. Independent verification

Verification must remain independent of the implementation being audited.

A subagent must not approve its own consequential scientific claims.

Follow the supplied OcuRisk V2 Verifier Prompt.

Unresolved critical findings block scientific acceptance and integration into the original product.

## 7. Continuous progress tracking

Maintain one authoritative shared project status.

Record:

- Active agents and assignments.
- Current workstreams.
- Branch/worktree ownership.
- Completed deliverables.
- Pending merges.
- Tests and failures.
- Scientific blockers.
- Hardware experiments awaiting user action.
- Next tasks.

Update the status after significant task completion and before context or session termination.

## 8. Autonomous operation

Continue independent software and research tasks without requiring routine user approval.

Escalate only decisions that genuinely require human involvement, including physical hardware operation, participant recruitment, consent, clinical measurements, ethical approval and major changes to protected project scope.

Never fabricate results to bypass a blocked stage.

## 9. Final objective

Parallelism should reduce engineering time, not weaken scientific verification.

Build one unified independent Research Lab with modular algorithms, reproducible experiments and objective performance comparisons.

Integrate only independently verified changes, and do not modify the original OcuRisk without my explicit approval.
