# Stage2 source milestone — 2026-10-09 UTC

Integrated separate local Lab: actual image/video experiments, source-PTS processing and maps, method comparisons/manual revisions, model fitting/provenance, five-workspace interface, CameraX source and USB helpers. Application commit05d915c; final execution evidence b308e6d. 112 Python tests and 9 host-helper tests passed, including a separate independent run. See STAGE2_TEST_REPORT.md for evidence and limits.

Source package and full all-branch checkpoint preserve continued development. No APK, browser visual acceptance, Windows/CMF operation or clinical validation is claimed. No patient data or trained clinical model is shipped; original OcuRisk remains untouched. Do not interpret a source milestone as a completed validated product.

---

# LAB-0001 first-stage release

Separate source/docs/test archive, 2026-10-08. Local Git checkpoint only; no external repository, production deployment or original integration. All three supplied PDF copies and provenance are included for future continuation. Original ZIP and dependency/node_modules/Git tree are intentionally not duplicated; use the original ZIP with its recorded SHA for legacy baseline execution/protection checks.

Implemented: loopback image import/persistence, manual anatomical OD/OS annotation, candidate spatial features/artifacts, immutable exports, deterministic replay, descriptive metrics, Android still/probe source and Windows/USB helpers. Android has no built APK. No real optical or clinical results, participant dataset, calibrated/trained model, full video or verified phone connection exists. Browser interaction/Windows/native build remain unverified. Scientific pipeline BLOCK; scoped independent Linux foundation APPROVE.

Read README to run. Read PROJECT_STATUS and HANDOFF_SOL to continue. Source hashes in evidence/release_inventory.json identify archived files; input hashes and verifier source snapshot remain separately preserved. Human datasets/runtime DB/caches/build outputs are excluded from release. Test evidence is synthetic and its origin is explicit.

## DroidCam source milestone — 2026-10-10 Dhaka

Applicationc618576 adds liveOSDroidCam source, snapshots/recording/autosave/uploads, automatic allframe quality, graphs/ranking/rejectevidence, actualUSB/WiFi comparison, immutablemetadata/provenance and Windowssource launcher.135Python+9host+3Node independentfixture suitespass. Conditionalsoftwareacceptance only; browserinteraction blocked and physicalDroidCam/opticalclinical unverified. No APKrequired. Rootcheckpoint includes currentmain plusallolderownerbranches; sourcepackage hasno runtimeparticipantrecords.
