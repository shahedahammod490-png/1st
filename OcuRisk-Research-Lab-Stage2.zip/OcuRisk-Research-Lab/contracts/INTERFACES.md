# Shared interfaces v0.1

These interfaces are fixed for the first engineering iteration. The original EYE tree is protected. Root owns contracts and cross-module integration. Engineers own only their assigned files. Do not commit other agents' changes.

## Runtime decision
Python 3.11+ local PC backend, SQLite, NumPy + Pillow optical processing, static HTML/JS research dashboard served by the same loopback HTTP server. Native Android CameraX acquisition is a separate client. No cloud LLM, trained model, automatic clinical prediction, or hidden demo data. This avoids transplanting the original coupled scientific calculations. Windows is the target; Linux is the current test host. Runtime versions must be logged. Native dependencies are not available here; Android build/device testing stays explicit.

## Capture import API
`POST /api/captures` accepts JSON `{manifest: CaptureManifest, files: [{name: string, base64: string}]}`. Imported image bytes must match SHA256 in the manifest. Images PNG/JPEG only for this iteration; raw video and metadata storage remain planned. No filesystem path supplied by clients is trusted. Return `{capture_id}`. Duplicate capture IDs/hashes are rejected or flagged explicitly. Limit total request size.

CaptureManifest:
```
schema_version: "1.0"
capture_id, participant_id, session_id, device_id: non-empty ASCII IDs [A-Za-z0-9_-], <=80 characters
mode: CONTROL | VIDEO_RIGHT | VIDEO_LEFT | HEAD_TURN
data_origin: NON_HUMAN_TEST | SYNTHETIC | REAL_APPROVED
approval_reference: string | null (required for REAL_APPROVED)
illumination: {requested: OFF|FLASH|TORCH|UNKNOWN, reported: OFF|FLASH|TORCH|UNKNOWN, physical_verified: boolean, evidence_id: string|null}
distance_m: positive finite number | null
phone_pose, head_pose: object | null (unmeasured stays null)
mirrored: boolean | null
image_rotation_deg: 0|90|180|270 | null
timestamp_source: string
frames: [{frame_index: nonnegative integer, timestamp_ns: decimal string|null, source_file: basename PNG/JPEG, sha256: lowercase hex64, eyes: {OD: pupil|null, OS: pupil|null}}]
pupil: {cx_px: finite number, cy_px: finite number, radius_px: positive finite number, source: "MANUAL_ANNOTATION"}
```
Coordinates refer to DECODED stored image pixels: x right, y down; radius px. Eye ID is anatomical, explicitly assigned by annotator. No guess from video direction or image-side position. Rotation/mirroring metadata is recorded, not applied implicitly. Manual circle is an annotation, not automatic pupil detection or physical millimetre measurement. Both eyes remain present as keys, including missing values. All frames are retained; timestamps strictly increasing when known; no timestamp fabricated from a nominal FPS.

## CV API (Sol optical module ownership)
`ocurisk_lab.optical.analyze_frame(image_path: Path, eyes: dict, output_dir: Path, config: dict|None=None) -> dict`
Returns `{algorithm_id, algorithm_version, config, eyes: {OD: record, OS: record}}`. Each record contains `status`, `reasons`, `measurements` (numeric/null values with declared units), `artifacts` (relative PNG basenames), `prediction: null`, `uncertainty: null`. Missing eye => INCONCLUSIVE. Persist raw crop, normalized crop, pupil/glint/candidate masks, RD/RE/Y, gradient and polar representation. Algorithms are candidate image features; do not output diopters or disease labels. Global blur/clipping does not establish gradability. Input validation, no NaN JSON, deterministic replay required. Baseline old brightness contrast can be a separately named adapted comparator; it must not be represented as a faithful complete original pipeline. Verbatim legacy TS stored separately.

## Backend API (Sol service ownership)
`python -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir data`
`GET /api/health` actual service status, no device-connected claim.
`GET /api/captures` persisted manifests.
`GET /api/captures/{id}` actual manifest.
`GET /api/images/{capture_id}/{filename}` serves only manifest-whitelisted source image bytes.
`POST /api/captures/{id}/process` `{}` => runs imported frames through CV, persists immutable run/config/source hashes; returns run.
`GET /api/runs` / `GET /api/runs/{id}` actual results.
`GET /api/artifacts/{run_id}/{filename}` serves only whitelisted run artifact files.
`GET /api/export/{run_id}` exports actual result JSON.
`GET /api/status` explicit capability registry; advanced models NOT_IMPLEMENTED/AWAITING_REFERENCE_DATA. No fabricated measurements.
UI must import an image, ask for anatomical OD/OS manual circles, choose mode and origin, inspect resulting artifacts and quality side-by-side, retain missingness. UI-created captures default NON_HUMAN_TEST; never bypass human-study approval. Empty initial database.

## Ownership
Root: documentation, contracts, original hashing, integration and package.
Sol service: `ocurisk_lab/server.py`, `store.py`, `schema.py`, `web/`, `tests/test_service.py`, `tests/test_schema.py`.
Sol optical: `ocurisk_lab/optical.py`, `tests/test_optical.py`, `tools/replay.py`.
Sol Android: `android/`, `tools/windows/`, `research/ANDROID_IMPLEMENTATION.md`.
Verifier: `research/verification/`, `tests/test_independent_verification.py` only; independent read-only inspection of other modules.

## Required engineering acceptance
Unmodified original hashes; empty database; invalid input rejected; zero preserved; each frame/eye isolated; absent quantities null; raw import checksum verified; processing/DB roundtrip; deterministic replay; no public bind; unsafe paths rejected; no external inference. Synthetic examples only in tests and explicitly labelled. Passing tests is engineering evidence only. Phone, geometry, optics and clinical gates are separate.
