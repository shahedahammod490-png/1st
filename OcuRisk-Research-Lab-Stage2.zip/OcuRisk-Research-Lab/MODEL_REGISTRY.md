# Stage2 model registry

The empty shipped Lab contains no clinically trained model or invented performance. Runtime registry reflects actual saved versions, origins and dependency availability. Details: research/STAGE2_MODELS.md.

| Implementation | Status / scientific boundary |
|---|---|
| LINEAR, RIDGE, ELASTIC_NET, RANDOM_FOREST, GRADIENT_BOOSTING | Executable fitting, train-only preprocessing, grouped CV, held-out evaluation and safe stored inference; current exact tests in verification report |
| BAYESIAN_LOGIT | Explicit event/proper priors, checked MAP and Laplace Monte Carlo integration; one observation per participant, no calibrated disease-risk claim |
| Train-mean baseline | Computed only from supplied training targets |
| Legacy optical comparator | Exact archived scalar arithmetic with explicit inputs/clamps; UNCALIBRATED, clinical prediction null |
| M/J0/J45 conversion | Mathematical conversion of supplied reference values, not an image inference |
| CNN/HYBRID | Optional actual Python training/checkpoint/inference source; PyTorch absent in last verified host, execution unverified beyond dependency/schema checks |
| Calibrated physical model, temporal fusion, hierarchy, progression | Not scientifically established; unimplemented extensions must not advertise results |

SYNTHETIC, NON_HUMAN_TEST independent bench references and REAL_APPROVED independent clinical references remain separate origins. Their provenance is caller supplied, not independently authenticated. Immutable full training payload/config/reference/hash records preserve reproducibility. Trained does not mean validated. Complete-record error excludes acquisition failures; report those separately. Hidden reference proxies/near-duplicates/domain leakage still need independent review. No best model is selected.
