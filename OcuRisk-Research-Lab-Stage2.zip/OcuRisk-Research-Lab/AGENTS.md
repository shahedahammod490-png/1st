# Agent instructions for the independent Research Lab

Read PROJECT_STATUS, NEXT_STEPS, HANDOFF_SOL, contracts/INTERFACES, TEST_REPORT and independent verification before changing code. Read all three inputs/PDFs and supplemented prompts for full research requirements. Current source and measured results override historical implementation claims; user instructions take priority.

Never modify the original OcuRisk source/ZIP/configuration/database/history. Development is confined to this independent repository. No production integration, merge, migration or deployment is authorized without explicit user approval.

The lead scientific architect owns audit/research/experiments/architecture/acceptance/review. GPT-6.1 Sol is primary application/integration engineer where confirmed model delegation is supported. Use parallel specialized agents for independent work, with specific task contracts, module ownership, dependencies, tests and prohibited actions. Use disjoint files or isolated worktrees; avoid concurrent edits/commits. Do not assume a model identity that the environment does not confirm. If direct Sol delegation is unavailable, maintain the detailed handoff instead of duplicating primary coding.

Builders do not approve their own consequential scientific claims. Independent verification follows prompts/VERIFIER_INDEPENDENT.md and the supplied verifier PDF. Critical findings block affected acceptance; passing synthetic tests does not establish camera feasibility, optical accuracy, illumination safety, model calibration or clinical performance.

Retain raw hashes, source/config/runtime versions, immutable runs, origin, units, missingness and failure reasons. Never substitute invented measurements, coefficients, references, data, accuracy or confidence. Manual annotations are not physical measurements. Human collection/eye illumination requires appropriate qualified safety/research approval and consent; clinical references require qualified human measurements. Routine reversible software/research work can proceed autonomously.

Keep PROJECT_STATUS authoritative. Update experiment/evidence/model/dataset registries, decisions, change log, tests/failures and next tasks after meaningful completion and before stopping. Preserve reproducible prior checkpoints, controlled integration and regression evidence. See prompts/PARALLEL_DIRECTIVE.md for the complete parallel instruction included in both master prompts.
