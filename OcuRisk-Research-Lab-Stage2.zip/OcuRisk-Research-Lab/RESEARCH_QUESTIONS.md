# Research questions and falsification conditions

LAB-0001, 2026-10-08. None of the optical or clinical hypotheses below has been answered by a CMF acquisition. Software tests are recorded separately in TEST_REPORT.

| ID | Question | Evidence needed | Result that rejects or restricts the claim |
|---|---|---|---|
| RQ01 | Can the selected CMF camera acquire stable, traceable nonhuman media with useful controls? | Native build, camera-ID inventory, request/result logs, sensor timestamps, real transfer checksums | Unavailable controls, unidentified lens switching, unstable exposure or untraceable frame identity |
| RQ02 | Does the measured LED-camera-eye arrangement produce useful photorefractive structure? | Configuration-specific safety review, model-eye/approved reference experiments, independent geometry and source observations | Only corneal glare, absent/repeatedly saturated signal, nonrepeatable structure |
| RQ03 | Which pupil/glint/crescent method identifies the intended structures? | Independently annotated representative images, blinded mask review, false positives and boundary errors | Detector follows eyelids/glints rather than pupil/reflex; unacceptable failure coverage |
| RQ04 | Are static, lateral/yaw, physical roll and head-turn acquisitions different in useful information? | Matched geometry/fixation/exposure, randomized order, repeats, all four direction/eye streams | Improvement disappears after exposure/gaze controls, or increased failures outweigh benefit |
| RQ05 | Is any feature-to-refraction relation identifiable and calibrated? | Traceable optical derivation, measured pupil/geometry, bounded working range, independent refraction | Same feature maps to materially different refractions; calibration/domain instability |
| RQ06 | Does ML improve a simpler baseline on unseen participants? | Train-only preprocessing, grouped selection, frozen paired test, coverage and error intervals | Gains vanish on independent subjects/devices, leakage or unacceptable abstention |
| RQ07 | Can screening remain useful when continuous refraction is inadequate? | Prespecified referral outcome, threshold, reference adjudication, sensitivity/specificity/calibration | Clinical lower/upper performance bounds fail despite appealing average accuracy |
| RQ08 | Can a probabilistic risk model add value beyond optical screening? | Explicit event/horizon, independently labelled outcomes, logistic/Bayesian comparisons | Miscalibration, context leakage, correlated predictor double counting or no incremental utility |
| RQ09 | Can future progression be predicted? | Longitudinal measured refraction/axial-length outcomes, follow-up and intervention accounting | No longitudinal data; cross-sectional risk cannot answer this question |

No acquisition preference, universal optical constant, optimal algorithm or winning pipeline is selected. See EXPERIMENT_REGISTRY, research/OPTICAL_RESEARCH and research/BAYESIAN_RESEARCH for executable handoff requirements.
