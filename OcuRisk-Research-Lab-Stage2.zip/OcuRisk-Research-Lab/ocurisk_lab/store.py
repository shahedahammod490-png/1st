"""Transactional image import and immutable local processing runs."""
import base64
import hashlib
import io
import inspect
import json
import os
from pathlib import Path
import platform
import shutil
import sqlite3
import tempfile
import uuid
import warnings
from contextlib import contextmanager

from PIL import Image, __version__ as pillow_version

from .schema import ValidationError, fields, finite_tree, require, valid_id, validate_manifest

MAX_IMAGE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 24 * 1024 * 1024
MAX_PIXELS = 40_000_000


def json_text(value):
    finite_tree(value)
    return json.dumps(value, allow_nan=False, separators=(',', ':'), sort_keys=True)


def runtime_versions():
    import numpy
    return {'python': platform.python_version(), 'platform': platform.platform(), 'numpy': numpy.__version__, 'pillow': pillow_version}


def source_snapshot(analyzer):
    """Snapshot files plus executable optical code; reject edited cached modules."""
    package = Path(__file__).parent
    hashes = {f'ocurisk_lab/{name}': hashlib.sha256((package / name).read_bytes()).hexdigest() for name in ('optical.py', 'store.py', 'schema.py', 'server.py')}
    module = inspect.getmodule(analyzer)
    injected = analyzer.__module__ != 'ocurisk_lab.optical'
    code_hashes = {}
    if not injected:
        require(getattr(module, 'SOURCE_SHA256_AT_IMPORT', None) == hashes['ocurisk_lab/optical.py'], 'Optical source changed after import; restart service before processing')
        compiled = compile((package / 'optical.py').read_bytes(), str(package / 'optical.py'), 'exec')
        compiled_functions = {code.co_name: code for code in compiled.co_consts if inspect.iscode(code)}
        for name, function in vars(module).items():
            if inspect.isfunction(function) and function.__module__ == module.__name__:
                require(function.__code__ == compiled_functions.get(name), 'Optical source changed after import; restart service before processing')
                code_hashes[name] = code_fingerprint(function.__code__)
    else:
        code_hashes['injected_analyzer'] = code_fingerprint(analyzer.__code__)
    return hashes, {'injected_test_boundary': injected, 'executable_function_hashes': code_hashes}


def code_fingerprint(code):
    # marshal's reference flags depend on string interning at runtime. Serialize
    # code structure explicitly so replay hashes remain stable after execution.
    def constant(value):
        if inspect.iscode(value):
            return {'code': describe(value)}
        if isinstance(value, (tuple, frozenset)):
            items = [constant(item) for item in value]
            return {'type': type(value).__name__, 'items': sorted(items, key=repr) if isinstance(value, frozenset) else items}
        if isinstance(value, bytes):
            return {'bytes': value.hex()}
        return {'type': type(value).__name__, 'repr': repr(value)}
    def describe(value):
        return {'bytecode': value.co_code.hex(), 'constants': [constant(item) for item in value.co_consts], 'names': value.co_names, 'varnames': value.co_varnames, 'freevars': value.co_freevars, 'cellvars': value.co_cellvars, 'flags': value.co_flags, 'argcount': value.co_argcount, 'posonlyargcount': value.co_posonlyargcount, 'kwonlyargcount': value.co_kwonlyargcount, 'exceptiontable': getattr(value, 'co_exceptiontable', b'').hex()}
    return hashlib.sha256(json.dumps(describe(code), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


class Store:
    def __init__(self, data_dir, analyzer=None):
        self.root = Path(data_dir).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.captures_dir = self.root / 'captures'
        self.runs_dir = self.root / 'runs'
        self.captures_dir.mkdir(exist_ok=True)
        self.runs_dir.mkdir(exist_ok=True)
        self.db = self.root / 'lab.sqlite3'
        self.analyzer = analyzer
        with self.connect() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS captures(id TEXT PRIMARY KEY, manifest TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS frames(capture_id TEXT NOT NULL REFERENCES captures(id), name TEXT NOT NULL, sha256 TEXT NOT NULL UNIQUE, PRIMARY KEY(capture_id,name));
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, capture_id TEXT NOT NULL REFERENCES captures(id), result TEXT NOT NULL);
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.db, timeout=30)
        try:
            db.execute('PRAGMA foreign_keys=ON')
            with db:
                yield db
        finally:
            db.close()

    def captures(self):
        with self.connect() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT manifest FROM captures ORDER BY rowid')]

    def capture(self, capture_id):
        require(valid_id(capture_id), 'Invalid capture ID')
        with self.connect() as db:
            row = db.execute('SELECT manifest FROM captures WHERE id=?', (capture_id,)).fetchone()
        if row is None:
            raise KeyError('Capture not found')
        return json.loads(row[0])

    def import_capture(self, payload):
        fields(payload, 'manifest files', 'import')
        manifest = validate_manifest(payload['manifest'])
        files = payload['files']
        require(isinstance(files, list) and len(files) == len(manifest['frames']), 'Supply exactly one file per frame')
        expected = {frame['source_file']: frame for frame in manifest['frames']}
        decoded, total = {}, 0
        for entry in files:
            fields(entry, 'name base64', 'file')
            name, encoded = entry['name'], entry['base64']
            require(isinstance(name, str) and name in expected and name not in decoded, 'Unexpected or duplicate file')
            require(isinstance(encoded, str) and len(encoded) <= (MAX_IMAGE_BYTES + 2) // 3 * 4, 'Image exceeds size limit')
            try:
                raw = base64.b64decode(encoded, validate=True)
            except (ValueError, TypeError) as exc:
                raise ValidationError('Invalid base64 image') from exc
            total += len(raw)
            require(0 < len(raw) <= MAX_IMAGE_BYTES and total <= MAX_TOTAL_BYTES, 'Image data exceeds size limit')
            require(hashlib.sha256(raw).hexdigest() == expected[name]['sha256'], 'Image SHA256 mismatch')
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter('error', Image.DecompressionBombWarning)
                    with Image.open(io.BytesIO(raw)) as img:
                        require(img.format in ('PNG', 'JPEG'), 'Decoded image must be PNG/JPEG')
                        require((img.format == 'PNG') == name.lower().endswith('.png'), 'Image format differs from extension')
                        require(img.width * img.height <= MAX_PIXELS, 'Decoded image exceeds pixel limit')
                        require(getattr(img, 'n_frames', 1) == 1, 'Animated images are unsupported')
                        img.load()
                        require('A' not in img.getbands() and 'transparency' not in img.info, 'Alpha-bearing images are unsupported, including fully opaque alpha')
                        for pupil in expected[name]['eyes'].values():
                            if pupil is not None:
                                require(0 <= pupil['cx_px'] < img.width and 0 <= pupil['cy_px'] < img.height, 'Circle center lies outside decoded image')
                                require(pupil['radius_px'] <= max(img.width, img.height), 'Circle radius exceeds image dimensions')
            except ValidationError:
                raise
            except Exception as exc:
                raise ValidationError('Image cannot be safely decoded') from exc
            decoded[name] = raw
        capture_id = manifest['capture_id']
        destination = self.captures_dir / capture_id
        staging = Path(tempfile.mkdtemp(prefix='import-', dir=self.root))
        moved = False
        try:
            for name, raw in decoded.items():
                (staging / name).write_bytes(raw)
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                require(not destination.exists(), 'Capture ID already exists')
                db.execute('INSERT INTO captures VALUES (?,?)', (capture_id, json_text(manifest)))
                for frame in manifest['frames']:
                    db.execute('INSERT INTO frames VALUES (?,?,?)', (capture_id, frame['source_file'], frame['sha256']))
                os.rename(staging, destination)
                moved = True
            return {'capture_id': capture_id}
        except sqlite3.IntegrityError as exc:
            raise ValidationError('Duplicate capture ID or image SHA256') from exc
        except Exception:
            if moved:
                shutil.rmtree(destination, ignore_errors=True)
            raise
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def image_path(self, capture_id, filename):
        manifest = self.capture(capture_id)
        require(filename in {frame['source_file'] for frame in manifest['frames']}, 'Unknown image filename')
        return self._safe_file(self.captures_dir / capture_id, filename)

    @staticmethod
    def _safe_file(directory, filename):
        require(isinstance(filename, str) and Path(filename).name == filename and filename not in ('.', '..') and '\\' not in filename, 'Unsafe filename')
        path = directory / filename
        require(not path.is_symlink() and path.resolve().parent == directory.resolve(), 'Unsafe file path')
        if not path.is_file():
            raise KeyError('File not found')
        return path

    def process(self, capture_id):
        manifest = self.capture(capture_id)
        analyzer = self.analyzer
        if analyzer is None:
            from .optical import analyze_frame
            analyzer = analyze_frame
        source_hashes, execution_fingerprint = source_snapshot(analyzer)
        run_id = uuid.uuid4().hex
        staging = Path(tempfile.mkdtemp(prefix='process-', dir=self.root))
        destination = self.runs_dir / run_id
        moved = False
        try:
            results, whitelist = [], []
            for frame in manifest['frames']:
                source_path = self.image_path(capture_id, frame['source_file'])
                require(hashlib.sha256(source_path.read_bytes()).hexdigest() == frame['sha256'], 'Stored image SHA256 mismatch')
                frame_dir = staging / f"frame_{frame['frame_index']}"
                frame_dir.mkdir()
                result = analyzer(source_path, frame['eyes'], frame_dir, config=None)
                require(isinstance(result, dict) and isinstance(result.get('eyes'), dict) and set(result['eyes']) == {'OD', 'OS'}, 'Invalid optical result')
                finite_tree(result)
                for eye, record in result['eyes'].items():
                    require(isinstance(record, dict) and record.get('prediction') is None and record.get('uncertainty') is None, 'Clinical outputs must remain null')
                    artifacts = record.get('artifacts')
                    require(isinstance(artifacts, dict), 'Optical artifacts must be a mapping')
                    for label, basename in list(artifacts.items()):
                        path = self._safe_file(frame_dir, basename)
                        require(path.suffix.lower() == '.png', 'Artifacts must be PNG')
                        with Image.open(path) as artifact:
                            require(artifact.format == 'PNG', 'Artifact is not PNG')
                            artifact.verify()
                        new_name = f"f{frame['frame_index']}__{basename}"
                        target = staging / new_name
                        if new_name not in whitelist:
                            shutil.copyfile(path, target)
                            whitelist.append(new_name)
                        artifacts[label] = new_name
                shutil.rmtree(frame_dir)
                results.append({'frame_index': frame['frame_index'], 'timestamp_ns': frame['timestamp_ns'], 'source_file': frame['source_file'], 'sha256': frame['sha256'], 'analysis': result})
            require(source_snapshot(analyzer) == (source_hashes, execution_fingerprint), 'Processing source changed during run; retry after restarting service')
            run = {'run_id': run_id, 'capture_id': capture_id, 'manifest': manifest, 'runtime_versions': runtime_versions(), 'source_hashes': source_hashes, 'execution_fingerprint': execution_fingerprint, 'frames': results, 'artifact_files': whitelist, 'prediction': None, 'uncertainty': None}
            serialized = json_text(run)
            (staging / 'result.json').write_text(serialized, encoding='utf-8')
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('INSERT INTO runs VALUES (?,?,?)', (run_id, capture_id, serialized))
                os.rename(staging, destination)
                moved = True
            return run
        except Exception:
            if moved:
                shutil.rmtree(destination, ignore_errors=True)
            raise
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def runs(self):
        with self.connect() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT result FROM runs ORDER BY rowid')]

    def run(self, run_id):
        require(valid_id(run_id), 'Invalid run ID')
        with self.connect() as db:
            row = db.execute('SELECT result FROM runs WHERE id=?', (run_id,)).fetchone()
        if row is None:
            raise KeyError('Run not found')
        return json.loads(row[0])

    def artifact_path(self, run_id, filename):
        require(filename in self.run(run_id)['artifact_files'], 'Artifact is not whitelisted')
        return self._safe_file(self.runs_dir / run_id, filename)
