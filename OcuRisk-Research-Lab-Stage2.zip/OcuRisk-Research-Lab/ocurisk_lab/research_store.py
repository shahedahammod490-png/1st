"""Additive research records, immutable sources and append-only human revisions."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from .schema import require, fields, finite_tree, valid_id, number
from .store import Store, runtime_versions

MAX_MEDIA_BYTES = 256 * 1024 * 1024

def finite_json(value, depth=0):
    require(depth <= 32, 'JSON nesting exceeds limit')
    if value is None or type(value) is bool:
        return
    if type(value) in (int, float):
        require(number(value), 'Numbers must be finite')
    elif isinstance(value, str):
        require(len(value) <= 65536, 'String exceeds limit')
    elif isinstance(value, list):
        require(len(value) <= 100000, 'List exceeds limit')
        for item in value: finite_json(item, depth + 1)
    elif isinstance(value, dict):
        require(len(value) <= 10000, 'Object exceeds limit')
        for key, item in value.items():
            require(isinstance(key, str), 'JSON keys must be strings')
            finite_json(item, depth + 1)
    else:
        require(False, 'Value is not JSON serializable')

def json_text(value):
    finite_json(value)
    return json.dumps(value, allow_nan=False, separators=(',', ':'), sort_keys=True)

def now():
    return datetime.now(timezone.utc).isoformat()

def text(value, name, nullable=False):
    require(nullable and value is None or isinstance(value, str) and 0 < len(value.strip()) <= 4096, f'Invalid {name}')

def basename(value):
    require(isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9_-][A-Za-z0-9_.-]{0,119}', value) is not None and value not in ('.', '..'), 'Unsafe filename')
    return value

class ResearchStore(Store):
    def __init__(self, root, analyzer=None):
        super().__init__(root, analyzer)
        self.media_dir = self.root / 'media'
        self.jobs_dir = self.root / 'jobs'
        self.media_dir.mkdir(exist_ok=True)
        self.jobs_dir.mkdir(exist_ok=True)
        with self.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS research_records(kind TEXT NOT NULL,id TEXT PRIMARY KEY,parent TEXT,body TEXT NOT NULL); CREATE INDEX IF NOT EXISTS research_parent ON research_records(kind,parent);''')

    def put(self, kind, record, parent=None):
        identifier = record[f'{kind}_id']
        with self.connect() as db:
            db.execute('INSERT INTO research_records VALUES(?,?,?,?)', (kind, identifier, parent, json_text(record)))
        return record

    def get(self, kind, identifier):
        require(valid_id(identifier), 'Invalid record ID')
        with self.connect() as db:
            row = db.execute('SELECT body FROM research_records WHERE kind=? AND id=?', (kind, identifier)).fetchone()
        if row is None:
            raise KeyError(identifier)
        return json.loads(row[0])

    def records(self, kind, parent=None):
        with self.connect() as db:
            sql = 'SELECT body FROM research_records WHERE kind=?'
            args = [kind]
            if parent is not None:
                sql += ' AND parent=?'
                args.append(parent)
            return [json.loads(row[0]) for row in db.execute(sql + ' ORDER BY rowid', args)]

    def create_experiment(self, payload):
        finite_json(payload)
        fields(payload, 'title participant_id session_id mode data_origin approval_reference notes', 'experiment')
        for key in ('title', 'notes'):
            require(isinstance(payload[key], str), f'{key} must be text')
        text(payload['title'], 'title')
        for key in ('participant_id', 'session_id'):
            require(valid_id(payload[key]), f'Invalid {key}')
        require(payload['mode'] in ('STATIC', 'MULTI_VIEW', 'HEAD_TURN'), 'Invalid mode')
        require(payload['data_origin'] in ('NON_HUMAN_TEST', 'SYNTHETIC', 'REAL_APPROVED'), 'Invalid origin')
        text(payload['approval_reference'], 'approval_reference', True)
        require(payload['data_origin'] != 'REAL_APPROVED' or payload['approval_reference'] is not None, 'Approval reference required')
        return self.put('experiment', dict(payload, experiment_id=uuid.uuid4().hex, created_at=now()))

    def experiment(self, identifier):
        record = self.get('experiment', identifier)
        record['media'] = self.records('media', identifier)
        record['references'] = self.records('reference', identifier)
        ids = {x['media_id'] for x in record['media']}
        record['jobs'] = [x for x in self.records('job') if x['media_id'] in ids]
        return record

    def import_media(self, experiment_id, filename, raw, direction, mirrored):
        self.get('experiment', experiment_id)
        basename(filename)
        require(direction in ('STATIC', 'RIGHT', 'LEFT', 'HEAD_TURN'), 'Invalid media direction')
        require(mirrored is None or type(mirrored) is bool, 'Invalid mirrored value')
        require(0 < len(raw) <= MAX_MEDIA_BYTES, 'Media exceeds size bound')
        identifier = uuid.uuid4().hex
        destination = self.media_dir / identifier
        staging = Path(tempfile.mkdtemp(prefix='media-', dir=self.root))
        moved = False
        try:
            source = staging / filename
            source.write_bytes(raw)
            from .video import probe_media
            metadata = probe_media(source)
            finite_json(metadata)
            require(metadata.get('kind') in ('IMAGE', 'VIDEO'), 'Unsupported media')
            digest = hashlib.sha256(raw).hexdigest()
            duplicates = [x['media_id'] for x in self.records('media') if x['sha256'] == digest]
            record = dict(media_id=identifier, experiment_id=experiment_id, filename=filename, kind=metadata['kind'], direction=direction, mirrored=mirrored, sha256=digest, size_bytes=len(raw), metadata=metadata, created_at=now(), duplicate_of=duplicates)
            os.rename(staging, destination)
            moved = True
            return self.put('media', record, experiment_id)
        except Exception:
            if moved:
                shutil.rmtree(destination, ignore_errors=True)
            raise
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def sidecar(self, identifier, filename, raw):
        self.get('media', identifier)
        basename(filename)
        require(filename.lower().endswith('.json') and len(raw) <= 4 * 1024 * 1024, 'Sidecar must be bounded JSON')
        from .server import strict_json
        value = strict_json(raw)
        finite_tree(value)
        if filename == "capture-quality.json":
            from .quality import validate_capture_metadata
            validated = validate_capture_metadata(value)
            roi = validated.get('chart_roi')
            media = self.get('media', identifier)
            if roi is not None:
                require(roi['x'] + roi['width'] <= media['metadata']['width'] and roi['y'] + roi['height'] <= media['metadata']['height'], 'Chart ROI outside source dimensions')
        directory = self.media_dir / identifier / 'sidecars'
        directory.mkdir(exist_ok=True)
        path = directory / filename
        require(not path.exists(), 'Sidecar filename already exists')
        digest = hashlib.sha256(raw).hexdigest()
        with path.open('xb') as stream:
            stream.write(raw)
        try:
            return self.put('sidecar', {'sidecar_id': uuid.uuid4().hex, 'media_id': identifier, 'filename': filename, 'sha256': digest, 'size_bytes': len(raw), 'created_at': now()}, identifier)
        except Exception:
            path.unlink()
            raise

    def media(self, identifier):
        record = self.get('media', identifier)
        for key, kind in (('annotations', 'annotation'), ('reviews', 'review'), ('jobs', 'job'), ('sidecars', 'sidecar')):
            record[key] = self.records(kind, identifier)
        return record

    def original(self, identifier):
        media = self.get('media', identifier)
        path = self._safe_file(self.media_dir / identifier, media['filename'])
        require(hashlib.sha256(path.read_bytes()).hexdigest() == media['sha256'], 'Original source checksum changed')
        return path

    def frame_index(self, media, index):
        require(type(index) is int and index >= 0, 'Invalid frame_index')
        count = media['metadata'].get('frame_count')
        require(type(count) is int and index < count, 'Frame does not exist in probed source')

    def eyes(self, media, eyes):
        fields(eyes, 'OD OS', 'eyes')
        for circle in eyes.values():
            if circle is None:
                continue
            fields(circle, 'cx_px cy_px radius_px source', 'circle')
            require(number(circle['cx_px']) and number(circle['cy_px']) and number(circle['radius_px'], True), 'Invalid circle')
            require(circle['source'] == 'MANUAL_ANNOTATION', 'Invalid annotation source')
            width, height = media['metadata']['width'], media['metadata']['height']
            require(0 <= circle['cx_px'] < width and 0 <= circle['cy_px'] < height and circle['radius_px'] <= max(width, height), 'Circle outside source dimensions')

    def annotate(self, identifier, payload):
        finite_json(payload)
        fields(payload, 'frame_index eyes comment', 'annotation')
        media = self.get('media', identifier)
        self.frame_index(media, payload['frame_index'])
        self.eyes(media, payload['eyes'])
        require(isinstance(payload['comment'], str), 'Comment must be text')
        return self.put('annotation', dict(payload, annotation_id=uuid.uuid4().hex, media_id=identifier, created_at=now()), identifier)

    def review(self, identifier, payload):
        finite_json(payload)
        fields(payload, 'reviewer_id frame_index eye label comment blinded', 'review')
        media = self.get('media', identifier)
        text(payload['reviewer_id'], 'reviewer_id')
        if payload['frame_index'] is not None:
            self.frame_index(media, payload['frame_index'])
        require(payload['eye'] in ('OD', 'OS', 'BOTH'), 'Invalid eye')
        require(payload['label'] in ('VERIFIED_REFLEX', 'UNCERTAIN', 'NOT_DETECTED', 'UNINTERPRETABLE'), 'Invalid review label')
        require(isinstance(payload['comment'], str) and type(payload['blinded']) is bool, 'Invalid review metadata')
        return self.put('review', dict(payload, review_id=uuid.uuid4().hex, media_id=identifier, created_at=now(), blinding_status='CALLER_ASSERTION' if payload['blinded'] else 'NOT_BLINDED'), identifier)

    def reference(self, identifier, payload):
        finite_json(payload)
        fields(payload, 'eye method measured_at sphere_d cylinder_d axis_deg cycloplegic examiner_id notes', 'reference')
        self.get('experiment', identifier)
        require(payload['eye'] in ('OD', 'OS'), 'Invalid eye')
        for key in ('method', 'examiner_id', 'measured_at'):
            text(payload[key], key)
        try:
            stamp = datetime.fromisoformat(payload['measured_at'].replace('Z', '+00:00'))
            require(stamp.tzinfo is not None, 'Reference timestamp requires timezone')
        except ValueError:
            require(False, 'Invalid measured_at timestamp')
        for key in ('sphere_d', 'cylinder_d', 'axis_deg'):
            require(payload[key] is None or number(payload[key]), f'Invalid {key}')
        require(payload['sphere_d'] is not None or payload['cylinder_d'] is not None, 'At least one refractive measurement required')
        require(payload['axis_deg'] is None or 0 <= payload['axis_deg'] <= 180, 'Axis must be 0..180')
        require(payload['cycloplegic'] is None or type(payload['cycloplegic']) is bool, 'Invalid cycloplegic')
        require(isinstance(payload['notes'], str), 'Notes must be text')
        return self.put('reference', dict(payload, reference_id=uuid.uuid4().hex, experiment_id=identifier, created_at=now(), verification_status='CALLER_SUPPLIED_UNVERIFIED', units={'sphere_d':'diopter','cylinder_d':'diopter','axis_deg':'degree'}), identifier)

    def process_options(self, identifier, payload):
        finite_json(payload)
        required = {'sample_every', 'algorithms', 'identity_confirmed', 'upright_confirmed', 'annotations'}
        require(isinstance(payload, dict) and required <= set(payload) and set(payload) <= required | {'capture_metadata', 'quality_config'}, 'Invalid process options fields')
        require(type(payload['sample_every']) is int and 1 <= payload['sample_every'] <= 1000, 'Invalid sampling interval')
        require(type(payload['identity_confirmed']) is bool and type(payload['upright_confirmed']) is bool, 'Identity/orientation confirmation must be boolean')
        from .optical_compare import registry
        allowed = {x['algorithm_id'] for x in registry()}
        require(isinstance(payload['algorithms'], list) and 1 <= len(payload['algorithms']) <= len(allowed) and all(isinstance(x, str) for x in payload['algorithms']) and len(set(payload['algorithms'])) == len(payload['algorithms']) and all(x in allowed for x in payload['algorithms']), 'Invalid algorithms')
        media = self.get('media', identifier)
        annotations = {str(x['frame_index']): x['eyes'] for x in self.records('annotation', identifier)}
        require(isinstance(payload['annotations'], dict), 'Invalid annotations')
        for key, eyes in payload['annotations'].items():
            require(isinstance(key, str) and re.fullmatch(r'0|[1-9][0-9]*', key) is not None, 'Frame indices must be canonical decimal strings')
            self.frame_index(media, int(key))
            self.eyes(media, eyes)
            annotations[key] = eyes
        from .quality import validate_capture_metadata, validate_config
        config = validate_config(payload.get('quality_config'))
        capture = self.capture_metadata(identifier)
        if 'capture_metadata' in payload:
            supplied = validate_capture_metadata(payload['capture_metadata'])
            if capture is not None:
                require(supplied == capture, 'Capture metadata differs from immutable sidecar')
            elif supplied is not None:
                self.sidecar(identifier, 'capture-quality.json', json_text(supplied).encode('utf-8'))
                capture = supplied
        roi = (capture or {}).get('chart_roi')
        if roi is not None:
            require(roi['x'] + roi['width'] <= media['metadata']['width'] and roi['y'] + roi['height'] <= media['metadata']['height'], 'Chart ROI outside source dimensions')
        return dict(payload, annotations=annotations, capture_metadata=capture, quality_config=config, capture_sidecar_snapshot=self.records('sidecar', identifier))

    def capture_metadata(self, identifier):
        from .server import strict_json
        from .quality import validate_capture_metadata
        capture = None
        for item in self.records('sidecar', identifier):
            path = self._safe_file(self.media_dir / identifier / 'sidecars', item['filename'])
            require(hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], 'Sidecar checksum changed')
            if item['filename'] == 'capture-quality.json':
                capture = validate_capture_metadata(strict_json(path.read_bytes()))
        return capture

    def verify_job_inputs(self, job):
        self.original(job['media_id'])
        snapshot = job.get('options', {}).get('capture_sidecar_snapshot')
        if snapshot is not None:
            require(snapshot == self.records('sidecar', job['media_id']), 'Sidecar set changed after job snapshot; process a new job')
            self.capture_metadata(job['media_id'])

    def checked_job(self, identifier):
        job = self.get('job', identifier)
        if job.get('state') == 'COMPLETED' and job.get('result', {}).get('acquisition_quality') is not None:
            self.verify_job_inputs(job)
            for name in job['result'].get('artifact_files', []): self.artifact(identifier, name)
            report = json.loads(self.artifact(identifier, 'acquisition-quality.json').read_text(encoding='utf-8'))
            require(report == {key: job['result'].get(key) for key in ('acquisition_quality', 'capture_metadata', 'media_metadata')}, 'Quality result differs from immutable artifact')
        return job

    def quality_comparison(self, payload):
        require(isinstance(payload, dict) and set(payload) == {'job_ids'}, 'Expected job_ids')
        ids = payload['job_ids']
        require(isinstance(ids, list) and 2 <= len(ids) <= 20 and all(isinstance(x, str) and valid_id(x) for x in ids) and len(set(ids)) == len(ids), 'job_ids must contain 2..20 distinct valid IDs')
        from .quality import compare_recordings
        recordings = []
        for identifier in ids:
            job = self.get('job', identifier)
            require(job['state'] == 'COMPLETED', 'Comparison requires completed jobs')
            self.verify_job_inputs(job)
            result = job.get('result') or {}
            require(isinstance(result.get('acquisition_quality'), dict), 'Job has no acquisition-quality result; reprocess source')
            for filename in result.get('artifact_files', []):
                self.artifact(identifier, filename)
            report = json.loads(self.artifact(identifier, 'acquisition-quality.json').read_text(encoding='utf-8'))
            require(report == {'acquisition_quality': result['acquisition_quality'], 'capture_metadata': result.get('capture_metadata'), 'media_metadata': result.get('media_metadata')}, 'Quality result differs from immutable artifact')
            media = self.get('media', job['media_id'])
            require(result.get('service_provenance', {}).get('source_sha256') == media['sha256'], 'Job source provenance mismatch')
            recordings.append({'job_id': identifier, 'media_id': job['media_id'], 'acquisition_quality': result['acquisition_quality'], 'capture_metadata': result.get('capture_metadata'), 'media_metadata': result['media_metadata'], 'source_sha256': media['sha256']})
        return compare_recordings(recordings)

    def update_job(self, record):
        with self.connect() as db:
            db.execute('UPDATE research_records SET body=? WHERE kind=\'job\' AND id=?', (json_text(record), record['job_id']))
        return record

    def artifact(self, identifier, filename, *, verify_inputs=True):
        job = self.get('job', identifier)
        if verify_inputs: self.verify_job_inputs(job)
        basename(filename)
        require(filename in (job.get('result') or {}).get('artifact_files', []), 'Artifact not whitelisted')
        path = self._safe_file(self.jobs_dir / identifier, filename)
        expected = (job.get('result') or {}).get('service_provenance', {}).get('artifact_sha256', {}).get(filename)
        require(isinstance(expected, str) and hashlib.sha256(path.read_bytes()).hexdigest() == expected, 'Artifact checksum missing or changed')
        return path

    def export(self, identifier):
        experiment = self.experiment(identifier)
        descriptor, temporary = tempfile.mkstemp(prefix='export-', suffix='.zip', dir=self.root)
        os.close(descriptor)
        buffer = Path(temporary)
        try:
            with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
                archive.writestr('experiment.json', json_text(experiment))
                archive.writestr('runtime.json', json_text(runtime_versions()))
                for media in experiment['media']:
                    mid = media['media_id']
                    archive.writestr(f'media/{mid}/record.json', json_text(self.media(mid)))
                    archive.write(self.original(mid), f'media/{mid}/original/{media["filename"]}')
                    for item in self.records('sidecar', mid):
                        path = self._safe_file(self.media_dir / mid / 'sidecars', item['filename'])
                        require(hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], 'Sidecar checksum changed')
                        archive.write(path, f'media/{mid}/sidecars/{item["filename"]}')
                for job in experiment['jobs']:
                    jid = job['job_id']
                    result = job.get('result') or {}
                    if job['state'] == 'COMPLETED' and isinstance(result.get('acquisition_quality'), dict):
                        report = json.loads(self.artifact(jid, 'acquisition-quality.json', verify_inputs=False).read_text(encoding='utf-8'))
                        require(report == {key: result.get(key) for key in ('acquisition_quality', 'capture_metadata', 'media_metadata')}, 'Quality result differs from immutable artifact')
                        require(result.get('service_provenance', {}).get('source_sha256') == self.get('media', job['media_id'])['sha256'], 'Job source provenance mismatch')
                    archive.writestr(f'jobs/{jid}/job.json', json_text(job))
                    snapshot = job.get('options', {}).get('capture_sidecar_snapshot')
                    current = self.records('sidecar', job['media_id'])
                    for item in snapshot or []:
                        path = self._safe_file(self.media_dir / job['media_id'] / 'sidecars', item['filename'])
                        require(hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], 'Historical job sidecar checksum changed')
                    archive.writestr(f'jobs/{jid}/export-input-scope.json', json_text({'scope': 'HISTORICAL_IMMUTABLE_JOB_WITH_CURRENT_ATTACHMENTS', 'historical_sidecar_snapshot': snapshot, 'current_sidecar_records': current, 'snapshot_matches_current_attachments': snapshot == current if snapshot is not None else None, 'current_comparison_requires_matching_inputs': True}))
                    for name in (job.get('result') or {}).get('artifact_files', []):
                        archive.write(self.artifact(jid, name, verify_inputs=False), f'jobs/{jid}/{name}')
        except Exception:
            buffer.unlink(missing_ok=True)
            raise
        return buffer
