"""Decoded-stream engineering diagnostics; none are optical or clinical calibration."""
import hashlib
import json
import math
import platform
from pathlib import Path
import numpy as np

SOURCE_SHA256_AT_IMPORT = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
DEFAULT_CONFIG = {'clip_low_code': 5, 'clip_high_code': 250, 'gap_factor': 1.5,
                  'warning_clipped_fraction': 0.05, 'minimum_laplacian_variance': None,
                  'maximum_frame_difference': None}

def validate_config(config=None):
    if config is None: config = {}
    if not isinstance(config, dict) or set(config) - set(DEFAULT_CONFIG): raise ValueError('unknown quality configuration')
    out = {**DEFAULT_CONFIG, **config}
    for key in ('clip_low_code', 'clip_high_code'):
        if type(out[key]) is not int or not 0 <= out[key] <= 255: raise ValueError('clip codes require integers 0..255')
    if out['clip_low_code'] >= out['clip_high_code']: raise ValueError('clip low must precede high')
    for key in ('gap_factor', 'warning_clipped_fraction', 'minimum_laplacian_variance', 'maximum_frame_difference'):
        value = out[key]
        if value is None and key in ('minimum_laplacian_variance', 'maximum_frame_difference'): continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0: raise ValueError('quality thresholds must be finite positive numbers')
    if out['gap_factor'] <= 1 or out['warning_clipped_fraction'] > 1: raise ValueError('invalid gap/fraction threshold')
    return out

def _roi(roi, width=None, height=None):
    if roi is None: return None
    if not isinstance(roi, dict) or set(roi) != {'x','y','width','height'} or any(type(v) is not int for v in roi.values()): raise ValueError('ROI requires integer source-pixel rectangle')
    if roi['x'] < 0 or roi['y'] < 0 or roi['width'] <= 0 or roi['height'] <= 0: raise ValueError('invalid ROI')
    if width is not None and (roi['x']+roi['width'] > width or roi['y']+roi['height'] > height): raise ValueError('ROI outside source')
    return dict(roi)

def validate_capture_metadata(metadata=None):
    if metadata is None: return {}
    keys={'schema_version','capture_source','connection','pair_id','target_id','calibration_stationary_asserted','chart_roi','requested_constraints','observed_track_settings','browser_mime_type','browser_video_callbacks','declared_source_settings','recorder_status','recorder_error','recorder_bytes','browser_callback_clock_scope'}
    if not isinstance(metadata,dict) or set(metadata)-keys: raise ValueError('unknown capture metadata')
    out=json.loads(json.dumps(metadata,allow_nan=False))
    if 'schema_version' in out and (type(out['schema_version']) is not int or out['schema_version'] != 1): raise ValueError('capture schema version must be 1')
    if 'capture_source' in out and out['capture_source'] not in ('BROWSER_DROIDCAM','BROWSER_CAMERA','UPLOADED_FILE'): raise ValueError('invalid capture source')
    if 'connection' in out:
        c=out['connection']
        if not isinstance(c,dict) or set(c)!={'method','provenance'} or c['method'] not in ('USB','WIFI','UNKNOWN') or c['provenance'] not in ('USER_DECLARED','UNKNOWN'): raise ValueError('invalid connection declaration')
    for key in ('pair_id','target_id','browser_mime_type'):
        if key in out and out[key] is not None and (not isinstance(out[key],str) or not out[key].strip() or len(out[key])>512): raise ValueError('invalid capture text')
    if 'calibration_stationary_asserted' in out and type(out['calibration_stationary_asserted']) is not bool: raise ValueError('stationarity requires boolean')
    if 'chart_roi' in out: _roi(out['chart_roi'])
    for key in ('requested_constraints','observed_track_settings'):
        if key in out and out[key] is not None and not isinstance(out[key],dict): raise ValueError('track metadata requires object')
    track=out.get('observed_track_settings') or {}
    for key in ('width','height','frameRate'):
        if key in track and (isinstance(track[key],bool) or not isinstance(track[key],(int,float)) or not math.isfinite(track[key]) or track[key]<=0): raise ValueError('invalid observed track dimension/rate')
    if 'declared_source_settings' in out:
        settings=out['declared_source_settings']
        if not isinstance(settings,dict) or set(settings)-{'provenance','app_version','client_version','filters','focus','exposure','white_balance','notes'} or settings.get('provenance')!='USER_DECLARED' or any(not isinstance(v,str) or len(v)>4096 for v in settings.values()): raise ValueError('invalid declared source settings')
    if 'recorder_status' in out and out['recorder_status'] not in ('COMPLETE','PARTIAL','ERROR'): raise ValueError('invalid recorder status')
    if 'recorder_error' in out and out['recorder_error'] is not None and (not isinstance(out['recorder_error'],str) or len(out['recorder_error'])>4096): raise ValueError('invalid recorder error')
    if 'recorder_bytes' in out and (type(out['recorder_bytes']) is not int or out['recorder_bytes']<0): raise ValueError('invalid recorder byte count')
    if 'browser_callback_clock_scope' in out and out['browser_callback_clock_scope']!='BROWSER_PRESENTATION_CALLBACK_NOT_SENSOR': raise ValueError('invalid callback clock scope')
    if 'browser_video_callbacks' in out:
        callbacks=out['browser_video_callbacks']
        if not isinstance(callbacks,list) or len(callbacks)>10000: raise ValueError('callback count exceeds bound')
        for c in callbacks:
            if not isinstance(c,dict) or set(c)-{'mediaTime','presentedFrames','performance_time_ms'}: raise ValueError('invalid callback')
            for k,v in c.items():
                if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0: raise ValueError('invalid callback number')
                if k=='presentedFrames' and type(v) is not int: raise ValueError('presentedFrames requires integer')
    return out

def frame_metrics(rgb, previous_rgb=None, roi=None, config=None):
    cfg=validate_config(config)
    if not isinstance(rgb,np.ndarray) or rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3 or min(rgb.shape[:2]) <= 0 or rgb.shape[0]*rgb.shape[1]>16000000: raise ValueError('RGB requires bounded nonempty uint8 HxWx3')
    h,w=rgb.shape[:2]; rectangle=_roi(roi,w,h)
    def crop(a):
        if rectangle is None: return a
        r=rectangle; return a[r['y']:r['y']+r['height'],r['x']:r['x']+r['width']]
    a=crop(rgb).astype(np.float64); y=a @ np.array([.2126,.7152,.0722])
    dy=np.diff(y,axis=0); dx=np.diff(y,axis=1)
    lap=(y[:-2,1:-1]+y[2:,1:-1]+y[1:-1,:-2]+y[1:-1,2:]-4*y[1:-1,1:-1]) if min(y.shape)>=3 else None
    edges=[np.abs(v).ravel() for v in (dy,dx) if v.size]
    boundary=[]; ordinary=[]
    for axis in (0,1):
        d=np.abs(np.diff(y,axis=axis)); positions=np.arange(1,y.shape[axis])+(rectangle['y' if axis==0 else 'x'] if rectangle else 0)
        if d.size:
            selected=np.take(d,np.flatnonzero(positions%8==0),axis=axis); other=np.take(d,np.flatnonzero(positions%8!=0),axis=axis)
            if selected.size: boundary.append(selected.ravel())
            if other.size: ordinary.append(other.ravel())
    block=float(np.concatenate(boundary).mean()-np.concatenate(ordinary).mean()) if boundary and ordinary else None
    difference=None
    if isinstance(previous_rgb,np.ndarray) and previous_rgb.dtype==np.uint8 and previous_rgb.shape==rgb.shape:
        difference=float(np.abs(a-crop(previous_rgb).astype(float)).mean())
    return {'scope':'CHART_ROI' if rectangle else 'FULL_FRAME_SCENE_CONFOUNDED','roi':rectangle,'width':w,'height':h,
            'mean_luma':float(y.mean()),'mean_rgb':[float(v) for v in a.mean(axis=(0,1))],
            'clipped_high_fraction':float(np.any(a>=cfg['clip_high_code'],axis=2).mean()),
            'clipped_low_fraction':float(np.any(a<=cfg['clip_low_code'],axis=2).mean()),
            'laplacian_variance':float(lap.var()) if lap is not None else None,
            'edge_strength':float(np.concatenate(edges).mean()) if edges else None,
            'block_boundary_excess':block,'frame_difference_mean':difference,
            'decoded_rgb_sha256':hashlib.sha256(rgb.tobytes()).hexdigest()}

def _stats(values):
    values=[float(v) for v in values if v is not None and math.isfinite(float(v))]
    if not values: return {'count':0,'mean':None,'std':None,'min':None,'max':None}
    a=np.array(values); return {'count':len(values),'mean':float(a.mean()),'std':float(a.std()),'min':float(a.min()),'max':float(a.max())}

def summarize_quality(frame_records, media_metadata, *, source_path=None, capture_metadata=None, config=None):
    cfg=validate_config(config); capture=validate_capture_metadata(capture_metadata)
    records=list(frame_records); series=[]; times=[]; hashes=[]
    for r in records:
        m=r.get('quality_metrics',r.get('acquisition_quality'))
        if not isinstance(m,dict): raise ValueError('frame quality metrics missing')
        t=r.get('timestamp_ns'); source=r.get('timestamp_source','UNAVAILABLE')
        if t is not None:
            if isinstance(t,bool) or not isinstance(t,(str,int)) or isinstance(t,str) and (not t.lstrip('-').isdigit()): raise ValueError('invalid timestamp')
            try: t=int(t)
            except (TypeError,ValueError): raise ValueError('invalid timestamp')
        times.append(t); hashes.append(m.get('decoded_rgb_sha256'))
        series.append({'frame_index':r['frame_index'],'timestamp_ns':str(t) if t is not None else None,'timestamp_source':source,**m})
    intervals=[]; duplicate=0; backwards=0; gaps=[]
    for i in range(1,len(times)):
        if times[i] is None or times[i-1] is None: continue
        d=(times[i]-times[i-1])/1e9
        if d==0: duplicate+=1
        elif d<0: backwards+=1
        else: intervals.append((i,d))
    ds=[d for _,d in intervals]; median=float(np.median(ds)) if ds else None
    if median:
        gaps=[{'after_frame_index':series[i-1]['frame_index'],'before_frame_index':series[i]['frame_index'],'interval_seconds':d,'nominal_missing_intervals_estimate':max(0,round(d/median)-1)} for i,d in intervals if d>cfg['gap_factor']*median]
    complete=bool(times) and all(t is not None for t in times) and not duplicate and not backwards
    span=(times[-1]-times[0])/1e9 if complete and len(times)>1 else None
    stats=_stats(ds)
    timing={'scope':'MEDIA_PRESENTATION_NOT_SENSOR_TIME','available_timestamps':sum(t is not None for t in times),'missing_timestamps':sum(t is None for t in times),'duplicate_timestamps':duplicate,'nonmonotonic_intervals':backwards,'span_seconds':span,'effective_fps':(len(times)-1)/span if span and span>0 else None,'interval_seconds':{**stats,'median':median,'cv':stats['std']/stats['mean'] if stats['mean'] else None},'gap_events':gaps,'exact_source_dropped_frames':'UNKNOWN','gap_estimate_scope':'MEDIAN_INTERVAL_HEURISTIC_NOT_SOURCE_DROP_COUNT'}
    names=('mean_luma','clipped_high_fraction','clipped_low_fraction','laplacian_variance','edge_strength','block_boundary_excess','frame_difference_mean')
    metrics={k:_stats([s.get(k) for s in series]) for k in names}
    metrics['mean_rgb']=[_stats([s['mean_rgb'][c] for s in series]) for c in range(3)]
    chroma=[]
    for s in series:
        total=sum(s['mean_rgb']); chroma.append([v/total for v in s['mean_rgb']] if total>0 else None)
    metrics['rgb_chromaticity']=[_stats([v[c] for v in chroma if v is not None]) for c in range(3)]
    paired=[(v['frame_difference_mean'],v['laplacian_variance']) for v in series if v.get('frame_difference_mean') is not None and v.get('laplacian_variance') is not None]
    correlation=None
    if len(paired)>=3:
        arr=np.asarray(paired)
        if np.all(arr.std(axis=0)>0): correlation=float(np.corrcoef(arr.T)[0,1])
    motion_sharpness={'paired_frame_count':len(paired),'pearson_correlation':correlation,'scope':'DESCRIPTIVE_PROXY_ASSOCIATION_NOT_CAUSAL_MOTION_DEGRADATION'}
    diagnostics=[]
    for s in series:
        reasons=[]
        if s['clipped_high_fraction']>cfg['warning_clipped_fraction']: reasons.append('HIGH_CODE_CLIPPING')
        if s['clipped_low_fraction']>cfg['warning_clipped_fraction']: reasons.append('LOW_CODE_CLIPPING')
        if cfg['minimum_laplacian_variance'] is not None and s['laplacian_variance'] is not None and s['laplacian_variance']<cfg['minimum_laplacian_variance']: reasons.append('BELOW_CONFIGURED_SHARPNESS_PROXY')
        if cfg['maximum_frame_difference'] is not None and s['frame_difference_mean'] is not None and s['frame_difference_mean']>cfg['maximum_frame_difference']: reasons.append('ABOVE_CONFIGURED_FRAME_DIFFERENCE')
        diagnostics.append({'frame_index':s['frame_index'],'diagnostic_reasons':reasons,'retained':True})
    encoded={'scope':'SAVED_STREAM_NOT_ORIGINAL_DROIDCAM_LINK','upstream_droidcam_compression':'UNKNOWN','codec':media_metadata.get('codec'),'stream_bit_rate':media_metadata.get('stream_bit_rate'),'format_bit_rate':media_metadata.get('format_bit_rate')}
    config_hash=hashlib.sha256(json.dumps(cfg,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    resolutions=sorted({(s['width'],s['height']) for s in series})
    return {'schema_version':1,'motion_sharpness_association':motion_sharpness,'frame_count':len(records),'resolution':[{'width':w,'height':h} for w,h in resolutions],'timing':timing,'metrics':metrics,'series':series,'diagnostics':diagnostics,'repeated_exact_decoded_adjacent_frames':sum(a is not None and a==b for a,b in zip(hashes,hashes[1:])), 'black_chromaticity_unavailable_frames':sum(v is None for v in chroma),'variability_scope':('STATIONARY_CHART_ROI_USER_ASSERTED' if capture.get('chart_roi') else 'FULL_FRAME_CHART_USER_ASSERTED') if capture.get('calibration_stationary_asserted') else 'SCENE_MOTION_ILLUMINATION_CONFOUNDED','encoded_stream':encoded,'capture_metadata':capture,'config':cfg,'provenance':{'source_sha256':hashlib.sha256(Path(source_path).read_bytes()).hexdigest() if source_path else None,'quality_code_sha256':SOURCE_SHA256_AT_IMPORT,'config_sha256':config_hash,'runtime':{'python':platform.python_version(),'numpy':np.__version__}},'metric_definitions':{'directly_measured':['resolution','decoded_frame_count','mean_rgb','mean_luma_code_BT709','clipped_code_fractions_any_RGB_channel_not_luma','decoded_presentation_intervals'],'proxies':['laplacian_variance_code_squared_interior_4_neighbor','edge_strength_mean_absolute_adjacent_luma_code','block_boundary_excess_signed_8_pixel_grid_code','frame_difference_mean_absolute_RGB_code'],'variability':'population descriptive std over this session; no confidence interval'},'limitations':['Default thresholds are uncalibrated engineering diagnostics, not clinical acceptance.','Sharpness can increase with noise; block-grid excess is scene-content confounded.','Frame difference includes scene, illumination and compression changes; it is not pose. RGB code variation does not establish exposure or white-balance causation.','Presentation gaps and repeated decoded frames do not prove sensor or transport drops.','No hardware, optical or clinical accuracy or quality winner is established.']}

def compare_recordings(recordings):
    records=list(recordings)
    if not 2<=len(records)<=20: raise ValueError('comparison requires 2..20 recordings')
    reasons=[]; groups={'USB':[],'WIFI':[],'UNKNOWN':[]}
    for r in records:
        q=r['acquisition_quality']; c=validate_capture_metadata(r.get('capture_metadata',q.get('capture_metadata')))
        method=c.get('connection',{}).get('method','UNKNOWN'); groups[method].append(r)
        if c.get('connection',{}).get('provenance')!='USER_DECLARED': reasons.append('CONNECTION_PROVENANCE_UNKNOWN')
        if c.get('recorder_status') in ('PARTIAL','ERROR') or c.get('recorder_error'): reasons.append('RECORDER_INCOMPLETE')
        settings=c.get('declared_source_settings',{})
        if any(not settings.get(k,'').strip() for k in ('app_version','client_version','filters','focus','exposure','white_balance')): reasons.append('INCOMPLETE_DECLARED_SOURCE_SETTINGS')
        if not q.get('frame_count'): reasons.append('EMPTY_RECORDING')
        if not c.get('calibration_stationary_asserted'): reasons.append('STATIONARY_CHART_NOT_ASSERTED')
    for key in ('pair_id','target_id','chart_roi','observed_track_settings','declared_source_settings'):
        values=[r.get('capture_metadata',r['acquisition_quality'].get('capture_metadata',{})).get(key) for r in records]
        if (key!='chart_roi' and any(v is None or v=='' or v=={} for v in values)) or any(v!=values[0] for v in values): reasons.append('UNMATCHED_'+key.upper())
    for key in ('resolution','config'):
        values=[r['acquisition_quality'].get(key) for r in records]
        if any(v!=values[0] for v in values): reasons.append('MISMATCHED_'+key.upper())
    codecs=[r['acquisition_quality'].get('encoded_stream',{}).get('codec') for r in records]
    if any(v is None for v in codecs) or any(v!=codecs[0] for v in codecs): reasons.append('UNKNOWN_OR_MISMATCHED_CODEC')
    if not groups['USB'] or not groups['WIFI'] or groups['UNKNOWN']: reasons.append('USB_WIFI_GROUPS_UNMATCHED')
    source_hashes=[r.get('source_sha256') or r['acquisition_quality'].get('provenance',{}).get('source_sha256') for r in records]
    known_hashes=[v for v in source_hashes if v]
    if len(known_hashes)!=len(set(known_hashes)): reasons.append('REUSED_IDENTICAL_SOURCE_NOT_INDEPENDENT_ACQUISITIONS')
    differences={}
    if groups['USB'] and groups['WIFI']:
        for metric in ('mean_luma','laplacian_variance','clipped_high_fraction','frame_difference_mean','block_boundary_excess'):
            a=_stats([r['acquisition_quality']['metrics'][metric]['mean'] for r in groups['USB']]); b=_stats([r['acquisition_quality']['metrics'][metric]['mean'] for r in groups['WIFI']])
            differences[metric]={'USB':a,'WIFI':b,'WIFI_minus_USB':b['mean']-a['mean'] if a['mean'] is not None and b['mean'] is not None else None}
        for metric in ('effective_fps',):
            a=_stats([r['acquisition_quality']['timing'][metric] for r in groups['USB']]); b=_stats([r['acquisition_quality']['timing'][metric] for r in groups['WIFI']]); differences[metric]={'USB':a,'WIFI':b,'WIFI_minus_USB':b['mean']-a['mean'] if a['mean'] is not None and b['mean'] is not None else None}
    return {'schema_version':1,'status':'ELIGIBLE_DESCRIPTIVE_COMPARISON' if not reasons else 'INELIGIBLE_CONFOUNDED','recordings':records,'groups':{k:[r.get('job_id') for r in v] for k,v in groups.items()},'ineligibility_reasons':sorted(set(reasons)),'differences':differences,'difference_scope':'DESCRIPTIVE_OBSERVED_ONLY_NOT_ATTRIBUTABLE','limitations':['Connection is user declared, not independently transport verified.','Matching recorded fields cannot exclude device, light, encoder, motion, order or session confounds.','Group std is descriptive session variability, not uncertainty or clinical accuracy.','Signed differences imply no universal quality winner; sharpness may reflect noise.']}
