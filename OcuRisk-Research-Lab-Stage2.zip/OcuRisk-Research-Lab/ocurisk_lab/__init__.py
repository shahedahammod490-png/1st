"""Independent OcuRisk Research Lab. Research only."""
__version__ = "0.1.0"
