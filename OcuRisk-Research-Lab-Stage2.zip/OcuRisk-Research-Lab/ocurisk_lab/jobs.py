"""Bounded asynchronous processing; restart marks unfinished work interrupted."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import threading
import uuid
from .research_store import now
from .schema import require
from .store import runtime_versions

TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED'}
SOURCE_HASHES_AT_IMPORT = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}

class JobManager:
    def __init__(self, store, analyzer=None):
        self.store = store
        self.analyzer = analyzer
        self.lock = threading.RLock()
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='lab-analysis')
        for job in store.records('job'):
            if job['state'] not in TERMINAL:
                job['result'] = self._partial(job['job_id'], job.get('result'))
                job.update(state='INTERRUPTED', error='Service restarted before completion', updated_at=now())
                store.update_job(job)

    def _partial(self, identifier, fallback=None):
        path = self.store.jobs_dir / identifier / 'result.partial.json'
        if path.is_file() and not path.is_symlink():
            try:
                from .server import strict_json
                from .research_store import finite_json
                value = strict_json(path.read_bytes())
                finite_json(value)
                require(isinstance(value, dict) and isinstance(value.get('frames'), list), 'Invalid partial result')
                return self._artifact_hashes(identifier, value)
            except (ValueError, OSError):
                pass
        return fallback

    def _artifact_hashes(self, identifier, result):
        if not result:
            return result
        from .research_store import basename
        hashes = {}
        for name in result.get('artifact_files', []):
            basename(name)
            path = self.store._safe_file(self.store.jobs_dir / identifier, name)
            hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
            previous = result.get('service_provenance', {}).get('artifact_sha256', {}).get(name)
            require(previous is None or previous == hashes[name], 'Artifact changed since checkpoint')
        result.setdefault('service_provenance', {})['artifact_sha256'] = hashes
        return result

    def submit(self, identifier, payload):
        options = self.store.process_options(identifier, payload)
        with self.lock:
            require(sum(x['state'] not in TERMINAL for x in self.store.records('job')) < 16, 'Processing queue is full')
            jid = uuid.uuid4().hex
            job = dict(job_id=jid, media_id=identifier, state='QUEUED', progress={'done': 0, 'total': None}, options=options, result=None, error=None, created_at=now(), updated_at=now(), cancel_requested=False)
            self.store.put('job', job, identifier)
            self.pool.submit(self._run, jid)
            return job

    def cancel(self, identifier):
        with self.lock:
            job = self.store.get('job', identifier)
            if job['state'] not in TERMINAL:
                job['cancel_requested'] = True
                job['updated_at'] = now()
                self.store.update_job(job)
            return job

    def _run(self, identifier):
        with self.lock:
            job = self.store.get('job', identifier)
            job.update(state='CANCELLED' if job['cancel_requested'] else 'RUNNING', updated_at=now())
            self.store.update_job(job)
            if job['state'] == 'CANCELLED':
                return
        output = self.store.jobs_dir / identifier
        output.mkdir()
        def cancelled():
            return self.store.get('job', identifier)['cancel_requested']
        def progress(value):
            with self.lock:
                require(isinstance(value, dict), 'Invalid job progress')
                done, total = value.get('done'), value.get('total')
                require(type(done) is int and done >= 0 and (total is None or type(total) is int and total >= done), 'Invalid job progress counts')
                current = self.store.get('job', identifier)
                require(done >= current['progress']['done'], 'Job progress must be monotonic')
                current.update(result=self._partial(identifier, current.get('result')), progress=value, updated_at=now())
                self.store.update_job(current)
        result = None
        try:
            media = self.store.get('media', job['media_id'])
            path = self.store.original(job['media_id'])
            self.store.verify_job_inputs(job)
            analyzer = self.analyzer
            if analyzer is None:
                from .video import analyze_media
                analyzer = analyze_media
            source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}
            require(source_hashes == SOURCE_HASHES_AT_IMPORT, 'Implementation changed after service import; restart before processing')
            result = analyzer(path, output, media=media, options=job['options'], progress=progress, cancelled=cancelled)
            require(isinstance(result, dict), 'Analyzer result must be object')
            self.store.verify_job_inputs(job)
            require(hashlib.sha256(path.read_bytes()).hexdigest() == media['sha256'], 'Original source changed during processing')
            require(source_hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}, 'Implementation changed during processing')
            result['service_provenance'] = {'source_sha256': media['sha256'], 'source_hashes': source_hashes, 'runtime_versions': runtime_versions(), 'annotation_snapshot': job['options']['annotations'], 'capture_metadata_snapshot': job['options'].get('capture_metadata'), 'capture_sidecar_snapshot': job['options'].get('capture_sidecar_snapshot'), 'quality_config': job['options'].get('quality_config')}
            if isinstance(result.get('acquisition_quality'), dict):
                report = {'acquisition_quality': result['acquisition_quality'], 'capture_metadata': result.get('capture_metadata'), 'media_metadata': result.get('media_metadata')}
                from .research_store import json_text
                (output / 'acquisition-quality.json').write_text(json_text(report), encoding='utf-8')
                result.setdefault('artifact_files', []).append('acquisition-quality.json')
            result = self._artifact_hashes(identifier, result)
            status = result.get('status')
            state = 'CANCELLED' if cancelled() or status == 'CANCELLED' else 'COMPLETED' if status in ('COMPLETED', 'SUCCESS') else 'FAILED'
            error = None if state == 'COMPLETED' else result.get('error') or f'Analysis ended with {status}'
        except Exception as exc:
            state = 'CANCELLED' if cancelled() else 'FAILED'
            error = f'{type(exc).__name__}: {exc}'
            # Preserve concrete files produced before failure without inventing observations.
            result = self._partial(identifier, result) or {'status': state, 'frames': [], 'artifact_files': sorted(p.name for p in output.iterdir() if p.is_file() and not p.is_symlink()), 'error': error}
        with self.lock:
            current = self.store.get('job', identifier)
            try:
                result = self._artifact_hashes(identifier, result)
            except (ValueError, OSError) as exc:
                state, error = 'FAILED', f'Artifact integrity failure: {exc}'
            current.update(state=state, result=result, error=error, updated_at=now())
            self.store.update_job(current)

    def shutdown(self):
        for job in self.store.records('job'):
            if job['state'] not in TERMINAL:
                self.cancel(job['job_id'])
        self.pool.shutdown(wait=True, cancel_futures=False)
