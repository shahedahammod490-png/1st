"""Common decoded source-circle comparisons; unvalidated code-value masks."""
import hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from .optical import _components, _annotation
SOURCE_SHA256_AT_IMPORT=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
IDS=('BOUNDARY_Y','BOUNDARY_RE','BOUNDARY_Y_RE','ADAPTED_OLD')
def registry():
    definitions={'BOUNDARY_Y':'positive Y deviation touching boundary','BOUNDARY_RE':'positive red-excess deviation touching boundary','BOUNDARY_Y_RE':'union of Y and RE deviations touching boundary','ADAPTED_OLD':'legacy top/bottom contrast with artificial 0.08 floor; not crescent area'}
    return [{'algorithm_id':key,'version':'2.0.0','title':key,'definition':definitions[key],'status':'UNVALIDATED_IMAGE_HEURISTIC','config':{'boundary_radius':.72,'min_contrast':.035,'mad_multiplier':2.5}} for key in IDS]
def compare(rgb,circle,output_dir,prefix,algorithms=None):
    algorithms=IDS if algorithms is None else algorithms
    if any(a not in IDS for a in algorithms): raise ValueError('unknown optical algorithm')
    yy,xx=np.mgrid[:rgb.shape[0],:rgb.shape[1]]
    radial=np.hypot(xx-circle['cx_px'],yy-circle['cy_px'])/circle['radius_px']; roi=radial<=1
    values=np.asarray(rgb,dtype=float)/255; r,g,b=np.moveaxis(values,-1,0); y=.5*r+.25*g+.25*b; re=r-(g+b)/2
    selected={}
    for name,channel in [('Y',y),('RE',re)]:
        samples=channel[roi]; median=float(np.median(samples)) if samples.size else 0
        mad=float(np.median(abs(samples-median)))*1.4826 if samples.size else 0
        selected[name]=roi & (channel-median>max(.035,2.5*mad))
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True); results={}
    roi_hash=hashlib.sha256(roi.tobytes()).hexdigest()
    for algorithm in algorithms:
        if algorithm=='ADAPTED_OLD':
            inner=roi&(radial<=.85); v=(yy-circle['cy_px'])/circle['radius_px']; top=inner&(v<-.2125); bottom=inner&(v>.2125); mid=inner&~(top|bottom)
            contrast=max(0,float(y[top].mean()-y[mid].mean()),float(y[bottom].mean()-y[mid].mean()))/max(1/255,float(y[mid].mean())) if top.any() and bottom.any() and mid.any() else None
            results[algorithm]={'value':round(min(.6,max(.08,.08+1.75*contrast)),2) if contrast is not None else None,'unit':'legacy_ratio_with_artificial_floor','roi_sha256':roi_hash,'artifacts':{},'prediction':None}; continue
        raw=selected['Y'] if algorithm=='BOUNDARY_Y' else selected['RE'] if algorithm=='BOUNDARY_RE' else selected['Y']|selected['RE']
        mask=np.zeros_like(roi)
        for component in _components(raw):
            cy,cx=component[:,0],component[:,1]
            if len(component)>=8 and np.any(radial[cy,cx]>=.72): mask[cy,cx]=True
        filename=f'{prefix}_{algorithm}_mask.png'; Image.fromarray(mask.astype('uint8')*255).save(out/filename)
        results[algorithm]={'value':float(mask.sum()/roi.sum()) if roi.any() else None,'unit':'fraction_of_source_circle','roi_sha256':roi_hash,'artifacts':{'candidate_mask':filename},'prediction':None}
    return results
