"""Independent model lab. JSON checkpoints only; no clinical validation implied."""
import copy
import hashlib
import json
import math
import os
import platform
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

LOADED_SOURCE_HASH = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

ALGORITHMS = ('LINEAR','RIDGE','ELASTIC_NET','RANDOM_FOREST','GRADIENT_BOOSTING','BAYESIAN_LOGIT')

def finite(x, name='number'):
    if isinstance(x, bool) or not isinstance(x, (int,float)) or not math.isfinite(x):
        raise ValueError(f'{name} must be finite numeric, not bool')
    return float(x)

def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)

def immutable_json(path, record):
    staged=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with staged.open('x') as f:
            f.write(canonical(record)); f.flush(); os.fsync(f.fileno())
        os.link(staged,path)  # atomic publication, never replaces an existing artifact
    finally:
        staged.unlink(missing_ok=True)

def digest(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()

def text(x,name):
    if not isinstance(x,str) or not x.strip() or len(x)>1000: raise ValueError(f'{name} required')
    return x

def _validate(payload, allow_empty_features=False):
    p=copy.deepcopy(payload)
    if p.get('algorithm') not in ALGORITHMS: raise ValueError('unknown algorithm')
    if not isinstance(p,dict) or not isinstance(p.get('dataset'),dict): raise ValueError('dataset object required')
    d=p['dataset']; text(d.get('target_name'),'target_name'); text(d.get('target_unit'),'target_unit')
    records=d.get('records')
    if not isinstance(records,list) or not 2<=len(records)<=10000: raise ValueError('2..10000 records required')
    if not isinstance(records[0],dict) or not isinstance(records[0].get('features'),dict): raise ValueError('record features must be object')
    names=sorted(records[0]['features'])
    if any(k in ('target',d['target_name'],'reference','source_id','sphere_d','cylinder_d','axis_deg') for k in names): raise ValueError('target/reference feature leakage')
    if (not names and not allow_empty_features) or len(names)>128: raise ValueError('1..128 features required')
    participants={}; duplicates={}; references={}; origins=set()
    for r in records:
        if not isinstance(r,dict) or not isinstance(r.get('features'),dict): raise ValueError('record/features must be objects')
        pid=text(r.get('participant_id'),'participant_id'); split=r.get('split')
        if split not in ('train','validation','test'): raise ValueError('invalid split')
        if pid in participants and participants[pid]!=split: raise ValueError('participant leakage')
        if p['algorithm']=='BAYESIAN_LOGIT' and pid in participants: raise ValueError('Bayesian requires one observation per participant')
        participants[pid]=split
        if sorted(r['features'])!=names: raise ValueError('feature schema mismatch')
        for k,v in r['features'].items(): text(k,'feature name'); finite(v,k)
        finite(r['target'],'target')
        origin=r.get('data_origin'); origins.add(origin)
        if origin=='SYNTHETIC':
            if r.get('target_origin')!='SYNTHETIC': raise ValueError('synthetic target origin required')
        elif origin=='NON_HUMAN_TEST':
            if r.get('target_origin')!='INDEPENDENT_BENCH_REFERENCE': raise ValueError('independent bench reference required')
            ref=r.get('reference',{})
            if not isinstance(ref,dict): raise ValueError('reference must be object')
            for k in ('source_id','method','operator_id','measured_at','apparatus_id','calibration_reference'): text(ref.get(k),k)
            try: dt=datetime.fromisoformat(ref['measured_at'].replace('Z','+00:00'))
            except ValueError: raise ValueError('invalid measured_at')
            if dt.tzinfo is None: raise ValueError('reference timezone required')
            sid=ref['source_id']
            if sid in references and references[sid]!=split: raise ValueError('reference leakage')
            references[sid]=split
        elif origin=='REAL_APPROVED':
            text(r.get('approval_reference'),'approval_reference')
            if r.get('target_origin')!='INDEPENDENT_REFERENCE': raise ValueError('independent reference required')
            ref=r.get('reference',{})
            if not isinstance(ref,dict): raise ValueError('reference must be object')
            for k in ('source_id','method','examiner_id','measured_at'): text(ref.get(k),k)
            try: dt=datetime.fromisoformat(ref['measured_at'].replace('Z','+00:00'))
            except ValueError: raise ValueError('invalid measured_at')
            if dt.tzinfo is None: raise ValueError('reference timezone required')
            sid=ref['source_id']
            if sid in references and references[sid]!=split: raise ValueError('reference leakage')
            references[sid]=split
        else: raise ValueError('invalid data origin')
        key=digest(r['features'])
        if names and key in duplicates and duplicates[key]!=split: raise ValueError('exact duplicate leakage')
        duplicates[key]=split
    if len(origins)!=1: raise ValueError('mixed data origins')
    if len({r['participant_id'] for r in records if r['split']=='train'})<2: raise ValueError('at least two training observations required')
    if p['algorithm']=='BAYESIAN_LOGIT':
        text(d.get('event_definition'),'event_definition')
        if any(r['target'] not in (0,1) for r in records): raise ValueError('Bernoulli target must be 0 or 1')
    return p,names

def validate(payload, *, allow_empty_features=False):
    try: return _validate(payload,allow_empty_features)
    except (KeyError,TypeError,AttributeError) as exc: raise ValueError('malformed training dataset') from exc

def configuration(algorithm, raw):
    if not isinstance(raw,dict): raise ValueError('config must be object')
    common={'cv_folds':(0,10,0),'bootstrap_samples':(0,1000,0),'seed':(0,2147483647,0)}
    specs={
      'LINEAR':{},'RIDGE':{'alpha':(1e-8,1e6,1.)},
      'ELASTIC_NET':{'alpha':(1e-8,1e6,1.),'l1_ratio':(0,1,.5),'max_iter':(100,10000,2000)},
      'RANDOM_FOREST':{'n_estimators':(1,300,100),'max_depth':(1,32,8),'min_samples_leaf':(1,100,1)},
      'GRADIENT_BOOSTING':{'n_estimators':(1,300,100),'max_depth':(1,8,3),'learning_rate':(.001,1,.1)},
      'BAYESIAN_LOGIT':{'prior_sd':(1e-4,100,None),'intercept_prior_mean':(-30,30,None),'intercept_prior_sd':(1e-4,100,None),'max_iter':(100,5000,1000),'posterior_samples':(100,20000,2000)}}[algorithm]
    specs={**common,**specs}
    if set(raw)-set(specs): raise ValueError('unknown config field')
    result={}
    integer={'cv_folds','bootstrap_samples','seed','max_iter','n_estimators','max_depth','min_samples_leaf','posterior_samples'}
    for k,(lo,hi,default) in specs.items():
        v=raw.get(k,default)
        if v is None: raise ValueError(f'explicit {k} required')
        finite(v,k)
        if not lo<=v<=hi or k in integer and int(v)!=v: raise ValueError(f'{k} out of bounds')
        result[k]=int(v) if k in integer else float(v)
    if result['cv_folds']==1: raise ValueError('cv_folds must be 0 or >=2')
    if algorithm=='BAYESIAN_LOGIT' and result['cv_folds']: raise ValueError('Bayesian group CV not implemented; use explicit held-out split')
    return result

def estimator(a,c):
    from sklearn.linear_model import LinearRegression,Ridge,ElasticNet
    from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor
    args={k:v for k,v in c.items() if k not in ('cv_folds','bootstrap_samples','seed')}
    return {'LINEAR':lambda:LinearRegression(),'RIDGE':lambda:Ridge(**args),'ELASTIC_NET':lambda:ElasticNet(**args,random_state=c['seed']), 'RANDOM_FOREST':lambda:RandomForestRegressor(**args,random_state=c['seed'],n_jobs=1),'GRADIENT_BOOSTING':lambda:GradientBoostingRegressor(**args,random_state=c['seed'])}[a]()

def tree_state(tree):
    t=tree.tree_
    return {k:getattr(t,k).tolist() for k in ('children_left','children_right','feature','threshold','value')}

def tree_predict(t,x):
    out=[]
    for row in x:
        node=0
        while t['children_left'][node]!=-1:
            node=t['children_left'][node] if float(row[t['feature'][node]])<=t['threshold'][node] else t['children_right'][node]
        out.append(t['value'][node][0][0])
    return np.array(out)

def state_of(m,a):
    if a in ('LINEAR','RIDGE','ELASTIC_NET'): return {'coef':m.coef_.tolist(),'intercept':float(m.intercept_)}
    if a=='RANDOM_FOREST': return {'trees':[tree_state(t) for t in m.estimators_]}
    return {'trees':[tree_state(t[0]) for t in m.estimators_],'initial':float(m.init_.constant_[0,0]),'learning_rate':float(m.learning_rate)}

def state_predict(state,a,x):
    if a in ('LINEAR','RIDGE','ELASTIC_NET'): return x@np.array(state['coef'])+state['intercept']
    # sklearn trees consume float32 inputs before traversal.
    predictions=np.array([tree_predict(t,x.astype(np.float32)) for t in state['trees']])
    if a=='RANDOM_FOREST': return predictions.mean(axis=0)
    return state['initial']+state['learning_rate']*predictions.sum(axis=0)

def bayesian_objective(theta,z,y,mean,precision):
    from scipy.special import expit
    eta=z@theta; p=expit(eta); delta=theta-mean
    value=np.logaddexp(0,eta).sum()-y@eta+.5*np.sum(precision*delta**2)
    gradient=z.T@(p-y)+precision*delta
    hessian=z.T@((p*(1-p))[:,None]*z)+np.diag(precision)
    return value,gradient,hessian

def fit_bayes(x,y,c):
    from scipy.optimize import minimize
    z=np.column_stack([np.ones(len(x)),x]); mean=np.zeros(z.shape[1]); mean[0]=c['intercept_prior_mean']
    precision=np.full(z.shape[1],1/c['prior_sd']**2); precision[0]=1/c['intercept_prior_sd']**2
    f=lambda t:bayesian_objective(t,z,y,mean,precision)
    fit=minimize(lambda t:f(t)[0],mean,jac=lambda t:f(t)[1],hess=lambda t:f(t)[2],method='trust-exact',options={'maxiter':c['max_iter'],'gtol':1e-8})
    value,g,h=f(fit.x)
    if np.max(np.abs(g))>1e-6: raise ValueError('MAP gradient convergence failed')
    np.linalg.cholesky(h); covariance=np.linalg.inv(h); np.linalg.cholesky(covariance)
    return {'map':fit.x.tolist(),'covariance':covariance.tolist(),'hessian':h.tolist(),'gradient_max_abs':float(np.abs(g).max()),'objective':float(value),'iterations':int(fit.nit),'method':'MAP + Laplace Gaussian approximation'}

def bayes_predict(s,x,c):
    from scipy.special import expit
    rng=np.random.default_rng(c['seed']); draws=rng.multivariate_normal(s['map'],s['covariance'],size=c['posterior_samples'])
    means=[]; intervals=[]
    for start in range(0,len(x),128):
        probs=expit(np.column_stack([np.ones(len(x[start:start+128])),x[start:start+128]])@draws.T)
        means.extend(probs.mean(axis=1)); intervals.extend(np.quantile(probs,[.025,.975],axis=1).T)
    return np.array(means),np.array(intervals)

def metrics(y,p,baseline,participants,boot,seed,binary=False):
    e=p-y; result={'n':len(y),'participants':len(set(participants)),'mae':float(np.abs(e).mean()),'rmse':float(np.sqrt((e**2).mean())),'bias':float(e.mean()),'train_mean_baseline':{'mae':float(np.abs(baseline-y).mean()),'rmse':float(np.sqrt(((baseline-y)**2).mean()))},'participant_bootstrap':None}
    if binary:
        clipped=np.clip(p,1e-15,1-1e-15); result.update(brier=float((e**2).mean()),log_loss=float(-(y*np.log(clipped)+(1-y)*np.log1p(-clipped)).mean()))
    groups=sorted(set(participants))
    if boot and len(groups)>=2:
        rng=np.random.default_rng(seed); values=[]
        for _ in range(boot):
            ix=np.concatenate([np.flatnonzero(np.array(participants)==g) for g in rng.choice(groups,len(groups),replace=True)])
            err=e[ix]; values.append([np.abs(err).mean(),np.sqrt((err**2).mean()),err.mean()])
        result['participant_bootstrap']={'method':'percentile participant resampling; development approximation','samples':boot,'interval_level':.95,'mae':np.quantile(np.array(values)[:,0],[.025,.975]).tolist(),'rmse':np.quantile(np.array(values)[:,1],[.025,.975]).tolist(),'bias':np.quantile(np.array(values)[:,2],[.025,.975]).tolist()}
    return result

class ModelLab:
    def __init__(self,root):
        self.root=Path(root)/'models'; self.root.mkdir(parents=True,exist_ok=True)
    def registry(self):
        try: import sklearn,scipy; available=True
        except ImportError: available=False
        entries=[{'algorithm':a,'algorithm_id':a,'status':'NOT_TRAINED' if available else 'UNAVAILABLE','reason':None if available else 'scikit-learn/scipy dependency missing','clinical_status':'AWAITING_REFERENCE_DATA'} for a in ALGORITHMS]
        from .cnn import availability
        entries.extend(availability())
        models=[]; failures=[]
        for path in sorted(self.root.glob('*.json')):
            try: models.append(self.model(path.stem))
            except (ValueError,KeyError,TypeError): failures.append({'model_id':path.stem,'status':'CORRUPT_ARTIFACT'})
        for entry in entries:
            versions=[{'model_id':m['model_id'],'status':m['status'],'data_origin':m['data_origin']} for m in models if m['algorithm']==entry['algorithm']]
            entry['trained_versions']=versions
            if versions and entry['status']!='UNAVAILABLE': entry['status']='TRAINED_VERSIONS_AVAILABLE'
        return {'algorithms':entries,'models':models,'artifact_failures':failures}
    def model(self,id):
        if not isinstance(id,str) or not re.fullmatch(r'[a-f0-9]{32}',id): raise ValueError('invalid model id')
        record=json.loads((self.root/f'{id}.json').read_text())
        if record['artifact_hash']!=digest({k:v for k,v in record.items() if k!='artifact_hash'}): raise ValueError('model artifact integrity failure')
        return record
    def train(self,payload):
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=LOADED_SOURCE_HASH: raise ValueError('loaded model source changed')
        p,names=validate(payload); a=p['algorithm']; c=configuration(a,p.get('config',{})); rows=p['dataset']['records']
        x=np.array([[r['features'][k] for k in names] for r in rows]); y=np.array([r['target'] for r in rows]); ix=np.array([r['split']=='train' for r in rows]); tx=x[ix]; ty=y[ix]
        mu=tx.mean(axis=0); scale=tx.std(axis=0);
        if not np.isfinite(mu).all() or not np.isfinite(scale).all(): raise ValueError('numeric scaling overflow')
        scale[scale==0]=1; sx=(x-mu)/scale
        if not np.isfinite(sx).all(): raise ValueError('numeric transform overflow')
        cv=None
        if c['cv_folds']:
            from sklearn.model_selection import GroupKFold
            from sklearn.preprocessing import StandardScaler
            groups=np.array([r['participant_id'] for r in rows])[ix]
            if len(set(groups))<c['cv_folds']: raise ValueError('not enough training participants for grouped CV')
            folds=[]
            for train,val in GroupKFold(c['cv_folds']).split(tx,ty,groups):
                scaler=StandardScaler().fit(tx[train]); m=estimator(a,c); m.fit(scaler.transform(tx[train]),ty[train]); pred=m.predict(scaler.transform(tx[val])); folds.append(metrics(ty[val],pred,float(ty[train].mean()),groups[val].tolist(),0,c['seed']))
            cv={'method':'GroupKFold on training participants; per-fold training scaler','folds':folds}
        if a=='BAYESIAN_LOGIT': state=fit_bayes(sx[ix],ty,c); pred,interval=bayes_predict(state,sx,c)
        else:
            m=estimator(a,c); m.fit(sx[ix],ty); state=state_of(m,a); pred=state_predict(state,a,sx); interval=None
            if not np.allclose(pred,m.predict(sx),rtol=1e-10,atol=1e-10): raise ValueError('safe estimator reconstruction mismatch')
        evaluation={}
        for split in ('train','validation','test'):
            ids=[j for j,r in enumerate(rows) if r['split']==split]
            evaluation[split]=metrics(y[ids],pred[ids],float(ty.mean()),[rows[j]['participant_id'] for j in ids],c['bootstrap_samples'],c['seed'],a=='BAYESIAN_LOGIT') if ids else None
        import sklearn,scipy
        record={'model_id':uuid.uuid4().hex,'algorithm':a,'status':'TRAINED_BENCH_RESEARCH_ONLY' if rows[0]['data_origin']=='NON_HUMAN_TEST' else 'TRAINED','clinical_status':'NOT_VALIDATED','data_origin':rows[0]['data_origin'],'provenance_authentication':'caller assertions; not independently authenticated','created_at':datetime.now(timezone.utc).isoformat(),'payload':p,'payload_hash':digest(p),'config':c,'feature_names':names,'scaler':{'mean':mu.tolist(),'scale':scale.tolist(),'fit_split':'train'},'estimator':state,'evaluation':evaluation,'cross_validation':cv,'runtime':{'python':platform.python_version(),'numpy':np.__version__,'sklearn':sklearn.__version__,'scipy':scipy.__version__},'source_hashes':{'models.py':LOADED_SOURCE_HASH},'limitations':['Synthetic fits verify engineering only. Feature-name/exact-row checks are limited; near-duplicate and semantic leakage need independent dataset review.','No clinical calibration or disease-risk claim.','Held-out metrics are descriptive; no automatic VALIDATED state.']}
        record['artifact_hash']=digest(record)
        path=self.root/f"{record['model_id']}.json"
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=LOADED_SOURCE_HASH: raise ValueError('loaded model source changed')
        immutable_json(path,record)
        return record
    def predict(self,id,features):
        r=self.model(id)
        if not isinstance(features,list) or not 1<=len(features)<=10000: raise ValueError('1..10000 feature rows required')
        names=r['feature_names']; values=[]
        for row in features:
            if not isinstance(row,dict) or sorted(row)!=names: raise ValueError('feature schema mismatch')
            values.append([finite(row[k],k) for k in names])
        x=(np.array(values)-r['scaler']['mean'])/r['scaler']['scale']
        if not np.isfinite(x).all(): raise ValueError('numeric transform overflow')
        if r['algorithm']=='BAYESIAN_LOGIT':
            p,interval=bayes_predict(r['estimator'],x,r['config']); predictions=[{'posterior_predictive_probability':float(v),'approximate_probability_interval':ci.tolist(),'posterior_integration':{'method':'Gaussian Laplace Monte Carlo','seed':r['config']['seed'],'draws':r['config']['posterior_samples']},'interval_scope':'95% Laplace posterior interval for fitted event probability; not outcome uncertainty','event_definition':r['payload']['dataset']['event_definition'],'clinical_risk':None} for v,ci in zip(p,interval)]
        else: predictions=[{'value':float(v),'unit':r['payload']['dataset']['target_unit'],'clinical_prediction':None} for v in state_predict(r['estimator'],r['algorithm'],x)]
        return {'model_id':id,'predictions':predictions,'clinical_status':'NOT_VALIDATED'}

def legacy_physics(payload):
    bounds={'crescent_ratio':(0,.8),'pupil_diameter_mm':(2,8),'reflex_ratio':(0,1),'working_distance_cm':(20,150),'flash_eccentricity_mm':(1,25),'optical_constant_k':(1,15)}
    requested={k:finite(payload[k],k) for k in bounds}; effective={k:min(hi,max(lo,requested[k])) for k,(lo,hi) in bounds.items()}
    orientation=payload['orientation']
    if orientation not in ('TOP','BOTTOM','SYMMETRIC'): raise ValueError('invalid orientation')
    sign={'TOP':-1,'BOTTOM':1,'SYMMETRIC':0}[orientation]; e=effective
    raw=sign*e['optical_constant_k']*e['crescent_ratio']*e['working_distance_cm']/(e['flash_eccentricity_mm']*e['pupil_diameter_mm'])
    clipped=min(8,max(-10,raw)); rounded=math.floor(clipped*4+.5)/4
    derivatives={'crescent_ratio':sign*e['optical_constant_k']*e['working_distance_cm']/(e['flash_eccentricity_mm']*e['pupil_diameter_mm']),'working_distance_cm':raw/e['working_distance_cm'],'optical_constant_k':raw/e['optical_constant_k'],'flash_eccentricity_mm':-raw/e['flash_eccentricity_mm'],'pupil_diameter_mm':-raw/e['pupil_diameter_mm'],'reflex_ratio':0.}
    return {'status':'LEGACY_UNCALIBRATED_COMPARATOR','requested':requested,'effective':effective,'orientation':orientation,'units':{'crescent_ratio':'dimensionless (legacy height/radius convention)','pupil_diameter_mm':'mm','reflex_ratio':'dimensionless','working_distance_cm':'cm','flash_eccentricity_mm':'mm','optical_constant_k':'legacy dimensional calibration unresolved'},'raw_legacy_numeric_output':raw,'clamped_legacy_numeric_output':clipped,'rounded_legacy_numeric_output':rounded,'derivative_unclipped_at_effective_inputs':derivatives,'clinical_prediction':None,'source_sha256':hashlib.sha256((Path(__file__).parent.parent/'legacy/opticsEngine.ts').read_bytes()).hexdigest()}

def power_vectors(payload):
    s=finite(payload['sphere_d']); c=finite(payload['cylinder_d']); axis=finite(payload['axis_deg'])
    if not 0<=axis<=180: raise ValueError('axis_deg must be 0..180')
    angle=math.radians(2*axis)
    return {'M':s+c/2,'J0':-c/2*math.cos(angle),'J45':-c/2*math.sin(angle),'unit':'D','status':'MATHEMATICAL_TRANSFORM_ONLY','clinical_prediction':None}

# Service-facing explicit comparator name.
legacy_uncalibrated = legacy_physics
