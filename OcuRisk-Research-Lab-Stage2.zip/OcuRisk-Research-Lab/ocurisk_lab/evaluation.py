"""Pure descriptive evaluation. These functions do not establish clinical validity."""
import math
import statistics


def regression_metrics(pairs):
    """Each pair is (prediction, independent_reference), in the same declared unit.

    Limits of agreement use sample SD and normal approximation. They describe the
    supplied pairs only; correlated eyes/repeats require a clustered analysis.
    """
    errors = []
    for prediction, reference in pairs:
        if type(prediction) not in (int, float) or type(reference) not in (int, float):
            raise ValueError("numeric values required")
        try:
            if not math.isfinite(prediction) or not math.isfinite(reference):
                raise ValueError("nonfinite prediction or reference")
            error = float(prediction) - float(reference)
            if not math.isfinite(error):
                raise ValueError("prediction-reference difference exceeds finite numeric range")
        except OverflowError as exc:
            raise ValueError("numeric input exceeds finite range") from exc
        errors.append(error)
    if not errors:
        return {"n": 0, "mae": None, "median_absolute_error": None,
                "rmse": None, "bias": None, "sample_sd_error": None,
                "limits_of_agreement_95_normal": None}
    bias = statistics.mean(errors)
    try:
        sd = statistics.stdev(errors) if len(errors) > 1 else None
        scale = max(map(abs, errors))
        rmse = scale * math.sqrt(statistics.mean((e / scale) ** 2 for e in errors)) if scale else 0.0
        limits = None if sd is None else [bias - 1.96 * sd, bias + 1.96 * sd]
        if (sd is not None and not math.isfinite(sd)) or (limits is not None and not all(map(math.isfinite, limits))):
            raise ValueError("derived metric exceeds finite numeric range")
    except OverflowError as exc:
        raise ValueError("derived metric exceeds finite numeric range") from exc
    return {"n": len(errors), "mae": statistics.mean(map(abs, errors)),
            "median_absolute_error": statistics.median(map(abs, errors)),
            "rmse": rmse,
            "bias": bias, "sample_sd_error": sd,
            "limits_of_agreement_95_normal": limits}


def classification_metrics(pairs):
    """Binary observed labels and decisions; None decision is an abstention.

    Returns accepted-case metrics and coverage, retaining full abstention count.
    No ROC-AUC from hard labels, invented denominators, or undefined rates.
    """
    counts = {"tp": 0, "tn": 0, "fp": 0, "fn": 0, "abstained": 0}
    n = 0
    for decision, truth in pairs:
        if type(truth) is not bool or (decision is not None and type(decision) is not bool):
            raise ValueError("binary bool labels and bool/None decision required")
        n += 1
        if decision is None:
            counts["abstained"] += 1
        elif truth:
            counts["tp" if decision else "fn"] += 1
        else:
            counts["fp" if decision else "tn"] += 1
    def ratio(a, b):
        return a / b if b else None
    accepted = n - counts["abstained"]
    return {"n": n, **counts, "coverage": ratio(accepted, n),
            "sensitivity_accepted": ratio(counts["tp"], counts["tp"] + counts["fn"]),
            "specificity_accepted": ratio(counts["tn"], counts["tn"] + counts["fp"]),
            "ppv_accepted": ratio(counts["tp"], counts["tp"] + counts["fp"]),
            "npv_accepted": ratio(counts["tn"], counts["tn"] + counts["fn"])}


def audit_partition(records):
    """Audit explicit participant partitions and exact media hashes.

    Does not prove absence of near duplicates or metadata/reference leakage.
    Multiple eyes, sessions and frames from one participant must stay together.
    """
    subjects, hashes, issues = {}, {}, []
    n_records = 0
    for record in records:
        n_records += 1
        subject, split = record["participant_id"], record["split"]
        if not isinstance(subject, str) or not subject or split not in {"train", "validation", "test"}:
            raise ValueError("participant_id and explicit valid split required")
        if subject in subjects and subjects[subject] != split:
            issues.append({"type": "SUBJECT_LEAKAGE", "participant_id": subject})
        subjects[subject] = split
        for digest in record.get("sha256", []):
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise ValueError("lowercase SHA256 required")
            if digest in hashes:
                prior = hashes[digest]
                issues.append({"type": "EXACT_DUPLICATE", "sha256": digest,
                               "cross_partition": prior[1] != split,
                               "cross_participant": prior[0] != subject})
            else:
                hashes[digest] = (subject, split)
    return {"records": n_records, "participants": len(subjects), "issues": issues,
            "partition_integrity_pass": None if not n_records else not any(i["type"] == "SUBJECT_LEAKAGE" or
            i.get("cross_partition") for i in issues),
            "unassessed": ["near_duplicates", "metadata_leakage", "reference_leakage", "clinical_reference_quality"]}
