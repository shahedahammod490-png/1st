"""Deterministic, annotation-based candidate image features (no clinical inference).

Coordinates are decoded-image pixels, x right/y down. OD/OS are supplied anatomical
labels. A circle is a MANUAL_ANNOTATION, never a fitted or measured pupil boundary.
The candidate, glint and adapted legacy features below are unvalidated heuristics.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image

# Hash once at actual module import; callers can reject stale loaded constants/code.
SOURCE_SHA256_AT_IMPORT = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

ALGORITHM_ID = "manual_circle_candidate_image_features"
ALGORITHM_VERSION = "1.2.0"
DEFAULT_CONFIG = {
    "normalized_size": 145,
    "rd_epsilon": 1 / 255,
    "crop_extent_radii": 1.25,
    "polar_radial_bins": 16,
    "polar_angular_bins": 72,
    "glint_min_y": 0.90,
    "glint_max_chroma": 0.15,
    "glint_max_pupil_fraction": 0.025,
    "candidate_boundary_radius": 0.72,
    "candidate_mad_multiplier": 2.5,
    "candidate_min_contrast": 0.035,
    "candidate_min_component_pixels": 8,
    "signal_min_range": 0.02,
    "whole_field_overexposure_fraction": 0.85,
    "overexposure_y": 0.98,
    "channel_clipping_level": 254 / 255,
    "adapted_old_brightness_ratio": True,
}
CONFIG_DOCUMENTATION = {
    "rgb": "decoded RGB code values divided by 255; encoding/profile not calibrated; no linear-light or radiometric calibration",
    "RD": "R / ((G+B)/2 + rd_epsilon), ratio; epsilon in decoded RGB fractions; PNG maps ratio/(1+ratio) monotonically; black=0 by algebra, not evidence of red signal",
    "RE": "R - (G+B)/2, signed decoded RGB code-value fraction; PNG maps (RE+1)/2",
    "Y": "0.5 R + 0.25 G + 0.25 B; decoded RGB code-value brightness proxy, not radiometric luminance",
    "normalization": "bilinear decoded RGB sample at cx+u*radius, cy+v*radius; u/v in annotated radii",
    "gradient": "least-squares Y = intercept + gx*u + gy*v inside valid annotated circle, excluding glint candidates",
    "angle": "atan2(v,u), degrees clockwise from decoded-image right; y down; metadata not applied",
    "polar": "radial bin centers (i+0.5)/16 and angular bin centers (j+0.5)*360/72; bilinear Y; missing=null",
    "candidate": "connected positive Y or RE deviations from pupil medians above max(configured MAD multiplier*scaled MAD,configured contrast floor), touching configured boundary annulus; glints excluded",
    "glint": "small connected high-Y low-chroma components; unverified specular candidates, not all bright pixels",
    "ADAPTED_OLD": "per-eye adaptation of legacy weighted (.5R+.25G+.25B) top/bottom versus middle contrast; inner radius=.85 annotation radius; segments +/- .25 inner radius; legacy ratio round(clamp(.08+1.75*contrast,.08,.6),2), with no absent-segment numeric fallback; original pools both eyes. Uniform signal has legacy floor .08, NOT detected crescent area",
    "annotation_conflict": "OD/OS circles conflict when center distance < radius_OD + radius_OS (positive disk intersection); external boundary tangency is allowed; both become INCONCLUSIVE diagnostics only",
    "scope": "candidate heuristics not scientifically verified; manual circles are annotations; clinical gradability, uncertainty and predictions unavailable",
}


def _finite_number(value: Any, name: str) -> float:
    if isinstance(value, (bool, str)) or not isinstance(value, (int, float, np.integer, np.floating)):
        raise ValueError(f"{name} must be a finite number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    return number


def _config(config: dict | None) -> dict:
    if config is not None and not isinstance(config, dict):
        raise ValueError("config must be an object or null")
    result = DEFAULT_CONFIG.copy()
    for key, value in (config or {}).items():
        if key not in result:
            raise ValueError(f"unknown config key: {key}")
        if key == "adapted_old_brightness_ratio":
            if not isinstance(value, bool):
                raise ValueError(f"{key} must be boolean")
        elif key in {"normalized_size", "polar_radial_bins", "polar_angular_bins", "candidate_min_component_pixels"}:
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{key} must be integer")
        else:
            value = _finite_number(value, key)
        result[key] = value
    if not (33 <= result["normalized_size"] <= 513 and result["normalized_size"] % 2 == 1):
        raise ValueError("normalized_size must be odd in [33,513]")
    if not 1 <= result["crop_extent_radii"] <= 3:
        raise ValueError("crop_extent_radii must be in [1,3]")
    if result["polar_radial_bins"] != 16 or result["polar_angular_bins"] != 72:
        raise ValueError("polar representation is fixed at 16 radial by 72 angular bins")
    if not 1 <= result["candidate_min_component_pixels"] <= result["normalized_size"] ** 2:
        raise ValueError("invalid candidate_min_component_pixels")
    for key in ("rd_epsilon", "glint_min_y", "glint_max_chroma", "glint_max_pupil_fraction", "candidate_boundary_radius", "candidate_min_contrast", "signal_min_range", "whole_field_overexposure_fraction", "overexposure_y", "channel_clipping_level"):
        if not 0 < result[key] <= 1:
            raise ValueError(f"{key} must be in (0,1]")
    if result["rd_epsilon"] < 1e-12:
        raise ValueError("rd_epsilon must be at least 1e-12 to preserve finite ratios")
    if not 0 < result["candidate_mad_multiplier"] <= 20:
        raise ValueError("candidate_mad_multiplier must be in (0,20]")
    return result


def _annotation(value: Any, eye: str) -> dict | None:
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != {"cx_px", "cy_px", "radius_px", "source"}:
        raise ValueError(f"{eye} must be a manual circle with cx_px, cy_px, radius_px, source")
    if value["source"] != "MANUAL_ANNOTATION":
        raise ValueError(f"{eye} source must be MANUAL_ANNOTATION")
    result = {key: _finite_number(value[key], f"{eye}.{key}") for key in ("cx_px", "cy_px", "radius_px")}
    if result["radius_px"] <= 0:
        raise ValueError(f"{eye}.radius_px must be positive")
    result["source"] = value["source"]
    return result


def _measurement(value, unit: str | None) -> dict:
    return {"value": value, "unit": unit}


def _components(mask: np.ndarray) -> list[np.ndarray]:
    """8-neighbor connected components; deterministic row-major traversal."""
    seen = np.zeros(mask.shape, dtype=bool)
    height, width = mask.shape
    result = []
    for y, x in zip(*np.nonzero(mask)):
        if seen[y, x]:
            continue
        pending, points = [(int(y), int(x))], []
        seen[y, x] = True
        while pending:
            py, px = pending.pop()
            points.append((py, px))
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    ny, nx = py + dy, px + dx
                    if 0 <= ny < height and 0 <= nx < width and mask[ny, nx] and not seen[ny, nx]:
                        seen[ny, nx] = True
                        pending.append((ny, nx))
        result.append(np.asarray(points, dtype=int))
    return result


def _sample(rgb: np.ndarray, xs: np.ndarray, ys: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    height, width = rgb.shape[:2]
    valid = (xs >= 0) & (xs <= width - 1) & (ys >= 0) & (ys <= height - 1)
    # Clip before conversion, so very distant finite annotations never overflow.
    cx, cy = np.clip(xs, 0, width - 1), np.clip(ys, 0, height - 1)
    x0, y0 = np.floor(cx).astype(int), np.floor(cy).astype(int)
    x1, y1 = np.minimum(x0 + 1, width - 1), np.minimum(y0 + 1, height - 1)
    fx, fy = cx - x0, cy - y0
    if rgb.ndim == 3:
        fx, fy = fx[..., None], fy[..., None]
    out = ((1-fx)*(1-fy)*rgb[y0,x0] + fx*(1-fy)*rgb[y0,x1] + (1-fx)*fy*rgb[y1,x0] + fx*fy*rgb[y1,x1])
    out[~valid] = 0
    return out, valid


def _save(out: Path, name: str, values: np.ndarray, mask: bool = False) -> str:
    if mask:
        data = values.astype(np.uint8) * 255
    else:
        data = np.rint(np.clip(values, 0, 1) * 255).astype(np.uint8)
    Image.fromarray(data).save(out / name, format="PNG", compress_level=9)
    return name


def _empty(reason: str) -> dict:
    measurements = {key: _measurement(None, unit) for key, unit in {
        "annotation_cx": "decoded_pixel", "annotation_cy": "decoded_pixel", "annotation_radius": "decoded_pixel",
        "valid_pupil_fraction": "fraction", "mean_Y": "sRGB_code_value_fraction", "mean_RD": "ratio",
        "mean_RE": "sRGB_code_value_fraction", "pupil_clipped_channel_fraction": "fraction", "pupil_overexposure_fraction": "fraction",
        "gradient_x": "Y_fraction_per_annotated_radius", "gradient_y": "Y_fraction_per_annotated_radius",
        "gradient_magnitude": "Y_fraction_per_annotated_radius", "gradient_angle": "degree_clockwise_from_image_right",
        "candidate_crescent_fraction": "fraction_of_valid_annotated_circle", "glint_candidate_fraction": "fraction_of_valid_annotated_circle",
        "ADAPTED_OLD_brightness_ratio": "ratio", "clinical_gradability": None,
        "whole_image_clipped_channel_fraction": "fraction", "whole_image_overexposure_fraction": "fraction",
        "raw_crop_origin_x": "decoded_pixel", "raw_crop_origin_y": "decoded_pixel", "raw_crop_width": "decoded_pixel", "raw_crop_height": "decoded_pixel",
        "normalized_grid_step": "annotated_radius_per_normalized_pixel", "glint_candidate_component_count": "count",
        "candidate_crescent_component_count": "count", "candidate_Y_baseline": "sRGB_code_value_fraction", "candidate_Y_threshold": "sRGB_code_value_fraction",
        "candidate_RE_baseline": "sRGB_code_value_fraction", "candidate_RE_threshold": "sRGB_code_value_fraction", "feature_signal_range": "sRGB_code_value_fraction",
        "laplacian_variance": "Y_fraction_squared_per_normalized_pixel_fourth", "gradient_intercept": "Y_fraction", "gradient_fit_rmse": "Y_fraction",
        "polar_Y": "sRGB_code_value_fraction", "polar_angle_centers": "degree_clockwise_from_image_right", "polar_radius_centers": "annotated_radius",
        "ADAPTED_OLD_relative_contrast": "ratio",
    }.items()}
    return {"status": "INCONCLUSIVE", "reasons": [reason], "measurements": measurements, "artifacts": {}, "feature_validity": "UNAVAILABLE", "artifact_validity": "UNAVAILABLE", "prediction": None, "uncertainty": None}


def analyze_frame(image_path: Path, eyes: dict, output_dir: Path, config: dict | None = None) -> dict:
    """Analyze independent manually annotated eyes and save deterministic PNGs.

    Inputs are validated before writing. Missing eyes remain INCONCLUSIVE with null
    measurements. Pixel features are not disease, refraction or gradability claims.
    """
    cfg = _config(config)
    if not isinstance(eyes, dict) or set(eyes) != {"OD", "OS"}:
        raise ValueError("eyes must contain exactly OD and OS (null is allowed)")
    annotations = {eye: _annotation(eyes[eye], eye) for eye in ("OD", "OS")}
    with Image.open(image_path) as source:
        if source.format not in {"PNG", "JPEG"}:
            raise ValueError("only decoded PNG or JPEG images are supported")
        if source.width * source.height > 40_000_000:
            raise ValueError("image exceeds 40 million pixels")
        if "A" in source.getbands() or "transparency" in source.info:
            raise ValueError("transparent images are unsupported; import opaque decoded RGB")
        rgb = np.asarray(source.convert("RGB"), dtype=np.float64) / 255
    for annotation in annotations.values():
        if annotation is not None:
            bound = max(rgb.shape[:2]) * 1000
            if annotation["radius_px"] > bound or abs(annotation["cx_px"]) > bound or abs(annotation["cy_px"]) > bound:
                raise ValueError("annotation coordinates/radius exceed supported image-relative domain")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    whole_y = rgb @ np.array([0.5, 0.25, 0.25])
    whole_clipping = float(np.mean(np.any(rgb >= cfg["channel_clipping_level"], axis=2)))
    whole_overexposure = float(np.mean(whole_y >= cfg["overexposure_y"]))
    records = {}
    for eye, annotation in annotations.items():
        if annotation is None:
            records[eye] = _empty("MISSING_MANUAL_ANNOTATION")
            continue
        records[eye] = _analyze_eye(rgb, annotation, eye, out, cfg, whole_clipping, whole_overexposure)
    if annotations["OD"] is not None and annotations["OS"] is not None:
        od, os = annotations["OD"], annotations["OS"]
        distance = math.hypot(od["cx_px"]-os["cx_px"], od["cy_px"]-os["cy_px"])
        if distance < od["radius_px"] + os["radius_px"]:
            for record in records.values():
                record["status"] = "INCONCLUSIVE"
                record["reasons"].append("ANATOMICAL_ANNOTATION_CONFLICT")
                record["feature_validity"] = "INVALID_OVERLAPPING_ANATOMICAL_MANUAL_ANNOTATIONS"
                record["artifact_validity"] = "DIAGNOSTIC_ONLY_ANATOMICAL_ANNOTATION_CONFLICT"
                record["annotation_conflict"] = {"center_distance_px":distance,"sum_radii_px":od["radius_px"]+os["radius_px"],"criterion":"center_distance < sum_radii; external tangency allowed"}
                for measurement in record["measurements"].values():
                    measurement["validity"] = "DIAGNOSTIC_ONLY_ANATOMICAL_ANNOTATION_CONFLICT"
    return {"algorithm_id": ALGORITHM_ID, "algorithm_version": ALGORITHM_VERSION,
            "config": cfg, "feature_definitions": CONFIG_DOCUMENTATION.copy(), "eyes": records}


def _analyze_eye(rgb, annotation, eye, out, cfg, whole_clipping, whole_overexposure):
    cx, cy, radius = (annotation[k] for k in ("cx_px", "cy_px", "radius_px"))
    height, width = rgb.shape[:2]
    # Reject numeric overflow domains before computing coordinates or crop limits.
    if radius > max(height, width) * 1000 or abs(cx) > max(height, width) * 1000 or abs(cy) > max(height, width) * 1000:
        raise ValueError("annotation coordinates/radius exceed supported image-relative domain")
    n, extent = cfg["normalized_size"], cfg["crop_extent_radii"]
    axis = np.linspace(-extent, extent, n)
    u, v = np.meshgrid(axis, axis)
    normalized, valid = _sample(rgb, cx + u * radius, cy + v * radius)
    radial = np.hypot(u, v)
    pupil_circle = radial <= 1
    pupil = pupil_circle & valid
    count = int(pupil.sum())
    record = _empty("NO_VALID_ANNOTATED_CIRCLE_PIXELS")
    m, artifacts = record["measurements"], record["artifacts"]
    record["annotation_source"] = "MANUAL_ANNOTATION"
    record["annotation_geometry"] = "user_supplied_circle_not_measured_pupil_fit"
    for key, value in (("annotation_cx", cx), ("annotation_cy", cy), ("annotation_radius", radius)):
        m[key]["value"] = value
    m["valid_pupil_fraction"]["value"] = float(count / pupil_circle.sum())
    m["whole_image_clipped_channel_fraction"] = _measurement(whole_clipping, "fraction")
    m["whole_image_overexposure_fraction"] = _measurement(whole_overexposure, "fraction")
    if count < 3:
        record["feature_validity"] = "INVALID_OUT_OF_FIELD_OR_INSUFFICIENT_SAMPLED_MANUAL_ANNOTATION"
        for measurement in m.values():
            measurement["validity"] = "DIAGNOSTIC_ONLY_INVALID_MANUAL_ANNOTATION"
        return record
    record["status"], record["reasons"] = "FEATURES_COMPUTED", []
    if not np.all(valid[pupil_circle]):
        record["status"] = "INCONCLUSIVE"
        record["feature_validity"] = "INVALID_EDGE_CLIPPED_MANUAL_ANNOTATION"
        record["reasons"].append("ANNOTATED_CIRCLE_EDGE_CLIPPED_DIAGNOSTICS_ONLY")
    x0, y0 = max(0, math.floor(cx-extent*radius)), max(0, math.floor(cy-extent*radius))
    x1, y1 = min(width, math.ceil(cx+extent*radius)+1), min(height, math.ceil(cy+extent*radius)+1)
    if x1 <= x0 or y1 <= y0:
        return _empty("NO_INTERSECTING_CROP")
    for key, value in (("raw_crop_origin_x",x0),("raw_crop_origin_y",y0),("raw_crop_width",x1-x0),("raw_crop_height",y1-y0)):
        m[key] = _measurement(value,"decoded_pixel")
    m["normalized_grid_step"] = _measurement(2*extent/(n-1),"annotated_radius_per_normalized_pixel")
    artifacts["raw_crop"] = _save(out, f"{eye}_raw_crop.png", rgb[y0:y1,x0:x1])
    artifacts["normalized_crop"] = _save(out, f"{eye}_normalized_crop.png", normalized)
    artifacts["pupil_mask"] = _save(out, f"{eye}_pupil_mask.png", pupil, True)
    artifacts["sampling_valid_mask"] = _save(out, f"{eye}_sampling_valid_mask.png", valid, True)
    red = normalized[:,:,0]
    other_mean = (normalized[:,:,1] + normalized[:,:,2]) / 2
    rd = red / (other_mean + cfg["rd_epsilon"])
    re = red - other_mean
    y = normalized @ np.array([0.5, 0.25, 0.25])
    for key, values in (("RD",rd/(1+rd)), ("RE",(re+1)/2), ("Y",y)):
        values = values.copy()
        values[~pupil] = 0
        artifacts[key] = _save(out, f"{eye}_{key}.png", values)
    # High brightness alone never identifies glint: size and chroma restrict candidates.
    bright = pupil & (y >= cfg["glint_min_y"])
    neutral = np.ptp(normalized, axis=2) <= cfg["glint_max_chroma"]
    glints = np.zeros_like(pupil)
    glint_count = 0
    for component in _components(bright & neutral):
        if len(component) <= cfg["glint_max_pupil_fraction"] * count:
            glints[component[:,0],component[:,1]] = True
            glint_count += 1
    artifacts["bright_region_mask"] = _save(out, f"{eye}_bright_region_mask.png", bright, True)
    artifacts["glint_candidate_mask"] = _save(out, f"{eye}_glint_candidate_mask.png", glints, True)
    analysis_mask = pupil & ~glints
    artifacts["feature_analysis_mask"] = _save(out, f"{eye}_feature_analysis_mask.png", analysis_mask, True)
    m["glint_candidate_fraction"]["value"] = float(glints.sum()/count)
    m["glint_candidate_component_count"] = _measurement(glint_count, "count")
    m["mean_Y"]["value"] = float(y[pupil].mean())
    m["mean_RD"]["value"] = float(rd[pupil].mean())
    m["mean_RE"]["value"] = float(re[pupil].mean())
    m["pupil_clipped_channel_fraction"]["value"] = float(np.mean(np.any(normalized[pupil] >= cfg["channel_clipping_level"], axis=1)))
    m["pupil_overexposure_fraction"]["value"] = float(np.mean(y[pupil] >= cfg["overexposure_y"]))
    # Finite-difference blur proxy, only where all neighbors are valid pupil pixels.
    inner = pupil[1:-1,1:-1] & pupil[:-2,1:-1] & pupil[2:,1:-1] & pupil[1:-1,:-2] & pupil[1:-1,2:]
    lap = y[:-2,1:-1]+y[2:,1:-1]+y[1:-1,:-2]+y[1:-1,2:]-4*y[1:-1,1:-1]
    m["laplacian_variance"] = _measurement(float(np.var(lap[inner])) if inner.any() else None, "Y_fraction_squared_per_normalized_pixel_fourth")
    candidate = np.zeros_like(pupil)
    threshold_mask = np.zeros_like(pupil)
    boundary = pupil & (radial >= cfg["candidate_boundary_radius"])
    thresholds = {}
    ranges = []
    for name, values in (("Y",y),("RE",re)):
        samples = values[analysis_mask]
        if samples.size:
            median = float(np.median(samples))
            mad = float(np.median(np.abs(samples-median))) * 1.4826
            threshold = max(cfg["candidate_min_contrast"], cfg["candidate_mad_multiplier"]*mad)
            thresholds[name] = (median, threshold)
            ranges.append(float(np.ptp(samples)))
            threshold_mask |= analysis_mask & ((values-median) > threshold)
            m[f"candidate_{name}_baseline"] = _measurement(median, "sRGB_code_value_fraction")
            m[f"candidate_{name}_threshold"] = _measurement(threshold, "sRGB_code_value_fraction")
    signal_range = max(ranges) if ranges else 0.
    m["feature_signal_range"] = _measurement(signal_range, "sRGB_code_value_fraction")
    if signal_range < cfg["signal_min_range"]:
        threshold_mask[:] = False
        record["reasons"].append("NO_FEATURE_VARIATION_ABOVE_CONFIGURED_FLOOR")
    if whole_overexposure >= cfg["whole_field_overexposure_fraction"]:
        record["reasons"].append("WHOLE_IMAGE_OVEREXPOSURE_HEURISTIC_TRIGGERED")
    if m["pupil_overexposure_fraction"]["value"] >= cfg["whole_field_overexposure_fraction"]:
        threshold_mask[:] = False
        record["reasons"].append("ANNOTATED_CIRCLE_OVEREXPOSURE_HEURISTIC_TRIGGERED")
    component_count = 0
    for component in _components(threshold_mask):
        yy, xx = component[:,0], component[:,1]
        if len(component) >= cfg["candidate_min_component_pixels"] and np.any(boundary[yy,xx]):
            candidate[yy,xx] = True
            component_count += 1
    for name, values in (("adaptive_threshold_mask",threshold_mask), ("boundary_annulus_mask",boundary), ("candidate_crescent_mask",candidate)):
        artifacts[name] = _save(out, f"{eye}_{name}.png", values, True)
    m["candidate_crescent_fraction"]["value"] = float(candidate.sum()/count)
    m["candidate_crescent_component_count"] = _measurement(component_count, "count")
    # Least-squares coefficients retain directional sign; no fit uncertainty inference.
    gradient_image = np.full_like(y, 0.5)
    if analysis_mask.sum() >= 3:
        design = np.column_stack((np.ones(int(analysis_mask.sum())),u[analysis_mask],v[analysis_mask]))
        beta, _, rank, _ = np.linalg.lstsq(design, y[analysis_mask], rcond=None)
        if rank == 3:
            intercept, gx, gy = map(float,beta)
            magnitude = math.hypot(gx, gy)
            # Quantization/noise floor is not applied to nonzero gradients.
            if magnitude <= 1e-14:
                gx = gy = magnitude = 0.
            m["gradient_x"]["value"],m["gradient_y"]["value"] = gx,gy
            m["gradient_magnitude"]["value"] = magnitude
            m["gradient_angle"]["value"] = math.degrees(math.atan2(gy,gx)) % 360 if magnitude else None
            m["gradient_intercept"] = _measurement(intercept,"Y_fraction")
            residual = y[analysis_mask] - design @ beta
            m["gradient_fit_rmse"] = _measurement(float(np.sqrt(np.mean(residual**2))),"Y_fraction")
            gradient_image = 0.5 + (gx*u+gy*v)/2
    gradient_image[~pupil] = 0
    artifacts["gradient"] = _save(out, f"{eye}_gradient.png", gradient_image)
    radii = (np.arange(16)+0.5)/16
    angles = (np.arange(72)+0.5)*2*np.pi/72
    px, py = radii[:,None]*np.cos(angles), radii[:,None]*np.sin(angles)
    polar_rgb, polar_valid = _sample(rgb,cx+radius*px,cy+radius*py)
    polar_y = polar_rgb @ np.array([0.5,0.25,0.25])
    # Mask glint locations conservatively via nearest normalized sample.
    nx = np.rint((px+extent)/(2*extent)*(n-1)).astype(int)
    ny = np.rint((py+extent)/(2*extent)*(n-1)).astype(int)
    polar_valid &= ~glints[ny,nx]
    polar_y[~polar_valid] = 0
    artifacts["polar"] = _save(out,f"{eye}_polar.png",polar_y)
    artifacts["polar_valid_mask"] = _save(out,f"{eye}_polar_valid_mask.png",polar_valid,True)
    m["polar_Y"] = _measurement([[float(polar_y[i,j]) if polar_valid[i,j] else None for j in range(72)] for i in range(16)],"sRGB_code_value_fraction")
    m["polar_angle_centers"] = _measurement([(j+0.5)*360/72 for j in range(72)],"degree_clockwise_from_image_right")
    m["polar_radius_centers"] = _measurement(radii.tolist(),"annotated_radius")
    if cfg["adapted_old_brightness_ratio"]:
        old_signal = normalized @ np.array([0.5, 0.25, 0.25]) * 255
        old_mask = pupil & (radial <= 0.85)
        top = old_mask & (v < -0.85*0.25)
        bottom = old_mask & (v > 0.85*0.25)
        middle = old_mask & ~(top | bottom)
        if top.any() and bottom.any() and middle.any():
            avg_top, avg_bottom, avg_middle = (float(old_signal[mask].mean()) for mask in (top, bottom, middle))
            contrast = max(0., avg_top-avg_middle, avg_bottom-avg_middle) / max(1., avg_middle)
            m["ADAPTED_OLD_brightness_ratio"]["value"] = round(min(0.6, max(0.08, 0.08+1.75*contrast)), 2)
            m["ADAPTED_OLD_relative_contrast"] = _measurement(contrast, "ratio")
        else:
            m["ADAPTED_OLD_relative_contrast"] = _measurement(None, "ratio")
    record["reasons"].append("UNVALIDATED_CANDIDATE_FEATURES_MANUAL_CIRCLE_ONLY")
    if record["status"] == "INCONCLUSIVE":
        record["artifact_validity"] = "DIAGNOSTIC_ONLY_INVALID_MANUAL_ANNOTATION"
        for measurement in m.values():
            measurement["validity"] = "DIAGNOSTIC_ONLY_INVALID_MANUAL_ANNOTATION"
    else:
        record["feature_validity"] = "COMPUTED_UNVALIDATED_IMAGE_FEATURES"
        record["artifact_validity"] = "COMPUTED_UNVALIDATED_IMAGE_FEATURES"
    return record


def analyze_candidate_eye(rgb_uint8, candidate, eye, output_dir, config=None):
    """Additive automatic candidate adapter; equivalent-area circle is not a pupil measurement.

    Stage1 manual entry point and validation remain unchanged. The fitted ellipse is
    retained separately; circle-normalized features use its equivalent-area radius.
    """
    if candidate.get('source') != 'AUTOMATIC_CANDIDATE':
        raise ValueError('candidate source must be AUTOMATIC_CANDIDATE')
    cfg = _config(config)
    geometry = {key:_finite_number(candidate[key],key) for key in ('cx_px','cy_px','radius_px')}
    if geometry['radius_px'] <= 0: raise ValueError('candidate radius must be positive')
    rgb = np.asarray(rgb_uint8,dtype=np.float64)/255
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    y=rgb @ np.array([.5,.25,.25])
    record=_analyze_eye(rgb,geometry,eye,out,cfg,float(np.any(rgb>=cfg['channel_clipping_level'],axis=2).mean()),float((y>=cfg['overexposure_y']).mean()))
    record['annotation_source']='AUTOMATIC_CANDIDATE'
    record['annotation_geometry']='equivalent_area_circle_of_dark_component_ellipse_not_verified_pupil'
    record['observed_ellipse']=candidate.get('ellipse')
    record['reasons']=[reason.replace('MANUAL_ANNOTATION','AUTOMATIC_CANDIDATE').replace('MANUAL_CIRCLE_ONLY','AUTOMATIC_EQUIVALENT_AREA_CIRCLE') for reason in record['reasons']]
    record['feature_validity']='UNVALIDATED_AUTOMATIC_CANDIDATE_FEATURES' if record['status']=='FEATURES_COMPUTED' else 'INVALID_AUTOMATIC_CANDIDATE_DIAGNOSTICS_ONLY'
    return record
