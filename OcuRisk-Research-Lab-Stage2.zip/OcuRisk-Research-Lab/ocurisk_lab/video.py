"""Bounded local FFmpeg decoding with original presentation timestamps."""
import hashlib
import json
import subprocess
import time
from fractions import Fraction
from pathlib import Path
import numpy as np
from PIL import Image
from . import detection, optical, optical_compare, quality
SOURCE_SHA256_AT_IMPORT=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
MAX_PIXELS=16_000_000
MAX_FRAMES=10000

def _candidate_observation(rgb, candidate, output_dir, prefix, algorithms, frame):
    """Analyze an observed image-side circle without asserting anatomical identity."""
    out=Path(output_dir); temporary=out/f'_temporary_{prefix}'
    record=optical.analyze_candidate_eye(rgb,candidate,prefix,temporary)
    for key,name in list(record['artifacts'].items()):
        unique=f'{prefix}_{name}'
        (temporary/name).rename(out/unique); record['artifacts'][key]=unique
    temporary.rmdir()
    radius=candidate['radius_px']; cx=candidate['cx_px']; cy=candidate['cy_px']
    x0=max(0,int(np.floor(cx-radius))); y0=max(0,int(np.floor(cy-radius)))
    x1=min(rgb.shape[1],int(np.ceil(cx+radius))+1); y1=min(rgb.shape[0],int(np.ceil(cy+radius))+1)
    crop=rgb[y0:y1,x0:x1]
    circle={**candidate,'cx_px':cx-x0,'cy_px':cy-y0}
    comparisons=({a:{'status':'INCONCLUSIVE','reasons':record['reasons'],'value':None,'unit':None,'artifacts':{},'prediction':None} for a in algorithms}
                 if record['status']=='INCONCLUSIVE' else optical_compare.compare(crop,circle,out,prefix,algorithms))
    record.update(source='AUTOMATIC_CANDIDATE',candidate_status='UNCONFIRMED_IMAGE_CANDIDATE',
                  identity_status='UNRESOLVED_IMAGE_SIDE_CANDIDATE',detection_candidate=dict(candidate),
                  provenance={'source_frame_sha256':frame['sha256'],'source_file':frame['source_file'],
                              'optical_algorithm_id':optical.ALGORITHM_ID,'optical_algorithm_version':optical.ALGORITHM_VERSION,
                              'optical_config':optical._config(None),'comparison_algorithms':[a for a in optical_compare.registry() if a['algorithm_id'] in algorithms],
                              'comparison_crop_source_px':{'x':x0,'y':y0,'width':x1-x0,'height':y1-y0},
                              'comparison_mask_coordinates':'CROP_PIXELS_X_RIGHT_Y_DOWN',
                              'geometry_scope':'OBSERVED_EQUIVALENT_AREA_CIRCLE_NOT_VERIFIED_PUPIL'})
    return {'observation':record,'comparisons':comparisons}

def _rank_candidates(frames, config):
    """Transparent within-recording engineering ordering; every observation retained."""
    records=[]
    for frame in frames:
        if not frame['sampled']: continue
        metrics=frame['acquisition_quality']
        warnings=[]
        if metrics['clipped_high_fraction'] > config['warning_clipped_fraction']: warnings.append('HIGH_CODE_CLIPPING')
        if metrics['clipped_low_fraction'] > config['warning_clipped_fraction']: warnings.append('LOW_CODE_CLIPPING')
        threshold=config['minimum_laplacian_variance']
        if threshold is not None and metrics['laplacian_variance'] is not None and metrics['laplacian_variance']<threshold: warnings.append('BELOW_CONFIGURED_SHARPNESS_PROXY')
        threshold=config['maximum_frame_difference']
        if threshold is not None and metrics['frame_difference_mean'] is not None and metrics['frame_difference_mean']>threshold: warnings.append('ABOVE_CONFIGURED_FRAME_DIFFERENCE')
        for label, candidate in (frame.get('candidate_observations') or {}).items():
            observation=candidate['observation']
            reasons=list(observation.get('reasons',[]))
            rejected=observation.get('status')=='INCONCLUSIVE'
            records.append({'frame_index':frame['frame_index'],'candidate_label':label,'retained':True,'engineering_selection_status':'REJECTED_OBSERVATION' if rejected else 'CANDIDATE_ONLY','rejection_reasons':reasons if rejected else [],'diagnostic_warnings':warnings,'evidence':{'optical_status':observation.get('status'),'sharpness_proxy':metrics['laplacian_variance'],'clipped_high_fraction':metrics['clipped_high_fraction'],'clipped_low_fraction':metrics['clipped_low_fraction'],'frame_difference_mean':metrics['frame_difference_mean']}})
    records.sort(key=lambda r:(r['engineering_selection_status']=='REJECTED_OBSERVATION',len(r['diagnostic_warnings']),-(r['evidence']['sharpness_proxy'] or 0),r['frame_index'],r['candidate_label']))
    for rank,record in enumerate(records,1): record['engineering_rank']=rank
    return {'policy':'WITHIN_RECORDING_LEXICOGRAPHIC_V1','ordering':['non-inconclusive observation first','fewer configured frame diagnostics','descending frame sharpness proxy','frame index and candidate label'],'config':config,'records':records,'limitations':['Frame diagnostics use chart ROI when supplied, otherwise the full scene; they are not per-eye measurements.','All candidates and rejected frames are retained; rank is an unvalidated engineering heuristic, not retinal or clinical gradability.','Unresolved anatomy remains unresolved; sharpness can be noise.']}

def _source(path):
    path=Path(path).resolve(strict=True)
    if not path.is_file() or path.stat().st_size>256*1024*1024: raise ValueError('source must be local file <=256 MiB')
    return path

def _probe(path,frames=False):
    args=['ffprobe','-v','error','-protocol_whitelist','file,pipe','-probesize','5000000','-analyzeduration','5000000','-select_streams','v:0','-show_streams','-show_format']
    if frames: args+=['-read_intervals','%+#10001','-show_frames','-show_entries','frame=pts,best_effort_timestamp,pkt_duration']
    try: return json.loads(subprocess.run(args+['-of','json',str(path)],capture_output=True,timeout=30,check=True).stdout)
    except (subprocess.SubprocessError,json.JSONDecodeError) as error: raise ValueError('media probe failed') from error

def probe_media(source_path):
    path=_source(source_path); data=_probe(path); streams=data.get('streams',[])
    if len(streams)!=1: raise ValueError('no decodable video/image stream')
    stream=streams[0]; w=int(stream['width']); h=int(stream['height'])
    if w<=0 or h<=0 or w*h>MAX_PIXELS: raise ValueError('media dimensions exceed decoder bound')
    duration=float(stream.get('duration',data.get('format',{}).get('duration',0)) or 0)
    count=int(stream['nb_frames']) if stream.get('nb_frames','N/A').isdigit() else None
    if duration>600 or count and count>MAX_FRAMES: raise ValueError('media exceeds 600s/10000 frame bound')
    format_name=data.get('format',{}).get('format_name','')
    kind='IMAGE' if any(name in format_name.split(',') for name in ('image2','png_pipe','jpeg_pipe','webp_pipe','bmp_pipe')) else 'VIDEO'
    if kind=='VIDEO' and count is None:
        count=len(_probe(path,True).get('frames',[]))
        if count>MAX_FRAMES: raise ValueError('actual probed frame bound exceeded')
    return {'kind':kind,'width':w,'height':h,'frame_count':count if kind=='VIDEO' else 1,'time_base':stream.get('time_base'),'duration_seconds':duration or None,'rotation_metadata':stream.get('side_data_list',[]),'tags':stream.get('tags',{}),'rotation_applied':False,'format':format_name,'codec':stream.get('codec_name'),'stream_bit_rate':int(stream['bit_rate']) if str(stream.get('bit_rate','')).isdigit() else None,'format_bit_rate':int(data['format']['bit_rate']) if str(data.get('format',{}).get('bit_rate','')).isdigit() else None,'bit_rate_scope':'SAVED_STREAM_NOT_ORIGINAL_DROIDCAM_LINK','timing_scope':'MEDIA_PRESENTATION_NOT_SENSOR_TIME'}

def analyze_media(source_path,output_dir,*,media,options,progress=None,cancelled=None):
    path=_source(source_path); metadata=probe_media(path); source_hash=hashlib.sha256(path.read_bytes()).hexdigest()
    every=options.get('sample_every',1)
    if isinstance(every,bool) or not isinstance(every,int) or not 1<=every<=1000: raise ValueError('sample_every must be integer 1..1000')
    algorithms=options.get('algorithms',['BOUNDARY_Y_RE'])
    if not isinstance(algorithms,list) or not algorithms or any(not isinstance(a,str) or a not in optical_compare.IDS for a in algorithms): raise ValueError('invalid algorithms')
    capture_metadata=quality.validate_capture_metadata(options.get('capture_metadata'))
    quality_config=quality.validate_config(options.get('quality_config'))
    roi=(capture_metadata or {}).get('chart_roi')
    annotations=options.get('annotations',{})
    if not isinstance(annotations,dict): raise ValueError('annotations must be object')
    timing=_probe(path,True).get('frames',[])
    if len(timing)>MAX_FRAMES: raise ValueError('too many frames')
    for key,value in annotations.items():
        if not isinstance(key,str) or not key.isdigit() or str(int(key))!=key or int(key)>=len(timing): raise ValueError('annotation frame index nonexistent')
        if not isinstance(value,dict) or set(value)!={'OD','OS'}: raise ValueError('annotation requires OD/OS')
        for eye in ('OD','OS'): optical._annotation(value[eye],eye)
    out=Path(output_dir)
    out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()): raise ValueError('output directory must be empty')
    cmd=['ffmpeg','-v','error','-protocol_whitelist','file,pipe','-noautorotate','-i',str(path),'-map','0:v:0','-fps_mode','passthrough','-f','rawvideo','-pix_fmt','rgb24','pipe:1']
    process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    frames=[]; artifacts=[]; previous=[]; previous_rgb=None; status='COMPLETED'; error=None; frame_bytes=metadata['width']*metadata['height']*3
    modules={'video':SOURCE_SHA256_AT_IMPORT,'optical':optical.SOURCE_SHA256_AT_IMPORT,'detection':detection.SOURCE_SHA256_AT_IMPORT,'optical_compare':optical_compare.SOURCE_SHA256_AT_IMPORT,'quality':quality.SOURCE_SHA256_AT_IMPORT}
    provenance={'source_sha256':source_hash,'loaded_code_sha256':modules,'detection':detection.provenance(),'options':options,'ffmpeg_version':subprocess.run(['ffmpeg','-version'],capture_output=True,text=True,timeout=5).stdout.splitlines()[0],'scientific_scope':'UNVALIDATED_IMAGE_CANDIDATES_NO_RETINAL_OR_CLINICAL_ACCURACY'}
    last_checkpoint={'time':0.0,'frames':-1}
    def snapshot(state, failure=None):
        terminal=state != 'RUNNING'
        if not terminal and last_checkpoint['frames'] >= 0 and len(frames)-last_checkpoint['frames'] < 10 and time.monotonic()-last_checkpoint['time'] < 1.0:
            return None
        last_checkpoint.update(time=time.monotonic(),frames=len(frames))
        result={'status':state,'error':failure,'media_metadata':metadata,'frames':frames,'artifact_files':artifacts,'summary':{'decoded_frames':len(frames),'sampled_frames':sum(f['sampled'] for f in frames),'predictions_available':False},'provenance':{**provenance,'actual_bounds':{'width':metadata['width'],'height':metadata['height'],'decoded_frames':len(frames)}}}
        result['candidate_quality_ranking']=_rank_candidates(frames,quality_config) if terminal else None
        result['capture_metadata']=capture_metadata
        result['acquisition_quality']=None
        if terminal:
            result['acquisition_quality']=quality.summarize_quality([{'frame_index':f['frame_index'],'timestamp_ns':f['timestamp_ns'],'timestamp_source':f['timestamp_source'],'quality_metrics':f['acquisition_quality']} for f in frames], metadata, capture_metadata=capture_metadata, config=quality_config)
            result['acquisition_quality']['provenance']['source_sha256']=source_hash
        result['checkpoint_scope']='COMPLETE_DECODED_EVIDENCE' if terminal else 'PERIODIC_DECODED_EVIDENCE_SUMMARY_PENDING'
        temporary=out/'result.partial.tmp'
        temporary.write_text(json.dumps(result,allow_nan=False),encoding='utf-8')
        temporary.replace(out/'result.partial.json')
        return result
    try:
        snapshot('RUNNING')
        for index in range(MAX_FRAMES+1):
            if cancelled and cancelled(): status='CANCELLED'; break
            data=process.stdout.read(frame_bytes)
            if not data: break
            if len(data)!=frame_bytes or index>=MAX_FRAMES: raise ValueError('truncated frame or actual frame bound exceeded')
            if index>=len(timing): raise ValueError('decode/probe frame count disagreement')
            t=timing[index]; pts=t.get('pts',t.get('best_effort_timestamp')); estimated='pts' not in t
            if metadata['kind']=='IMAGE': pts=None
            ns=str(round(Fraction(int(pts))*Fraction(metadata['time_base'])*1_000_000_000)) if pts is not None else None
            filename=f'frame_{index:06d}.png'; rgb=np.frombuffer(data,dtype='uint8').reshape(metadata['height'],metadata['width'],3); Image.fromarray(rgb).save(out/filename); artifacts.append(filename)
            sampled=index%every==0 or str(index) in annotations
            frame={'frame_index':index,'pts':pts,'time_base':metadata['time_base'],'timestamp_ns':ns,'timestamp_source':('FFPROBE_BEST_EFFORT_ESTIMATED' if estimated else 'STREAM_PTS') if pts is not None else 'UNAVAILABLE','source_file':filename,'sha256':hashlib.sha256((out/filename).read_bytes()).hexdigest(),'sampled':sampled,'detection':None,'quality':None,'eyes':None,'comparisons':None}
            frame['acquisition_quality']=quality.frame_metrics(rgb, previous_rgb=previous_rgb, roi=roi, config=quality_config)
            previous_rgb=rgb.copy()
            frame['candidate_observations']=None
            frame['analysis_status']='PENDING' if sampled else 'SKIPPED'
            frames.append(frame)
            snapshot('RUNNING')
            if sampled:
                found=detection.detect(rgb,mirrored=media.get('mirrored'),upright_confirmed=options.get('upright_confirmed',False) is True,identity_confirmed=options.get('identity_confirmed',False) is True,previous=previous); previous=found['candidates']
                for candidate_index,candidate in enumerate(previous):
                    if candidate['track_id'] is None: candidate['track_id']=f'frame_{index}_candidate_{candidate_index}'
                frame['detection']=found; frame['quality']=found['quality']; manual=annotations.get(str(index),{'OD':None,'OS':None})
                frame['candidate_observations']={}
                for candidate_index,candidate in enumerate(found['candidates']):
                    label=f"IMAGE_{candidate['image_side']}"
                    if label in frame['candidate_observations']: label=f'{label}_{candidate_index+1}'
                    observation=_candidate_observation(rgb,candidate,out,f'frame_{index:06d}_{label}',algorithms,frame)
                    frame['candidate_observations'][label]=observation
                    artifacts.extend(observation['observation']['artifacts'].values())
                    for comparison in observation['comparisons'].values(): artifacts.extend(comparison['artifacts'].values())
                eyes={}; comparisons={}
                prepared_manual={}
                if any(manual.values()):
                    manual_dir=out/f'_temporary_manual_{index}'
                    prepared_manual=optical.analyze_frame(out/filename,manual,manual_dir)['eyes']
                    for manual_eye,manual_record in prepared_manual.items():
                        for artifact_key,artifact_name in manual_record['artifacts'].items():
                            unique=f'frame_{index:06d}_{manual_eye}_{artifact_name}'
                            (manual_dir/artifact_name).rename(out/unique); manual_record['artifacts'][artifact_key]=unique; artifacts.append(unique)
                    manual_dir.rmdir()
                for eye in ('OD','OS'):
                    circle=manual[eye] or found['eyes'][eye]
                    if circle is None: eyes[eye]=optical._empty('NO_RESOLVED_EYE_OBSERVATION'); continue
                    # Stage1 remains strictly manual; automatic masks use their own provenance.
                    sub=out/f'_temporary_{index}_{eye}'
                    if manual[eye]:
                        result=prepared_manual[eye]
                    else:
                        result=optical.analyze_candidate_eye(rgb,circle,eye,sub)
                    for key,name in ([] if manual[eye] else list(result['artifacts'].items())):
                        unique=f'frame_{index:06d}_{eye}_{name}'; (sub/name).rename(out/unique); result['artifacts'][key]=unique; artifacts.append(unique)
                    if sub.exists(): sub.rmdir()
                    eyes[eye]=result
                    eyes[eye]['annotation_source']=circle['source']; eyes[eye]['identity_status']='MANUAL_ASSERTION' if manual[eye] else found['identity_status']
                    comparisons[eye]=({a:{'status':'INCONCLUSIVE','reasons':result['reasons'],'value':None,'unit':None,'artifacts':{},'prediction':None} for a in algorithms} if result['status']=='INCONCLUSIVE' else optical_compare.compare(rgb,circle,out,f'frame_{index:06d}_{eye}',algorithms))
                    for result in comparisons[eye].values(): artifacts.extend(result['artifacts'].values())
                frame['eyes']=eyes; frame['comparisons']=comparisons
            else: frame['skip_reason']='EXPLICIT_SAMPLE_EVERY'; previous=[]
            frame['analysis_status']='COMPLETED' if sampled else 'SKIPPED'
            snapshot('RUNNING')
            if progress: progress({'done':len(frames),'total':len(timing),'stage':'DECODING_AND_ANALYSIS'})
        if status=='COMPLETED' and process.wait(timeout=15)!=0: raise ValueError('FFmpeg decode failed')
        if status=='COMPLETED' and len(frames)!=len(timing): raise ValueError('decode/probe frame count disagreement')
    except Exception as failure:
        status='FAILED'; error=f'{type(failure).__name__}: {failure}'
    finally:
        if process.poll() is None: process.terminate()
        try: process.wait(timeout=3)
        except subprocess.TimeoutExpired: process.kill(); process.wait()
        process.stdout.close()
    if hashlib.sha256(path.read_bytes()).hexdigest()!=source_hash: status='FAILED'; error='source changed during processing'
    for name,module in [('video',__file__),('optical',optical.__file__),('detection',detection.__file__),('optical_compare',optical_compare.__file__),('quality',quality.__file__)]:
        if hashlib.sha256(Path(module).read_bytes()).hexdigest()!=modules[name]:
            status='FAILED'; error='loaded module source changed during processing'
    return snapshot(status,error)
