"""Strict, dependency-free capture validation. No missing measurement is imputed."""
import math
import re


class ValidationError(ValueError):
    pass


ID = re.compile(r"[A-Za-z0-9_-]{1,80}\Z")
FILENAME = re.compile(r"[A-Za-z0-9_-][A-Za-z0-9_.-]{0,119}\.(?:png|jpg|jpeg)\Z", re.I)
SHA = re.compile(r"[0-9a-f]{64}\Z")
MAX_FRAMES = 128


def require(condition, message):
    if not condition:
        raise ValidationError(message)


def valid_id(value):
    return isinstance(value, str) and ID.fullmatch(value) is not None


def number(value, positive=False):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value) and (not positive or value > 0)
    except OverflowError:
        return False


def finite_tree(value, depth=0):
    require(depth <= 12, "JSON nesting exceeds limit")
    if value is None or type(value) is bool:
        return
    if type(value) in (int, float):
        require(number(value), "Numbers must be finite")
    elif isinstance(value, str):
        require(len(value) <= 4096, "String exceeds limit")
    elif isinstance(value, list):
        require(len(value) <= 4096, "List exceeds limit")
        for item in value:
            finite_tree(item, depth + 1)
    elif isinstance(value, dict):
        require(len(value) <= 512, "Object exceeds limit")
        for key, item in value.items():
            require(isinstance(key, str), "JSON keys must be strings")
            finite_tree(item, depth + 1)
    else:
        raise ValidationError("Value is not JSON serializable")


def fields(obj, names, label):
    require(isinstance(obj, dict), f"{label} must be an object")
    require(set(obj) == set(names.split()), f"{label} fields must be: {names}")


def validate_manifest(manifest):
    finite_tree(manifest)
    fields(manifest, "schema_version capture_id participant_id session_id device_id mode data_origin approval_reference illumination distance_m phone_pose head_pose mirrored image_rotation_deg timestamp_source frames", "manifest")
    require(manifest['schema_version'] == '1.0', "Unsupported schema_version")
    for key in ('capture_id', 'participant_id', 'session_id', 'device_id'):
        require(valid_id(manifest[key]), f"Invalid {key}")
    require(manifest['mode'] in ('CONTROL', 'VIDEO_RIGHT', 'VIDEO_LEFT', 'HEAD_TURN'), "Invalid mode")
    require(manifest['data_origin'] in ('NON_HUMAN_TEST', 'SYNTHETIC', 'REAL_APPROVED'), "Invalid data_origin")
    approval = manifest['approval_reference']
    require(approval is None or isinstance(approval, str) and 0 < len(approval.strip()) <= 512, "Invalid approval_reference")
    if manifest['data_origin'] == 'REAL_APPROVED':
        require(approval is not None, "REAL_APPROVED requires approval_reference")
    light = manifest['illumination']
    fields(light, 'requested reported physical_verified evidence_id', 'illumination')
    for key in ('requested', 'reported'):
        require(light[key] in ('OFF', 'FLASH', 'TORCH', 'UNKNOWN'), f"Invalid illumination {key}")
    require(type(light['physical_verified']) is bool, "physical_verified must be boolean")
    require(light['evidence_id'] is None or valid_id(light['evidence_id']), "Invalid evidence_id")
    require(not light['physical_verified'] or light['evidence_id'] is not None, "Physical verification assertion requires evidence_id")
    require(manifest['distance_m'] is None or number(manifest['distance_m'], positive=True), "distance_m must be positive finite or null")
    for key in ('phone_pose', 'head_pose'):
        require(manifest[key] is None or isinstance(manifest[key], dict), f"{key} must be object or null")
    require(manifest['mirrored'] is None or type(manifest['mirrored']) is bool, "mirrored must be boolean or null")
    rotation = manifest['image_rotation_deg']
    require(rotation is None or type(rotation) is int and rotation in (0, 90, 180, 270), "Invalid image_rotation_deg")
    require(isinstance(manifest['timestamp_source'], str) and 0 < len(manifest['timestamp_source'].strip()) <= 120, "Invalid timestamp_source")
    frames = manifest['frames']
    require(isinstance(frames, list) and 1 <= len(frames) <= MAX_FRAMES, f"frames must contain 1–{MAX_FRAMES} entries")
    indices, names, hashes = set(), set(), set()
    previous = None
    for frame in frames:
        fields(frame, 'frame_index timestamp_ns source_file sha256 eyes', 'frame')
        index = frame['frame_index']
        require(type(index) is int and 0 <= index <= 2147483647 and index not in indices, "frame_index must be a unique nonnegative integer")
        indices.add(index)
        name = frame['source_file']
        require(isinstance(name, str) and FILENAME.fullmatch(name) is not None and name not in names, "source_file must be a unique PNG/JPEG basename")
        names.add(name)
        digest = frame['sha256']
        require(isinstance(digest, str) and SHA.fullmatch(digest) is not None and digest not in hashes, "sha256 must be a unique lowercase SHA256")
        hashes.add(digest)
        timestamp = frame['timestamp_ns']
        require(timestamp is None or isinstance(timestamp, str) and re.fullmatch(r'[0-9]{1,30}', timestamp) is not None, "timestamp_ns must be decimal string or null")
        if timestamp is not None:
            current = int(timestamp)
            require(previous is None or current > previous, "Known timestamps must be strictly increasing")
            previous = current
        fields(frame['eyes'], 'OD OS', 'eyes')
        for eye, pupil in frame['eyes'].items():
            if pupil is None:
                continue
            fields(pupil, 'cx_px cy_px radius_px source', f'{eye} pupil')
            require(number(pupil['cx_px']) and number(pupil['cy_px']), "Circle coordinates must be finite")
            require(number(pupil['radius_px'], positive=True), "Circle radius must be positive finite")
            require(pupil['source'] == 'MANUAL_ANNOTATION', "Pupil source must be MANUAL_ANNOTATION")
    return manifest
