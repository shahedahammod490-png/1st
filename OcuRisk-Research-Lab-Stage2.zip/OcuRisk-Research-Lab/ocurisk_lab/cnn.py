"""Optional bounded CPU CNN/hybrid regression, Python API only.
Images are supplied as bytes, never caller-selected external server paths.
"""
import base64
import hashlib
import io
import json
import uuid
from pathlib import Path
import numpy as np
from PIL import Image

LOADED_SOURCE_HASH=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def availability():
    try: import torch; reason=None
    except ImportError: reason='PyTorch is not installed; optional CPU dependency required'
    return [{'algorithm':a,'algorithm_id':a,'status':'NOT_TRAINED' if reason is None else 'UNAVAILABLE','reason':reason,'clinical_status':'AWAITING_REFERENCE_DATA','interface':'Python only'} for a in ('CNN','HYBRID')]

def dependency():
    try: import torch; return torch
    except ImportError as exc: raise RuntimeError('UNAVAILABLE: PyTorch is not installed') from exc

def network(torch,n_features):
    class Compact(torch.nn.Module):
        def __init__(self):
            super().__init__(); self.conv=torch.nn.Sequential(torch.nn.Conv2d(3,8,3,padding=1),torch.nn.ReLU(),torch.nn.MaxPool2d(2),torch.nn.Conv2d(8,16,3,padding=1),torch.nn.ReLU(),torch.nn.AdaptiveAvgPool2d(1)); self.head=torch.nn.Linear(16+n_features,1)
        def forward(self,image,features): return self.head(torch.cat([self.conv(image).flatten(1),features],1)).flatten()
    return Compact()

def images_tensor(torch, images):
    arrays=[]
    for raw in images:
        if not isinstance(raw,bytes) or not 1<=len(raw)<=16*1024*1024: raise ValueError('bounded image bytes required')
        with Image.open(io.BytesIO(raw)) as image:
            if image.width*image.height>16000000: raise ValueError('image dimensions exceed limit')
            arrays.append(np.asarray(image.convert('RGB').resize((32,32)),dtype=np.float32).transpose(2,0,1)/255.)
    return torch.tensor(np.array(arrays))

def train(root,payload,image_bytes):
    torch=dependency()
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=LOADED_SOURCE_HASH: raise ValueError('loaded CNN source changed')
    from .models import validate,finite,digest,canonical,immutable_json
    import copy
    p=copy.deepcopy(payload); a=p['algorithm']
    if a not in ('CNN','HYBRID'): raise ValueError('CNN or HYBRID required')
    checked=dict(p); checked['algorithm']='LINEAR'; checked,names=validate(checked,allow_empty_features=a=='CNN')
    rows=p['dataset']['records']
    if len(image_bytes)!=len(rows) or len(rows)>1000: raise ValueError('one image per record, maximum 1000')
    hashes={}
    for r,b in zip(rows,image_bytes):
        h=hashlib.sha256(b).hexdigest()
        if h in hashes and hashes[h]!=r['split']: raise ValueError('image byte leakage across splits')
        hashes[h]=r['split']
    c=p.get('config',{})
    if set(c)-{'epochs','learning_rate','seed'}: raise ValueError('unknown CNN config')
    epochs=c.get('epochs',5); seed=c.get('seed',0); rate=c.get('learning_rate',.001)
    if isinstance(epochs,bool) or not isinstance(epochs,int) or not 1<=epochs<=100: raise ValueError('epochs 1..100')
    if isinstance(seed,bool) or not isinstance(seed,int) or not 0<=seed<=2147483647: raise ValueError('invalid seed')
    if not 1e-5<=finite(rate)<=.1: raise ValueError('learning_rate out of bounds')
    torch.set_num_threads(1); torch.manual_seed(seed)
    ix=np.array([r['split']=='train' for r in rows]); x=np.array([[r['features'][k] for k in names] for r in rows]); mu=x[ix].mean(0); scale=x[ix].std(0)
    if not np.isfinite(mu).all() or not np.isfinite(scale).all(): raise ValueError('numeric scaling overflow')
    scale[scale==0]=1
    features=torch.tensor((x-mu)/scale,dtype=torch.float32) if a=='HYBRID' else torch.empty((len(rows),0)); images=images_tensor(torch,image_bytes); y=torch.tensor([r['target'] for r in rows],dtype=torch.float32)
    if not torch.isfinite(features).all() or not torch.isfinite(y).all(): raise ValueError('float32 numeric overflow')
    net=network(torch,features.shape[1]); opt=torch.optim.Adam(net.parameters(),lr=rate); indices=torch.tensor(np.flatnonzero(ix))
    for _ in range(epochs):
        net.train(); opt.zero_grad(); loss=((net(images[indices],features[indices])-y[indices])**2).mean(); 
        if not torch.isfinite(loss): raise ValueError('nonfinite training loss')
        loss.backward(); opt.step()
    net.eval()
    with torch.no_grad(): preds=net(images,features).numpy()
    if not np.isfinite(preds).all(): raise ValueError('nonfinite CNN predictions')
    from .models import metrics
    evaluation={}
    for split in ('train','validation','test'):
        ids=[j for j,r in enumerate(rows) if r['split']==split]
        evaluation[split]=metrics(y.numpy()[ids],preds[ids],float(y[indices].mean()),[rows[j]['participant_id'] for j in ids],0,seed) if ids else None
    record={'model_id':uuid.uuid4().hex,'algorithm':a,'status':'TRAINED_BENCH_RESEARCH_ONLY' if rows[0]['data_origin']=='NON_HUMAN_TEST' else 'TRAINED','data_origin':rows[0]['data_origin'],'clinical_status':'NOT_VALIDATED','payload':p,'payload_hash':digest(p),'config':{'epochs':epochs,'learning_rate':rate,'seed':seed},'feature_names':names,'scaler':{'mean':mu.tolist(),'scale':scale.tolist()},'images':[{'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode()} for b in image_bytes],'weights':{k:v.detach().numpy().tolist() for k,v in net.state_dict().items()},'runtime':{'torch':torch.__version__},'architecture':'Compact: 3x32x32 Conv8-ReLU-Pool-Conv16-ReLU-global-average + optional standardized optical features + linear regression','preprocessing':'Pillow RGB resize 32x32; encoded values /255','evaluation':evaluation,'source_sha256':LOADED_SOURCE_HASH,'provenance_authentication':'caller assertions only'}
    record['artifact_hash']=digest(record); directory=Path(root)/'cnn_models'; directory.mkdir(parents=True,exist_ok=True)
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=LOADED_SOURCE_HASH: raise ValueError('loaded CNN source changed')
    immutable_json(directory/f"{record['model_id']}.json",record)
    return record

def predict(record,image_bytes,features):
    torch=dependency()
    from .models import digest,finite
    if record['artifact_hash']!=digest({k:v for k,v in record.items() if k!='artifact_hash'}): raise ValueError('CNN artifact integrity failure')
    names=record['feature_names']
    if len(features)!=len(image_bytes): raise ValueError('image/features length mismatch')
    x=[]
    for row in features:
        if sorted(row)!=names: raise ValueError('feature schema mismatch')
        x.append([finite(row[k]) for k in names])
    values=torch.tensor((np.array(x)-record['scaler']['mean'])/record['scaler']['scale'],dtype=torch.float32) if record['algorithm']=='HYBRID' else torch.empty((len(x),0))
    if not torch.isfinite(values).all(): raise ValueError('float32 numeric overflow')
    net=network(torch,values.shape[1]); expected=net.state_dict()
    if set(expected)!=set(record['weights']): raise ValueError('weight key mismatch')
    weights={}
    for k,v in expected.items():
        array=np.array(record['weights'][k])
        if tuple(array.shape)!=tuple(v.shape) or not np.isfinite(array).all(): raise ValueError('invalid safe weights')
        weights[k]=torch.tensor(array,dtype=v.dtype)
    net.load_state_dict(weights); net.eval()
    with torch.no_grad(): result=net(images_tensor(torch,image_bytes),values).tolist()
    if not np.isfinite(result).all(): raise ValueError('nonfinite CNN predictions')
    return {'values':result,'clinical_prediction':None,'clinical_status':'NOT_VALIDATED'}
