"""Observed image candidates only; Haar evidence is not anatomical verification."""
import hashlib
from pathlib import Path
import cv2
import numpy as np
SOURCE_SHA256_AT_IMPORT = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def provenance():
    assets = {}
    for name in ('haarcascade_frontalface_default.xml','haarcascade_eye.xml'):
        path = Path(cv2.data.haarcascades)/name
        assets[name] = {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'license':'Intel Open Source Computer Vision Library license (XML header)'}
    return {'opencv':cv2.__version__,'haar_assets':assets,'code_sha256':SOURCE_SHA256_AT_IMPORT}

def _dark(gray, box):
    x,y,w,h = map(int,box); crop = gray[y:y+h,x:x+w]
    if crop.size == 0 or float(crop.max()-crop.min()) < 15: return []
    threshold, mask = cv2.threshold(crop,0,255,cv2.THRESH_BINARY_INV|cv2.THRESH_OTSU)
    contours,_ = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    result=[]
    for contour in contours:
        area=cv2.contourArea(contour)
        if len(contour)<5 or not 6 <= area <= crop.size*.25: continue
        (cx,cy),(a,b),angle=cv2.fitEllipse(contour)
        if min(a,b)<2 or max(a,b)/min(a,b)>3: continue
        result.append({'cx_px':float(cx+x),'cy_px':float(cy+y),'radius_px':float(np.sqrt(a*b)/2),'ellipse':{'axes_px':[float(a),float(b)],'angle_deg':float(angle)},'source':'AUTOMATIC_CANDIDATE','area_px':float(area),'contour_source_px':[[int(point[0][0]+x),int(point[0][1]+y)] for point in contour],'threshold_gray_code_value':float(threshold),'radius_definition':'EQUIVALENT_ELLIPSE_AREA_RADIUS_NOT_ANATOMICAL_MEASUREMENT'})
    return sorted(result,key=lambda item:-item['area_px'])

def detect(rgb, *, mirrored=None, upright_confirmed=False, identity_confirmed=False, previous=None):
    gray=cv2.cvtColor(np.asarray(rgb,dtype=np.uint8),cv2.COLOR_RGB2GRAY)
    faces=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml').detectMultiScale(gray,1.1,5,minSize=(40,40))
    candidates=[]
    eye_detector=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_eye.xml')
    for face_index,(x,y,w,h) in enumerate(faces):
        boxes=eye_detector.detectMultiScale(gray[y:y+h//2,x:x+w],1.1,4,minSize=(12,12))
        for ex,ey,ew,eh in boxes:
            found=_dark(gray,(x+ex,y+ey,ew,eh))
            if found: candidates.append({**found[0],'face_index':face_index,'face_backed':True,'eye_box':[int(x+ex),int(y+ey),int(ew),int(eh)]})
    if not candidates:
        candidates=[{**candidate,'face_backed':False} for candidate in _dark(gray,(0,0,gray.shape[1],gray.shape[0]))[:2]]
    candidates.sort(key=lambda item:item['cx_px'])
    used_tracks=set()
    for i,item in enumerate(candidates):
        item['image_side']='LEFT' if i==0 else 'RIGHT' if i==len(candidates)-1 else 'UNKNOWN'
        item['track_id']=None
        if previous:
            distances=[(np.hypot(item['cx_px']-p['cx_px'],item['cy_px']-p['cy_px']),p.get('track_id')) for p in previous]
            distance,track=min(distances,default=(float('inf'),None))
            if distance <= max(10,item['radius_px']*2) and track is not None and track not in used_tracks:
                item['track_id']=track; used_tracks.add(track)
        # Unmatched observations have no persistent identity; never recycle track IDs.
        item['tracking_status']='MATCHED_OBSERVATION' if item['track_id'] is not None else 'NEW_UNASSIGNED_OBSERVATION'
    eyes={'OD':None,'OS':None}
    valid=len(candidates)==2 and all(c.get('face_backed') for c in candidates) and candidates[0].get('face_index')==candidates[1].get('face_index') and len(faces)==1 and isinstance(mirrored,bool) and upright_confirmed and identity_confirmed
    if valid:
        left,right=candidates
        # Repeated/overlapping Haar boxes can describe the same observed component.
        # Preserve both observations, but they cannot establish two anatomical eyes.
        lx,ly,lw,lh=left['eye_box']; rx,ry,rw,rh=right['eye_box']
        boxes_overlap=max(lx,rx)<min(lx+lw,rx+rw) and max(ly,ry)<min(ly+lh,ry+rh)
        circles_overlap=np.hypot(left['cx_px']-right['cx_px'],left['cy_px']-right['cy_px']) < left['radius_px']+right['radius_px']
        valid=not boxes_overlap and not circles_overlap
    if valid:
        eyes['OS' if mirrored else 'OD']=candidates[0]
        eyes['OD' if mirrored else 'OS']=candidates[1]
    return {'faces':[list(map(int,f)) for f in faces],'candidates':candidates,'eyes':eyes,'identity_status':'CONFIRMED_CONTEXT_FACE_BACKED' if valid else 'UNRESOLVED','blink':None,'head_pose':None,'tracking':'OBSERVED_ONLY','quality':{'laplacian_variance':float(cv2.Laplacian(gray,cv2.CV_64F).var()),'saturated_channel_fraction':float((rgb>=254).any(axis=2).mean()),'missing_eye_candidates':len(candidates)<2}}
