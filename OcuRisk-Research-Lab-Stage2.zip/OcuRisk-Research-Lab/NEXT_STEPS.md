# Next work from the DroidCam milestone

Read RESUME_HERE.md, PROJECT_STATUS.md, TASK_BOARD.md and STAGE2_TEST_REPORT.md. Source `c618576` is implemented/tested in documented fixture scope. Do not rebuild another app or restart modules.

1. User runs existing Windows DroidCam source through the local Lab using DROIDCAM_WINDOWS_SETUP.md. Verify discovery, permission, exact source, preview, snapshot, recording, autoanalysis and retained bytes. Report real errors; no custom APK prerequisite.
2. Record the same stationary nonhuman chart over USB and Wi-Fi, with paired/target IDs, matching framing/settings and honest declared controls. Inspect automatically produced measurements/graphs and comparison limitations; export actual evidence. Do not infer a winner from one clip or high sharpness alone.
3. Sol executes retained real browser interaction test on an equipped/permitted host and fixes any confirmed issue; independently review significant fixes. Source here passed mocks and HTTP tests, not browser interaction.
4. Lead reviews real source/quality output, feature stability, timestamps/settings/processing limitations. Design independently referenced model-eye geometry and representative pupil/reflex annotation studies; continue primary literature/sign/unit/uncertainty research in parallel.
5. Only if a measured essential DroidCam acquisition limitation blocks the scientific protocol, investigate optional native acquisition; prior Android source/build blockers are retained.
6. Qualified collaborators/user define optical safety, permissions, independent reference measurements and clinical endpoint/precision protocol before illuminated participant studies. Freeze grouped datasets/evaluation before selecting a complete pipeline.

Root leads scientific work; GPT-6.1 Sol implements. Original integration requires later explicit approval. Update exact test/code/data/config evidence and continuation files after each material result; retain failed and rejected evidence. No agents continue automatically while the session is paused.
