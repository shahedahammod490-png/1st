#!/usr/bin/env python3
"""Replay a supplied image/manual eye JSON twice; no built-in or clinical data.

Example: python tools/replay.py --image frame.png --eyes-json eyes.json --output-dir replay
The eye JSON is {"OD":circle|null,"OS":circle|null}; coordinates decoded pixels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import PIL

from ocurisk_lab.optical import analyze_frame


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical(value) -> str:
    return json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n'


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--eyes-json', type=Path, required=True)
    parser.add_argument('--config-json', type=Path)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    eyes = json.loads(args.eyes_json.read_text(encoding='utf-8'))
    config = json.loads(args.config_json.read_text(encoding='utf-8')) if args.config_json else None
    # Output must be a new directory: replay must not overwrite an earlier run.
    if args.output_dir.exists():
        parser.error('--output-dir must not exist (replay output is immutable)')
    with tempfile.TemporaryDirectory(prefix='ocurisk_replay_') as temp:
        first_dir, second_dir = Path(temp)/'first', Path(temp)/'second'
        first = analyze_frame(args.image,eyes,first_dir,config)
        second = analyze_frame(args.image,eyes,second_dir,config)
        equal_json = _canonical(first) == _canonical(second)
        artifact_hashes, equal_artifacts = {}, True
        for eye in ('OD','OS'):
            for name in first['eyes'][eye]['artifacts'].values():
                artifact_hashes[name] = _hash(first_dir/name)
                equal_artifacts &= artifact_hashes[name] == _hash(second_dir/name)
        report = {
            'schema_version':'1.0',
            'scope':'engineering replay only; no optical or clinical validation',
            'source_sha256':_hash(args.image),
            'eyes_input_sha256':_hash(args.eyes_json),
            'config_input_sha256':_hash(args.config_json) if args.config_json else None,
            'algorithm_id':first['algorithm_id'],
            'algorithm_version':first['algorithm_version'],
            'runtime':{'python':platform.python_version(),'numpy':np.__version__,'pillow':PIL.__version__},
            'result_json_identical':equal_json,
            'artifact_bytes_identical':equal_artifacts,
            'artifact_sha256':artifact_hashes,
        }
        args.output_dir.mkdir(parents=True)
        artifact_dir = args.output_dir/'artifacts'
        artifact_dir.mkdir()
        for name in artifact_hashes:
            (artifact_dir/name).write_bytes((first_dir/name).read_bytes())
        (args.output_dir/'result.json').write_text(_canonical(first),encoding='utf-8')
        (args.output_dir/'replay_report.json').write_text(_canonical(report),encoding='utf-8')
    print(_canonical(report),end='')
    return 0 if equal_json and equal_artifacts else 1


if __name__ == '__main__':
    raise SystemExit(main())
