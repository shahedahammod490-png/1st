"""Synthetic host fixtures only; no ADB device or real camera evidence."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("adb_export", Path(__file__).with_name("adb_export.py"))
export = importlib.util.module_from_spec(spec)
spec.loader.exec_module(export)


class ExportIntegrityTest(unittest.TestCase):
    def entry(self, name="capture.jpg", raw=b"\xff\xd8\x00test\xff\xd9"):
        return {"name": name, "size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

    def raw_manifest(self, entries):
        return json.dumps({"schema_version": "1.0", "files": entries}).encode()

    def test_actual_bytes_and_corruption(self):
        data=b"\xff\xd8\x00test\xff\xd9"
        entry=self.entry(raw=data)
        export.validate_bytes(entry,data)
        with self.assertRaises(ValueError): export.validate_bytes(entry,data[:-1])
        with self.assertRaises(ValueError): export.validate_bytes(entry,b"x"*len(data))

    def test_reject_unsafe_and_duplicate_names(self):
        for name in ("../capture.jpg", "C:evil.jpg", "a/b.jpg", "a\\b.jpg", "checksums.json", ".."): 
            with self.subTest(name=name),self.assertRaises(ValueError): export.checksum_entries(self.raw_manifest([self.entry(name)]))
        with self.assertRaises(ValueError): export.checksum_entries(self.raw_manifest([self.entry(),self.entry()]))

    def test_invalid_sizes_and_json(self):
        for size in (-1,True,export.MAX_FILE+1):
            entry=self.entry();entry["size_bytes"]=size
            with self.assertRaises(ValueError): export.checksum_entries(self.raw_manifest([entry]))
        for raw in (b'{"schema_version":"1.0","schema_version":"1.0","files":[]}',b'{"x":NaN}'):
            with self.assertRaises(ValueError): export.checksum_entries(raw)

    def test_payload_preserves_image_bytes_and_timestamp_string(self):
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)/"capture";directory.mkdir()
            raw=b"\xff\xd8\x00test\xff\xd9"; (directory/"capture.jpg").write_bytes(raw)
            manifest={"data_origin":"NON_HUMAN_TEST","mode":"CONTROL","frames":[{"source_file":"capture.jpg","sha256":hashlib.sha256(raw).hexdigest(),"timestamp_ns":"9223372036854775800","eyes":{"OD":None,"OS":None}}]}
            (directory/"manifest.json").write_text(json.dumps(manifest))
            (directory/"checksums.json").write_bytes(self.raw_manifest([self.entry(),self.entry("manifest.json",(directory/"manifest.json").read_bytes())]))
            output=Path(temp)/"payload.json";export.import_payload(directory,output)
            payload=json.loads(output.read_text());self.assertEqual(payload["manifest"]["frames"][0]["timestamp_ns"],"9223372036854775800")
            import base64
            self.assertEqual(base64.b64decode(payload["files"][0]["base64"]),raw)
            (directory/"unexpected.txt").write_text("x")
            with self.assertRaises(ValueError): export.validate_local(directory)

    def test_no_implicit_device_or_unsafe_id(self):
        with self.assertRaises(ValueError): export.assert_device("adb","unsafe; serial")
        with self.assertRaises(ValueError): export.download("adb","serial","../../wrong",Path("unused"))

    def test_download_synthetic_byte_roundtrip_and_no_overwrite(self):
        raw=b"\xff\xd8\x00test\xff\xd9"
        manifest={"data_origin":"NON_HUMAN_TEST","mode":"CONTROL","frames":[{"source_file":"capture.jpg","sha256":hashlib.sha256(raw).hexdigest()}]}
        files={"capture.jpg":raw,"manifest.json":json.dumps(manifest).encode(),"metadata.json":b'{"fixture":"SYNTHETIC_HOST_TEST"}'}
        files["checksums.json"]=self.raw_manifest([self.entry(n,b) for n,b in files.items()])
        capture_id="capture_"+"a"*32
        calls=[]
        def synthetic_adb(adb,serial,args,max_bytes):
            calls.append((adb,serial,args))
            self.assertEqual(serial,"explicit_serial")
            if args==["get-state"]: return b"device\n"
            self.assertEqual(args[:4],["exec-out","run-as",export.PACKAGE,"cat"])
            self.assertTrue(args[4].startswith(f"files/export/{capture_id}/"))
            return files[args[4].split("/")[-1]]
        with tempfile.TemporaryDirectory() as temp,patch.object(export,"adb_bytes",side_effect=synthetic_adb):
            path=export.download("adb","explicit_serial",capture_id,Path(temp))
            self.assertEqual((path/"capture.jpg").read_bytes(),raw)
            self.assertEqual(len(export.validate_local(path)),3)
            with self.assertRaises(FileExistsError): export.download("adb","explicit_serial",capture_id,Path(temp))
        self.assertTrue(calls)


if __name__=="__main__": unittest.main()
