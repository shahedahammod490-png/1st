# Run from any directory after completing README installation. No phone changes.
$ErrorActionPreference = 'Stop'
$labRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location $labRoot
$labPython = Join-Path $labRoot '.venv/Scripts/python.exe'
if (-not (Test-Path $labPython)) { throw 'Missing .venv. Complete the README Windows installation first.' }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue) -or -not (Get-Command ffprobe -ErrorAction SilentlyContinue)) { throw 'FFmpeg and ffprobe must be installed on PATH.' }
Write-Host 'Open http://127.0.0.1:8765 and select your actual DroidCam camera input. Ctrl+C stops the local server.'
& $labPython -m ocurisk_lab.server --host 127.0.0.1 --port 8765 --data-dir (Join-Path $labRoot 'data')
exit $LASTEXITCODE
