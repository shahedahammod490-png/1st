# Requires Windows PowerShell 5.1+ or PowerShell 7, Android platform-tools, Python 3.11+ for export.
# No implicit install, device cleanup, wipe, root, package uninstall or camera/LED access.
[CmdletBinding()]
param(
    [ValidateSet('Devices','Diagnostic','Install','Export','Reverse','RemoveReverse')][string]$Mode = 'Devices',
    [string]$Serial,
    [string]$Adb = 'adb',
    [string]$Python = 'python',
    [string]$OutputDirectory = '.\device-evidence',
    [string]$Apk,
    [string]$CaptureId
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Invoke-AdbText([string[]]$Arguments) {
    # Windows PowerShell 5.1 may turn native stderr into an ErrorRecord even on exit 0.
    $previousPreference = $ErrorActionPreference
    try { $ErrorActionPreference = 'Continue'; $text = & $Adb @Arguments 2>&1; $exitCode = $LASTEXITCODE }
    finally { $ErrorActionPreference = $previousPreference }
    if ($exitCode -ne 0) { throw "ADB failed ($exitCode): $($text -join [Environment]::NewLine)" }
    return ($text -join [Environment]::NewLine)
}
function Invoke-Selected([string[]]$Arguments) {
    return Invoke-AdbText (@('-s', $Serial) + $Arguments)
}
function Save-Evidence([string]$Name,[string[]]$Arguments) {
    $result = Invoke-Selected $Arguments
    [IO.File]::WriteAllText((Join-Path $script:DiagnosticPath $Name), $result, [Text.UTF8Encoding]::new($false))
}

$null = Get-Command $Adb -ErrorAction Stop
$devices = Invoke-AdbText @('devices','-l')
if ($Mode -eq 'Devices') { Write-Output $devices; return }
if ([string]::IsNullOrWhiteSpace($Serial) -or $Serial -notmatch '^[A-Za-z0-9_.:-]{1,120}$') {
    throw 'Supply an explicit -Serial from Devices; no first-device selection is permitted.'
}
$state = Invoke-Selected @('get-state')
if ($state.Trim() -ne 'device') { throw "Device is unauthorized/offline or missing: $state" }

switch ($Mode) {
    'Diagnostic' {
        $script:DiagnosticPath = Join-Path $OutputDirectory ('diagnostic_' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ'))
        if (Test-Path -LiteralPath $script:DiagnosticPath) { throw 'Evidence directory already exists.' }
        $null = New-Item -ItemType Directory -Path $script:DiagnosticPath
        [IO.File]::WriteAllText((Join-Path $script:DiagnosticPath 'adb-devices.txt'),$devices,[Text.UTF8Encoding]::new($false))
        Save-Evidence 'adb-version.txt' @('version')
        Save-Evidence 'android-release.txt' @('shell','getprop','ro.build.version.release')
        Save-Evidence 'android-sdk.txt' @('shell','getprop','ro.build.version.sdk')
        Save-Evidence 'build-fingerprint.txt' @('shell','getprop','ro.build.fingerprint')
        Save-Evidence 'model.txt' @('shell','getprop','ro.product.model')
        Save-Evidence 'camera-service.txt' @('shell','dumpsys','media.camera')
        Save-Evidence 'sensor-service.txt' @('shell','dumpsys','sensorservice')
        [IO.File]::WriteAllText((Join-Path $script:DiagnosticPath 'host.txt'),"UTC=$([DateTime]::UtcNow.ToString('o'))`nSerial=$Serial`nPowerShell=$($PSVersionTable.PSVersion)",[Text.UTF8Encoding]::new($false))
        Write-Output "Saved diagnostics: $script:DiagnosticPath. Physical camera/LED/geometry remains unverified."
    }
    'Install' {
        if ([string]::IsNullOrWhiteSpace($Apk) -or -not (Test-Path -LiteralPath $Apk -PathType Leaf)) { throw 'Install mode requires an existing debug APK via -Apk.' }
        Write-Output (Invoke-Selected @('install','-r',(Resolve-Path -LiteralPath $Apk).Path))
    }
    'Export' {
        if ($CaptureId -notmatch '^(capture|probe|video)_[a-f0-9]{32}$') { throw 'Copy the exact sealed export ID from the app into -CaptureId.' }
        $null = Get-Command $Python -ErrorAction Stop
        & $Python (Join-Path $PSScriptRoot 'adb_export.py') download --adb $Adb --serial $Serial --capture-id $CaptureId --destination $OutputDirectory
        if ($LASTEXITCODE -ne 0) { throw 'Export failed; do not import any incomplete folder.' }
    }
    'Reverse' {
        Write-Output (Invoke-Selected @('reverse','tcp:8765','tcp:8765'))
        Write-Output 'Port mapping requested. Android direct upload is NOT_IMPLEMENTED; this does not prove connectivity or camera access.'
    }
    'RemoveReverse' { Write-Output (Invoke-Selected @('reverse','--remove','tcp:8765')) }
}
