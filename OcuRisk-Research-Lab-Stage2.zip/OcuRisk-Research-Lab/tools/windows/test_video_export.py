"""Actual FFmpeg encoded synthetic media; simulated USB transport, no physical device."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from test_adb_export import export

class VideoExportTest(unittest.TestCase):
    def fixture(self, root, status='FINALIZED'):
        path=root/'source.mp4'
        subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=64x48:rate=5','-t','0.6','-c:v','mpeg4',str(path)],check=True)
        raw=path.read_bytes()
        metadata={'schema_version':'2.0','data_origin':'NON_HUMAN_TEST','direction':'RIGHT','mode':'MULTI_VIEW','status':status,'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw),'sensor_frame_association':'UNKNOWN_NO_ENCODED_FRAME_SENSOR_MATCH'}
        files={'recording.mp4':raw,'metadata.json':json.dumps(metadata).encode(),'recording_events.jsonl':b'{"event":"Finalize"}\n','capture_results.jsonl':b''}
        entries=[{'name':n,'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in files.items()]
        files['checksums.json']=json.dumps({'schema_version':'1.0','files':entries}).encode()
        return files
    def test_actual_encoded_binary_usb_roundtrip(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);files=self.fixture(root)
            def adb(adb,serial,args,max_bytes): return b'device\n' if args==['get-state'] else files[args[-1].split('/')[-1]]
            with patch.object(export,'adb_bytes',side_effect=adb):
                result=export.download('adb','synthetic_transport','video_'+'b'*32,root/'downloads')
            self.assertEqual((result/'recording.mp4').read_bytes(),files['recording.mp4'])
            self.assertEqual(len(export.validate_local(result)),4)
            subprocess.run(['ffprobe','-v','error','-show_entries','stream=nb_frames',str(result/'recording.mp4')],check=True,capture_output=True)
            (result/'capture_results.jsonl').unlink()
            with self.assertRaises(ValueError): export.validate_local(result)
    def test_failed_recording_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);files=self.fixture(root,'ERROR');directory=root/'export';directory.mkdir()
            for n,b in files.items():(directory/n).write_bytes(b)
            with self.assertRaises(ValueError):export.validate_local(directory)
    def test_loopback_import_hashes_and_sidecar_bytes(self):
        from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
        from threading import Thread
        received=[]
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                body=self.rfile.read(int(self.headers['Content-Length']));received.append((self.path,body))
                result={'media_id':'media_fixture','sha256':hashlib.sha256(body).hexdigest(),'size_bytes':len(body)}
                payload=json.dumps(result).encode();self.send_response(200);self.end_headers();self.wfile.write(payload)
            def log_message(self,*args):pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            with tempfile.TemporaryDirectory() as t:
                root=Path(t);files=self.fixture(root);directory=root/'video_fixture';directory.mkdir()
                for n,b in files.items():(directory/n).write_bytes(b)
                result=export.import_stage2(directory,f'http://127.0.0.1:{server.server_port}','exp_fixture')
                self.assertEqual(received[0][1],files['recording.mp4']);self.assertEqual(len(result['sidecars']),4)
                for path,body in received[1:]:self.assertEqual(body,files[path.split('/')[-1]])
        finally:server.shutdown();server.server_close()
