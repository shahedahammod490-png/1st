"""Verify protected ZIP and extracted authored files against recorded hashes."""
import argparse
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--zip', type=Path)
parser.add_argument('--source', type=Path, help='parent of extracted EYE directory')
args = parser.parse_args()
baseline = json.loads((root / 'evidence/original_inventory.json').read_text())
if not args.zip and not args.source:
    parser.error('supply --zip or --source')
failures = []
if args.zip and hashlib.sha256(args.zip.read_bytes()).hexdigest() != baseline['zip_sha256']:
    failures.append('ZIP SHA256 mismatch')
if args.source:
    for file in baseline['files']:
        p = args.source / file['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != file['sha256']:
            failures.append(file['path'])
print(json.dumps({'passed': not failures, 'failures': failures,
                  'original_zip_sha256': baseline['zip_sha256']}))
raise SystemExit(bool(failures))
