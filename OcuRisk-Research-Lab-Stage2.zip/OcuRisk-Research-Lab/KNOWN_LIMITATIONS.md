# Current limitations — Stage2

- No real CMF captures, physical Windows/USB test, measured illumination geometry, optical model-eye calibration, participant cohort or clinical reference dataset exists in this delivery.
- Current native build is BLOCKED by unresolved Android build dependencies; no APK is supplied. Current browser launch is BLOCKED by the execution environment's denied socket operation; no rendered screenshots or successful browser interaction are claimed.
- Software tests exercise explicit synthetic inputs. Automatic Haar/dark-region/ellipse candidates and red/brightness masks have no representative independent pupil/reflex-accuracy validation. Tracking loss never proves blinking; head pose remains unavailable unless an actual estimator exists.
- Raw RGB code values are not calibrated radiance. Pixel sizes are not measured millimetres. Media PTS is not automatically a camera sensor exposure clock. Source direction labels do not measure head/gaze geometry.
- Five regression estimators and a Bayesian Laplace candidate are executable. Their fitted outputs remain research-only. No clinical training data, calibrated disease risk, winner, progression model or validated optical equation is shipped.
- Optional CNN/hybrid source requires PyTorch. Neural execution is unverified beyond schema/dependency checks where Torch is absent. Named pretrained architectures and temporal fusion are future work.
- Current grouped fixed-config CV is not nested model selection; exact duplicate/reference checks do not discover every hidden target proxy, near duplicate, device/site or temporal leakage. Complete-record errors omit acquisition failures. Paired model-difference inference, external calibration and sufficient sample size remain separate study requirements.
- The legacy formula is an uncalibrated arithmetic comparator with explicit inputs/clamps, not an eye-power prescription. Power vectors transform supplied reference values only.
- Reviewer credentials, blinding and approval/reference strings are caller assertions. Dedicated protected raw-first review, reveal logging and independent adjudication are not established by a checkbox.
- Local loopback storage has no complete clinical account, encryption, access/retention governance or verified device-pairing system. Keep participant data and full fitted training payloads out of Git/release ZIPs.
- Stage1 historical audit/test outcomes remain preserved but do not automatically cover changed Stage2 source. Exact current evidence and remaining software findings belong in the final verification report.
- Original OcuRisk remains protected. Integration requires independent scientific evidence and explicit user approval.

## DroidCam current limitations

Virtualcamera transport is not programmatically identified; USB/WiFi userdeclared. Sensor clocks/native frame losses/raw radiance/original linkencoding remain unknown. Saved bitrate can be unavailable; blockgrid and sharpness are scene/noiseconfounded. Browserrecording addsprocessing; unsupported focus/exposure/WB controls remain unverified. Actualbrowser install failedinvalidZIP/missingbinary; no screenshots. ActualWindowsLab/CMF workflow awaitsuser nonhumantesting, despite existingDroidCamconnection working byuserreport. Recorder120secbound doesnot guarantee10000framebound atveryhighFPS. Partialbytes preserved but no automaticanalysis; manualinspectiondoesnotmakepartialmatchedeligible. No opticalcalibration/clinicalpipeline winner. NativeAPK optional.
