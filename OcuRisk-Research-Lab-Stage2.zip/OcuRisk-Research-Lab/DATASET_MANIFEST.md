# Actual dataset and provenance

Zero enrolled participants, zero real CMF captures, zero independent clinical reference records and zero longitudinal outcomes have been supplied to this Lab. No original patient database is imported. Automated tests use explicitly synthetic temporary fixtures.

Stage1 image-manifest schema remains supported. Stage2 adds immutable source media, experiment/mode/direction/mirroring records, indexed frames, jobs, append-only manual annotations and reviewer labels, references and sidecars. Exports preserve source bytes/hashes and actual analysis evidence. Camera/illumination metadata are observed or caller supplied; missing clock/pose/geometry remain unavailable.

Clinical references and expert reflex visibility are separate records. REAL_APPROVED, permission/reference strings, reviewer qualifications and blinding are assertions rather than authenticated evidence. Independent bench targets require apparatus/calibration provenance and remain nonclinical. No missing reference becomes zero or normal refraction.

Both eyes and repeated frames of a participant stay in the same split. Exact duplicate/participant/reference-ID checks do not establish complete leakage clearance. Retain failures, exclusions, origins and denominators. Full acquisition coverage differs from complete-record prediction coverage. Freeze reference versions and test cohorts before final comparisons.

Keep participant media, consent lookup and training payloads outside Git/release archives. Loopback HTTP and SQLite do not constitute full clinical authentication, encryption or retention governance. Applicable permission, access, retention and backup policies must precede participant collection. No human-eye illumination approval is supplied by this software.

## DroidCam dataset extension

Runtime starts empty; zero real DroidCam chart/eye records are shipped. Each imported source can have exact capture-quality.json bytes/hash with requested/observed/manual declarations and partialstatus. Jobs snapshot attachments/config/loadedcode/runtime and allframe quality; immutable acquisition-quality.json covers actual summary. Everyframe and rejected/unsampled candidate evidence is retained; quality is saved with media/job exports. USB/Wifi labels userdeclared, stationarychart not independently certified. Historicalarchive inputscope shows currentattachment mismatch; source/artifact/sidecar tampering rejects export. Testfixtures are synthetic only.
